(() => {
  // src/impostazioni.js
  var PREDEFINITE = {
    ollama: "http://localhost:11434",
    modello: "",
    // vuoto = automatico (preferisce TranslateGemma)
    opacita: 100,
    // percentuale
    testo: 100
    // dimensione del testo in percentuale
  };

  // src/popup.js
  var $ = (id) => document.getElementById(id);
  var esito = (t) => {
    $("esito").textContent = t;
  };
  var ask = (msg) => chrome.runtime.sendMessage({ to: "background", ...msg });
  async function loadModels(current) {
    const r = await ask({ type: "modelli" });
    const sel = $("modello");
    sel.length = 1;
    if (r?.error) {
      esito(r.error);
      return;
    }
    for (const m of r.modelli) sel.add(new Option(m, m));
    if (current && !r.modelli.includes(current)) sel.add(new Option(current + " (non trovato)", current));
    sel.value = current;
  }
  async function init() {
    const cfg = { ...PREDEFINITE, ...await chrome.storage.sync.get(PREDEFINITE) };
    $("ollama").value = cfg.ollama;
    for (const k of ["opacita", "testo"]) {
      $(k).value = cfg[k];
      $(k + "V").textContent = cfg[k];
    }
    loadModels(cfg.modello);
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    let on = !!(await ask({ type: "stato", tabId: tab?.id }))?.on;
    const showOn = () => {
      $("avvia").textContent = on ? "Ferma su questa scheda" : "Avvia su questa scheda";
      $("avvia").classList.toggle("acceso", on);
    };
    showOn();
    $("avvia").onclick = async () => {
      if (!tab) return;
      on = !on;
      await ask({ type: on ? "avvia" : "ferma", tabId: tab.id });
      showOn();
      if (on) window.close();
    };
    $("ollama").onchange = async () => {
      await chrome.storage.sync.set({ ollama: $("ollama").value.trim() || PREDEFINITE.ollama });
      loadModels($("modello").value);
    };
    $("modello").onchange = () => chrome.storage.sync.set({ modello: $("modello").value });
    for (const k of ["opacita", "testo"]) {
      $(k).oninput = () => {
        $(k + "V").textContent = $(k).value;
        chrome.storage.sync.set({ [k]: Number($(k).value) });
      };
    }
    $("prova").onclick = async () => {
      esito("Provo\u2026 la prima volta Ollama carica il modello, pu\xF2 volerci un po'.");
      const r = await ask({ type: "prova" });
      esito(r?.error ? r.error : `${r.model} in ${r.secondi}s:
\xAB${r.it}\xBB`);
    };
    $("ritraduci").onclick = async () => {
      const [tab2] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab2) chrome.tabs.sendMessage(tab2.id, { to: "pagina", type: "ritraduci" }).catch(() => esito("Ricarica la pagina e riprova."));
      window.close();
    };
  }
  init();
})();
