(() => {
  // src/impostazioni.js
  var PREDEFINITE = {
    ollama: "http://localhost:11434",
    modello: "",
    // vuoto = automatico (preferisce TranslateGemma)
    opacita: 100,
    // percentuale
    testo: 100
    // dimensione del testo in percentuale
  };

  // src/content.js
  var cfg = { ...PREDEFINITE };
  var on = false;
  var MIN_W = 300;
  var MIN_H = 200;
  var MIN_SHOWN = 250;
  var done = /* @__PURE__ */ new WeakMap();
  var queue = [];
  var busy = false;
  var isCandidate = (img) => img.naturalWidth >= MIN_W && img.naturalHeight >= MIN_H && img.getBoundingClientRect().width >= MIN_SHOWN;
  var srcOf = (img) => img.currentSrc || img.src;
  function enqueue(img) {
    if (!on || !isCandidate(img)) return;
    const src = srcOf(img);
    if (!src) return;
    const d = done.get(img);
    if (d && d.src === src) return;
    d?.layer?.querySelectorAll(".mercurio-riquadro").forEach((e) => e.remove());
    done.set(img, { src, layer: d?.layer, result: null });
    if (!queue.includes(img)) queue.push(img);
    pump();
  }
  async function send(msg) {
    try {
      return await chrome.runtime.sendMessage(msg);
    } catch (e) {
      const m = String(e?.message || e);
      return { error: /context invalidated/i.test(m) ? "Mercurio \xE8 stato aggiornato: ricarica la pagina (F5)" : m };
    }
  }
  async function pump() {
    if (busy) return;
    busy = true;
    try {
      while (queue.length) await work();
    } finally {
      busy = false;
    }
  }
  async function work() {
    {
      queue.sort((a, b) => Math.abs(a.getBoundingClientRect().top) - Math.abs(b.getBoundingClientRect().top));
      const img = queue.shift();
      const d = done.get(img);
      if (!d || !on) return;
      const layer = layerFor(img);
      badge(layer, "Mercurio: leggo\u2026", false);
      let res;
      try {
        const local = d.src.startsWith("blob:") || d.src.startsWith("data:");
        res = local ? await send({ to: "background", type: "pagina", src: d.src, data: await fromPage(d.src) }) : await send({ to: "background", type: "pagina", src: d.src });
        if (!local && res?.error?.startsWith("il sito non mi d\xE0")) {
          const data = await fromPage(d.src);
          if (data) res = await send({ to: "background", type: "pagina", src: d.src, data });
        }
      } catch (e) {
        res = { error: String(e?.message || e) };
      }
      if (done.get(img) !== d) return;
      if (res?.error) {
        badge(layer, "Mercurio: " + res.error, true);
        d.src = null;
        return;
      }
      d.result = res;
      let n = 0;
      for (const b of res.balloons) {
        if (done.get(img) !== d || !on || !img.isConnected || img.getBoundingClientRect().width === 0) break;
        badge(layer, `Mercurio: traduco ${++n}/${res.balloons.length}`, false);
        const t = await send({ to: "background", type: "traduci", text: b.text });
        if (t?.error) {
          badge(layer, "Mercurio: " + t.error, true);
          break;
        }
        b.it = t.it;
        if (done.get(img) === d) draw(img);
      }
      if (done.get(img) === d && n === res.balloons.length) badge(layer, null);
      else if (done.get(img) === d) d.src = null;
    }
  }
  async function fromPage(src) {
    try {
      const blob = await (await fetch(src)).blob();
      return await new Promise((ok, ko) => {
        const r = new FileReader();
        r.onload = () => ok(r.result);
        r.onerror = ko;
        r.readAsDataURL(blob);
      });
    } catch {
      return null;
    }
  }
  function layerFor(img) {
    const d = done.get(img);
    if (d.layer?.isConnected) return d.layer;
    const layer = document.createElement("div");
    layer.className = "mercurio-strato";
    document.body.appendChild(layer);
    d.layer = layer;
    place(img);
    return layer;
  }
  function place(img) {
    const d = done.get(img);
    if (!d?.layer) return;
    const r = img.getBoundingClientRect();
    const s = d.layer.style;
    s.left = r.left + window.scrollX + "px";
    s.top = r.top + window.scrollY + "px";
    s.width = r.width + "px";
    s.height = r.height + "px";
    s.display = r.width > 0 && on ? "" : "none";
    const k = d.result ? r.width / d.result.w : 0;
    if (k && Math.abs((d.k || 0) - k) > 1e-3) draw(img);
  }
  function draw(img) {
    const d = done.get(img);
    if (!d?.result) return;
    const layer = layerFor(img);
    const r = img.getBoundingClientRect();
    const k = r.width / d.result.w;
    d.k = k;
    layer.querySelectorAll(".mercurio-riquadro").forEach((e) => e.remove());
    for (const b of d.result.balloons) {
      if (!b.it) continue;
      const el = document.createElement("div");
      el.className = "mercurio-riquadro";
      el.textContent = b.it;
      el.title = b.text;
      const pad = 4;
      Object.assign(el.style, {
        left: b.box.x * k - pad + "px",
        top: b.box.y * k - pad + "px",
        width: b.box.w * k + 2 * pad + "px",
        height: b.box.h * k + 2 * pad + "px",
        opacity: String(cfg.opacita / 100)
      });
      layer.appendChild(el);
      fit(el, b.box.h * k + 2 * pad);
    }
  }
  var MIN_FONT = 11;
  function fit(el, h) {
    let size = Math.max(MIN_FONT, Math.round(16 * cfg.testo / 100));
    const floor = Math.max(MIN_FONT, Math.round(size * 0.7));
    const overflows = () => el.scrollWidth > el.clientWidth + 1 || el.scrollHeight > h + 1;
    el.style.fontSize = size + "px";
    el.style.height = "auto";
    el.style.minHeight = h + "px";
    while (overflows() && size > floor) {
      size--;
      el.style.fontSize = size + "px";
    }
    const layerW = el.parentElement.clientWidth;
    let w = el.offsetWidth;
    while (el.scrollWidth > el.clientWidth + 1 && w < layerW) {
      const grow = Math.min(el.scrollWidth - el.clientWidth + 6, layerW - w);
      const left = Math.max(0, Math.min(layerW - w - grow, parseFloat(el.style.left) - grow / 2));
      w += grow;
      el.style.width = w + "px";
      el.style.left = left + "px";
    }
    if (el.scrollWidth > el.clientWidth + 1) el.style.overflowWrap = "anywhere";
  }
  function badge(layer, text, error) {
    let b = layer.querySelector(".mercurio-stato");
    if (!text) {
      b?.remove();
      return;
    }
    if (!b) {
      b = document.createElement("div");
      b.className = "mercurio-stato";
      layer.appendChild(b);
    }
    b.textContent = text;
    b.style.background = error ? "rgba(200,30,30,.9)" : "rgba(40,40,40,.75)";
    clearTimeout(b._t);
    if (error) b._t = setTimeout(() => b.remove(), 15e3);
  }
  var watcher = new IntersectionObserver((entries) => {
    for (const e of entries) if (e.isIntersecting) enqueue(e.target);
  }, { rootMargin: "1200px 0px" });
  function watch(img) {
    if (img._mercurio) return;
    img._mercurio = true;
    watcher.observe(img);
    img.addEventListener("load", () => {
      watcher.unobserve(img);
      watcher.observe(img);
    });
  }
  function scan(root = document) {
    root.querySelectorAll?.("img").forEach(watch);
  }
  new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.type === "attributes" && m.target.tagName === "IMG") {
        const d = done.get(m.target);
        if (d && d.src !== srcOf(m.target)) {
          d.layer?.remove();
          done.delete(m.target);
        }
        watcher.unobserve(m.target);
        watcher.observe(m.target);
      }
      for (const n of m.addedNodes) {
        if (n.tagName === "IMG") watch(n);
        else if (n.nodeType === 1) scan(n);
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["src", "srcset"] });
  function relayoutAll() {
    document.querySelectorAll("img").forEach((img) => {
      const d = done.get(img);
      if (d?.layer) {
        if (!img.isConnected) {
          d.layer.remove();
          done.delete(img);
        } else place(img);
      }
      if (d && d.src && d.src !== srcOf(img) && img.complete) enqueue(img);
      else if (!img._mercurio) watch(img);
    });
  }
  var raf = 0;
  var relayoutSoon = () => {
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(relayoutAll);
  };
  window.addEventListener("resize", relayoutSoon);
  setInterval(relayoutAll, 1500);
  function redrawAll() {
    document.querySelectorAll(".mercurio-strato").forEach((l) => {
      l.style.display = on ? "" : "none";
    });
    document.querySelectorAll("img").forEach((img) => {
      if (done.get(img)?.result) draw(img);
    });
  }
  function retranslateAll() {
    document.querySelectorAll(".mercurio-strato").forEach((l) => l.remove());
    document.querySelectorAll("img").forEach((img) => {
      done.delete(img);
      watcher.unobserve(img);
      watcher.observe(img);
    });
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    for (const [k, v] of Object.entries(changes)) cfg[k] = v.newValue ?? PREDEFINITE[k];
    if (changes.modello || changes.ollama) retranslateAll();
    else redrawAll();
  });
  function setOn(value) {
    if (on === value) return;
    on = value;
    if (on) {
      scan();
      retranslateAll();
    } else {
      queue.length = 0;
      redrawAll();
    }
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.to !== "pagina") return;
    if (msg.type === "ritraduci") retranslateAll();
    if (msg.type === "acceso") setOn(msg.on);
  });
  chrome.storage.sync.get(PREDEFINITE).then(async (v) => {
    cfg = { ...PREDEFINITE, ...v };
    scan();
    const r = await send({ to: "background", type: "stato" });
    setOn(!!r?.on);
  });
})();
