// src/impostazioni.js
var PREDEFINITE = {
  ollama: "http://localhost:11434",
  modello: "",
  // vuoto = automatico (preferisce TranslateGemma)
  opacita: 100,
  // percentuale
  testo: 100
  // dimensione del testo in percentuale
};

// src/background.js
var OFFSCREEN = "offscreen.html";
var creating = null;
async function ensureOffscreen() {
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (contexts.length) return;
  creating ??= chrome.offscreen.createDocument({
    url: OFFSCREEN,
    reasons: ["WORKERS"],
    justification: "Legge le scritte dei fumetti con PaddleOCR e le traduce con Ollama"
  }).finally(() => {
    creating = null;
  });
  await creating;
}
async function activeTabs() {
  return new Set((await chrome.storage.session.get({ schede: [] })).schede);
}
async function setTab(tabId, on) {
  const tabs = await activeTabs();
  if (on) tabs.add(tabId);
  else tabs.delete(tabId);
  await chrome.storage.session.set({ schede: [...tabs] });
  await chrome.action.setBadgeText({ tabId, text: on ? "ON" : "" });
  if (on) await chrome.action.setBadgeBackgroundColor({ tabId, color: "#fa1e4e" });
  chrome.tabs.sendMessage(tabId, { to: "pagina", type: "acceso", on }).catch(() => {
  });
}
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const tabs = await activeTabs();
  if (tabs.delete(tabId)) await chrome.storage.session.set({ schede: [...tabs] });
});
chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  if (info.status === "loading" && (await activeTabs()).has(tabId)) chrome.action.setBadgeText({ tabId, text: "ON" });
});
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg?.to !== "background") return;
  if (msg.type === "stato") {
    const tabId = msg.tabId ?? sender.tab?.id;
    activeTabs().then((t) => reply({ on: t.has(tabId) }));
    return true;
  }
  if (msg.type === "avvia" || msg.type === "ferma") {
    setTab(msg.tabId, msg.type === "avvia").then(() => reply({ ok: true }), (e) => reply({ error: String(e?.message || e) }));
    return true;
  }
  (async () => {
    const cfg = { ...PREDEFINITE, ...await chrome.storage.sync.get(PREDEFINITE) };
    await ensureOffscreen();
    for (let i = 0; ; i++) {
      try {
        return await chrome.runtime.sendMessage({ ...msg, cfg, to: "offscreen" });
      } catch (e) {
        if (i >= 20 || !String(e?.message).includes("Receiving end")) throw e;
        await new Promise((r) => setTimeout(r, 150));
      }
    }
  })().then(reply, (e) => reply({ error: String(e?.message || e) }));
  return true;
});
