var __defProp = Object.defineProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// ../../../../../../../home/claude/app-traduzione/estensione/node_modules/onnxruntime-web/dist/ort.webgpu.bundle.min.mjs
var ort_webgpu_bundle_min_exports = {};
__export(ort_webgpu_bundle_min_exports, {
  InferenceSession: () => bc,
  TRACE: () => Qa,
  TRACE_EVENT_BEGIN: () => Ge,
  TRACE_EVENT_END: () => $e,
  TRACE_FUNC_BEGIN: () => ot,
  TRACE_FUNC_END: () => at,
  Tensor: () => Le,
  default: () => $l,
  env: () => ee,
  registerBackend: () => rt
});
var Jr = Object.defineProperty;
var dc = Object.getOwnPropertyDescriptor;
var lc = Object.getOwnPropertyNames;
var pc = Object.prototype.hasOwnProperty;
var Xr = ((a) => typeof __require < "u" ? __require : typeof Proxy < "u" ? new Proxy(a, { get: (r, s) => (typeof __require < "u" ? __require : r)[s] }) : a)(function(a) {
  if (typeof __require < "u") return __require.apply(this, arguments);
  throw Error('Dynamic require of "' + a + '" is not supported');
});
var G = (a, r, s) => () => {
  if (s) throw s[0];
  try {
    return a && (r = a(a = 0)), r;
  } catch (f) {
    throw s = [f], f;
  }
};
var At = (a, r) => {
  for (var s in r) Jr(a, s, { get: r[s], enumerable: true });
};
var mc = (a, r, s, f) => {
  if (r && typeof r == "object" || typeof r == "function") for (let i of lc(r)) !pc.call(a, i) && i !== s && Jr(a, i, { get: () => r[i], enumerable: !(f = dc(r, i)) || f.enumerable });
  return a;
};
var Ht = (a) => mc(Jr({}, "__esModule", { value: true }), a);
var qt;
var tt;
var rt;
var hc;
var Da;
var Zr = G(() => {
  "use strict";
  qt = /* @__PURE__ */ new Map(), tt = [], rt = (a, r, s) => {
    if (r && typeof r.init == "function" && typeof r.createInferenceSessionHandler == "function") {
      let f = qt.get(a);
      if (f === void 0) qt.set(a, { backend: r, priority: s });
      else {
        if (f.priority > s) return;
        if (f.priority === s && f.backend !== r) throw new Error(`cannot register backend "${a}" using priority ${s}`);
      }
      if (s >= 0) {
        let i = tt.indexOf(a);
        i !== -1 && tt.splice(i, 1);
        for (let p = 0; p < tt.length; p++) if (qt.get(tt[p]).priority <= s) {
          tt.splice(p, 0, a);
          return;
        }
        tt.push(a);
      }
      return;
    }
    throw new TypeError("not a valid backend");
  }, hc = async (a) => {
    let r = qt.get(a);
    if (!r) return "backend not found.";
    if (r.initialized) return r.backend;
    if (r.aborted) return r.error;
    {
      let s = !!r.initPromise;
      try {
        return s || (r.initPromise = r.backend.init(a)), await r.initPromise, r.initialized = true, r.backend;
      } catch (f) {
        return s || (r.error = `${f}`, r.aborted = true), r.error;
      } finally {
        delete r.initPromise;
      }
    }
  }, Da = async (a) => {
    let r = a.executionProviders || [], s = r.map((g) => typeof g == "string" ? g : g.name), f = s.length === 0 ? tt : s, i, p = [], l = /* @__PURE__ */ new Set();
    for (let g of f) {
      let w = await hc(g);
      typeof w == "string" ? p.push({ name: g, err: w }) : (i || (i = w), i === w && l.add(g));
    }
    if (!i) throw new Error(`no available backend found. ERR: ${p.map((g) => `[${g.name}] ${g.err}`).join(", ")}`);
    for (let { name: g, err: w } of p) s.includes(g) && console.warn(`removing requested execution provider "${g}" from session options because it is not available: ${w}`);
    let b = r.filter((g) => l.has(typeof g == "string" ? g : g.name));
    return [i, new Proxy(a, { get: (g, w) => w === "executionProviders" ? b : Reflect.get(g, w) })];
  };
});
var Pa = G(() => {
  "use strict";
  Zr();
});
var Ua;
var _a = G(() => {
  "use strict";
  Ua = "1.30.0";
});
var Ra;
var ie;
var Kr = G(() => {
  "use strict";
  _a();
  Ra = "warning", ie = { wasm: {}, webgl: {}, webgpu: {}, versions: { common: Ua }, set logLevel(a) {
    if (a !== void 0) {
      if (typeof a != "string" || ["verbose", "info", "warning", "error", "fatal"].indexOf(a) === -1) throw new Error(`Unsupported logging level: ${a}`);
      Ra = a;
    }
  }, get logLevel() {
    return Ra;
  } };
  Object.defineProperty(ie, "logLevel", { enumerable: true });
});
var ee;
var Na = G(() => {
  "use strict";
  Kr();
  ee = ie;
});
var Wa;
var ka;
var Fa = G(() => {
  "use strict";
  Wa = (a, r) => {
    let s = typeof document < "u" ? document.createElement("canvas") : new OffscreenCanvas(1, 1);
    s.width = a.dims[3], s.height = a.dims[2];
    let f = s.getContext("2d");
    if (f != null) {
      let i, p;
      r?.tensorLayout !== void 0 && r.tensorLayout === "NHWC" ? (i = a.dims[2], p = a.dims[3]) : (i = a.dims[3], p = a.dims[2]);
      let l = r?.format !== void 0 ? r.format : "RGB", b = r?.norm, g, w;
      b === void 0 || b.mean === void 0 ? g = [255, 255, 255, 255] : typeof b.mean == "number" ? g = [b.mean, b.mean, b.mean, b.mean] : (g = [b.mean[0], b.mean[1], b.mean[2], 0], b.mean[3] !== void 0 && (g[3] = b.mean[3])), b === void 0 || b.bias === void 0 ? w = [0, 0, 0, 0] : typeof b.bias == "number" ? w = [b.bias, b.bias, b.bias, b.bias] : (w = [b.bias[0], b.bias[1], b.bias[2], 0], b.bias[3] !== void 0 && (w[3] = b.bias[3]));
      let S = p * i, v = 0, T = S, A = S * 2, C = -1;
      l === "RGBA" ? (v = 0, T = S, A = S * 2, C = S * 3) : l === "RGB" ? (v = 0, T = S, A = S * 2) : l === "RBG" && (v = 0, A = S, T = S * 2);
      for (let _ = 0; _ < p; _++) for (let k = 0; k < i; k++) {
        let U = (a.data[v++] - w[0]) * g[0], M = (a.data[T++] - w[1]) * g[1], Y = (a.data[A++] - w[2]) * g[2], O = C === -1 ? 255 : (a.data[C++] - w[3]) * g[3];
        f.fillStyle = "rgba(" + U + "," + M + "," + Y + "," + O + ")", f.fillRect(k, _, 1, 1);
      }
      if ("toDataURL" in s) return s.toDataURL();
      throw new Error("toDataURL is not supported");
    } else throw new Error("Can not access image data");
  }, ka = (a, r) => {
    let s = typeof document < "u" ? document.createElement("canvas").getContext("2d") : new OffscreenCanvas(1, 1).getContext("2d"), f;
    if (s != null) {
      let i, p, l;
      r?.tensorLayout !== void 0 && r.tensorLayout === "NHWC" ? (i = a.dims[2], p = a.dims[1], l = a.dims[3]) : (i = a.dims[3], p = a.dims[2], l = a.dims[1]);
      let b = r !== void 0 && r.format !== void 0 ? r.format : "RGB", g = r?.norm, w, S;
      g === void 0 || g.mean === void 0 ? w = [255, 255, 255, 255] : typeof g.mean == "number" ? w = [g.mean, g.mean, g.mean, g.mean] : (w = [g.mean[0], g.mean[1], g.mean[2], 255], g.mean[3] !== void 0 && (w[3] = g.mean[3])), g === void 0 || g.bias === void 0 ? S = [0, 0, 0, 0] : typeof g.bias == "number" ? S = [g.bias, g.bias, g.bias, g.bias] : (S = [g.bias[0], g.bias[1], g.bias[2], 0], g.bias[3] !== void 0 && (S[3] = g.bias[3]));
      let v = p * i;
      if (r !== void 0 && (r.format !== void 0 && l === 4 && r.format !== "RGBA" || l === 3 && r.format !== "RGB" && r.format !== "BGR")) throw new Error("Tensor format doesn't match input tensor dims");
      let T = 4, A = 0, C = 1, _ = 2, k = 3, U = 0, M = v, Y = v * 2, O = -1;
      b === "RGBA" ? (U = 0, M = v, Y = v * 2, O = v * 3) : b === "RGB" ? (U = 0, M = v, Y = v * 2) : b === "RBG" && (U = 0, Y = v, M = v * 2), f = s.createImageData(i, p);
      for (let $ = 0; $ < p * i; A += T, C += T, _ += T, k += T, $++) f.data[A] = (a.data[U++] - S[0]) * w[0], f.data[C] = (a.data[M++] - S[1]) * w[1], f.data[_] = (a.data[Y++] - S[2]) * w[2], f.data[k] = O === -1 ? 255 : (a.data[O++] - S[3]) * w[3];
    } else throw new Error("Can not access image data");
    return f;
  };
});
var Qr;
var Ga;
var $a;
var za;
var Va;
var ja;
var Ha = G(() => {
  "use strict";
  Yt();
  Qr = (a, r) => {
    if (a === void 0) throw new Error("Image buffer must be defined");
    if (r.height === void 0 || r.width === void 0) throw new Error("Image height and width must be defined");
    if (r.tensorLayout === "NHWC") throw new Error("NHWC Tensor layout is not supported yet");
    let { height: s, width: f } = r, i = r.norm ?? { mean: 255, bias: 0 }, p, l;
    typeof i.mean == "number" ? p = [i.mean, i.mean, i.mean, i.mean] : p = [i.mean[0], i.mean[1], i.mean[2], i.mean[3] ?? 255], typeof i.bias == "number" ? l = [i.bias, i.bias, i.bias, i.bias] : l = [i.bias[0], i.bias[1], i.bias[2], i.bias[3] ?? 0];
    let b = r.format !== void 0 ? r.format : "RGBA", g = r.tensorFormat !== void 0 && r.tensorFormat !== void 0 ? r.tensorFormat : "RGB", w = s * f, S = g === "RGBA" ? new Float32Array(w * 4) : new Float32Array(w * 3), v = 4, T = 0, A = 1, C = 2, _ = 3, k = 0, U = w, M = w * 2, Y = -1;
    b === "RGB" && (v = 3, T = 0, A = 1, C = 2, _ = -1), g === "RGBA" ? Y = w * 3 : g === "RBG" ? (k = 0, M = w, U = w * 2) : g === "BGR" && (M = 0, U = w, k = w * 2);
    for (let $ = 0; $ < w; $++, T += v, C += v, A += v, _ += v) S[k++] = (a[T] + l[0]) / p[0], S[U++] = (a[A] + l[1]) / p[1], S[M++] = (a[C] + l[2]) / p[2], Y !== -1 && _ !== -1 && (S[Y++] = (a[_] + l[3]) / p[3]);
    return g === "RGBA" ? new ce("float32", S, [1, 4, s, f]) : new ce("float32", S, [1, 3, s, f]);
  }, Ga = async (a, r) => {
    let s = typeof HTMLImageElement < "u" && a instanceof HTMLImageElement, f = typeof ImageData < "u" && a instanceof ImageData, i = typeof ImageBitmap < "u" && a instanceof ImageBitmap, p = typeof a == "string", l, b = r ?? {}, g = () => {
      if (typeof document < "u") return document.createElement("canvas");
      if (typeof OffscreenCanvas < "u") return new OffscreenCanvas(1, 1);
      throw new Error("Canvas is not supported");
    }, w = (S) => typeof HTMLCanvasElement < "u" && S instanceof HTMLCanvasElement || S instanceof OffscreenCanvas ? S.getContext("2d") : null;
    if (s) {
      let S = g();
      S.width = a.width, S.height = a.height;
      let v = w(S);
      if (v != null) {
        let T = a.height, A = a.width;
        if (r !== void 0 && r.resizedHeight !== void 0 && r.resizedWidth !== void 0 && (T = r.resizedHeight, A = r.resizedWidth), r !== void 0) {
          if (b = r, r.tensorFormat !== void 0) throw new Error("Image input config format must be RGBA for HTMLImageElement");
          b.tensorFormat = "RGBA", b.height = T, b.width = A;
        } else b.tensorFormat = "RGBA", b.height = T, b.width = A;
        v.drawImage(a, 0, 0), l = v.getImageData(0, 0, A, T).data;
      } else throw new Error("Can not access image data");
    } else if (f) {
      let S, v;
      if (r !== void 0 && r.resizedWidth !== void 0 && r.resizedHeight !== void 0 ? (S = r.resizedHeight, v = r.resizedWidth) : (S = a.height, v = a.width), r !== void 0 && (b = r), b.format = "RGBA", b.height = S, b.width = v, r !== void 0) {
        let T = g();
        T.width = v, T.height = S;
        let A = w(T);
        if (A != null) A.putImageData(a, 0, 0), l = A.getImageData(0, 0, v, S).data;
        else throw new Error("Can not access image data");
      } else l = a.data;
    } else if (i) {
      if (r === void 0) throw new Error("Please provide image config with format for Imagebitmap");
      let S = g();
      S.width = a.width, S.height = a.height;
      let v = w(S);
      if (v != null) {
        let T = a.height, A = a.width;
        return v.drawImage(a, 0, 0, A, T), l = v.getImageData(0, 0, A, T).data, b.height = T, b.width = A, Qr(l, b);
      } else throw new Error("Can not access image data");
    } else {
      if (p) return new Promise((S, v) => {
        let T = g(), A = w(T);
        if (!a || !A) return v();
        let C = new Image();
        C.crossOrigin = "Anonymous", C.src = a, C.onload = () => {
          T.width = C.width, T.height = C.height, A.drawImage(C, 0, 0, T.width, T.height);
          let _ = A.getImageData(0, 0, T.width, T.height);
          b.height = T.height, b.width = T.width, S(Qr(_.data, b));
        };
      });
      throw new Error("Input data provided is not supported - aborted tensor creation");
    }
    if (l !== void 0) return Qr(l, b);
    throw new Error("Input data provided is not supported - aborted tensor creation");
  }, $a = (a, r) => {
    let { width: s, height: f, download: i, dispose: p } = r, l = [1, f, s, 4];
    return new ce({ location: "texture", type: "float32", texture: a, dims: l, download: i, dispose: p });
  }, za = (a, r) => {
    let { dataType: s, dims: f, download: i, dispose: p } = r;
    return new ce({ location: "gpu-buffer", type: s ?? "float32", gpuBuffer: a, dims: f, download: i, dispose: p });
  }, Va = (a, r) => {
    let { dataType: s, dims: f, download: i, dispose: p } = r;
    return new ce({ location: "ml-tensor", type: s ?? "float32", mlTensor: a, dims: f, download: i, dispose: p });
  }, ja = (a, r, s) => new ce({ location: "cpu-pinned", type: a, data: r, dims: s ?? [r.length] });
});
var nt;
var It;
var qa;
var Ya;
var Ja = G(() => {
  "use strict";
  nt = /* @__PURE__ */ new Map([["float32", Float32Array], ["uint8", Uint8Array], ["int8", Int8Array], ["uint16", Uint16Array], ["int16", Int16Array], ["int32", Int32Array], ["bool", Uint8Array], ["float64", Float64Array], ["uint32", Uint32Array], ["int4", Uint8Array], ["uint4", Uint8Array]]), It = /* @__PURE__ */ new Map([[Float32Array, "float32"], [Uint8Array, "uint8"], [Int8Array, "int8"], [Uint16Array, "uint16"], [Int16Array, "int16"], [Int32Array, "int32"], [Float64Array, "float64"], [Uint32Array, "uint32"]]), qa = false, Ya = () => {
    if (!qa) {
      qa = true;
      let a = typeof BigInt64Array < "u" && BigInt64Array.from, r = typeof BigUint64Array < "u" && BigUint64Array.from, s = globalThis.Float16Array, f = typeof s < "u" && s.from;
      a && (nt.set("int64", BigInt64Array), It.set(BigInt64Array, "int64")), r && (nt.set("uint64", BigUint64Array), It.set(BigUint64Array, "uint64")), f ? (nt.set("float16", s), It.set(s, "float16")) : nt.set("float16", Uint16Array);
    }
  };
});
var Xa;
var Za;
var Ka = G(() => {
  "use strict";
  Yt();
  Xa = (a) => {
    let r = 1;
    for (let s = 0; s < a.length; s++) {
      let f = a[s];
      if (typeof f != "number" || !Number.isSafeInteger(f)) throw new TypeError(`dims[${s}] must be an integer, got: ${f}`);
      if (f < 0) throw new RangeError(`dims[${s}] must be a non-negative integer, got: ${f}`);
      r *= f;
    }
    return r;
  }, Za = (a, r) => {
    switch (a.location) {
      case "cpu":
        return new ce(a.type, a.data, r);
      case "cpu-pinned":
        return new ce({ location: "cpu-pinned", data: a.data, type: a.type, dims: r });
      case "texture":
        return new ce({ location: "texture", texture: a.texture, type: a.type, dims: r });
      case "gpu-buffer":
        return new ce({ location: "gpu-buffer", gpuBuffer: a.gpuBuffer, type: a.type, dims: r });
      case "ml-tensor":
        return new ce({ location: "ml-tensor", mlTensor: a.mlTensor, type: a.type, dims: r });
      default:
        throw new Error(`tensorReshape: tensor location ${a.location} is not supported`);
    }
  };
});
var ce;
var Yt = G(() => {
  "use strict";
  Fa();
  Ha();
  Ja();
  Ka();
  ce = class {
    constructor(r, s, f) {
      Ya();
      let i, p;
      if (typeof r == "object" && "location" in r) switch (this.dataLocation = r.location, i = r.type, p = r.dims, r.location) {
        case "cpu-pinned": {
          let b = nt.get(i);
          if (!b) throw new TypeError(`unsupported type "${i}" to create tensor from pinned buffer`);
          if (!(r.data instanceof b)) throw new TypeError(`buffer should be of type ${b.name}`);
          this.cpuData = r.data;
          break;
        }
        case "texture": {
          if (i !== "float32") throw new TypeError(`unsupported type "${i}" to create tensor from texture`);
          this.gpuTextureData = r.texture, this.downloader = r.download, this.disposer = r.dispose;
          break;
        }
        case "gpu-buffer": {
          if (i !== "float32" && i !== "float16" && i !== "int32" && i !== "int64" && i !== "uint32" && i !== "uint8" && i !== "bool" && i !== "uint4" && i !== "int4") throw new TypeError(`unsupported type "${i}" to create tensor from gpu buffer`);
          this.gpuBufferData = r.gpuBuffer, this.downloader = r.download, this.disposer = r.dispose;
          break;
        }
        case "ml-tensor": {
          if (i !== "float32" && i !== "float16" && i !== "int32" && i !== "int64" && i !== "uint32" && i !== "uint64" && i !== "int8" && i !== "uint8" && i !== "bool" && i !== "uint4" && i !== "int4") throw new TypeError(`unsupported type "${i}" to create tensor from MLTensor`);
          this.mlTensorData = r.mlTensor, this.downloader = r.download, this.disposer = r.dispose;
          break;
        }
        default:
          throw new Error(`Tensor constructor: unsupported location '${this.dataLocation}'`);
      }
      else {
        let b, g;
        if (typeof r == "string") if (i = r, g = f, r === "string") {
          if (!Array.isArray(s)) throw new TypeError("A string tensor's data must be a string array.");
          b = s;
        } else {
          let w = nt.get(r);
          if (w === void 0) throw new TypeError(`Unsupported tensor type: ${r}.`);
          if (Array.isArray(s)) {
            if (r === "float16" && w === Uint16Array || r === "uint4" || r === "int4") throw new TypeError(`Creating a ${r} tensor from number array is not supported. Please use ${w.name} as data.`);
            r === "uint64" || r === "int64" ? b = w.from(s, BigInt) : b = w.from(s);
          } else if (s instanceof w) b = s;
          else if (s instanceof Uint8ClampedArray) if (r === "uint8") b = Uint8Array.from(s);
          else throw new TypeError("A Uint8ClampedArray tensor's data must be type of uint8");
          else if (r === "float16" && s instanceof Uint16Array && w !== Uint16Array) b = new globalThis.Float16Array(s.buffer, s.byteOffset, s.length);
          else throw new TypeError(`A ${i} tensor's data must be type of ${w}`);
        }
        else if (g = s, Array.isArray(r)) {
          if (r.length === 0) throw new TypeError("Tensor type cannot be inferred from an empty array.");
          let w = typeof r[0];
          if (w === "string") i = "string", b = r;
          else if (w === "boolean") i = "bool", b = Uint8Array.from(r);
          else throw new TypeError(`Invalid element type of data array: ${w}.`);
        } else if (r instanceof Uint8ClampedArray) i = "uint8", b = Uint8Array.from(r);
        else {
          let w = It.get(r.constructor);
          if (w === void 0) throw new TypeError(`Unsupported type for tensor data: ${r.constructor}.`);
          i = w, b = r;
        }
        if (g === void 0) g = [b.length];
        else if (!Array.isArray(g)) throw new TypeError("A tensor's dims must be a number array");
        p = g, this.cpuData = b, this.dataLocation = "cpu";
      }
      let l = Xa(p);
      if (this.cpuData && l !== this.cpuData.length && !((i === "uint4" || i === "int4") && Math.ceil(l / 2) === this.cpuData.length)) throw new Error(`Tensor's size(${l}) does not match data length(${this.cpuData.length}).`);
      this.type = i, this.dims = p, this.size = l;
    }
    static async fromImage(r, s) {
      return Ga(r, s);
    }
    static fromTexture(r, s) {
      return $a(r, s);
    }
    static fromGpuBuffer(r, s) {
      return za(r, s);
    }
    static fromMLTensor(r, s) {
      return Va(r, s);
    }
    static fromPinnedBuffer(r, s, f) {
      return ja(r, s, f);
    }
    toDataURL(r) {
      return Wa(this, r);
    }
    toImageData(r) {
      return ka(this, r);
    }
    get data() {
      if (this.ensureValid(), !this.cpuData) throw new Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");
      return this.cpuData;
    }
    get location() {
      return this.dataLocation;
    }
    get texture() {
      if (this.ensureValid(), !this.gpuTextureData) throw new Error("The data is not stored as a WebGL texture.");
      return this.gpuTextureData;
    }
    get gpuBuffer() {
      if (this.ensureValid(), !this.gpuBufferData) throw new Error("The data is not stored as a WebGPU buffer.");
      return this.gpuBufferData;
    }
    get mlTensor() {
      if (this.ensureValid(), !this.mlTensorData) throw new Error("The data is not stored as a WebNN MLTensor.");
      return this.mlTensorData;
    }
    async getData(r) {
      switch (this.ensureValid(), this.dataLocation) {
        case "cpu":
        case "cpu-pinned":
          return this.data;
        case "texture":
        case "gpu-buffer":
        case "ml-tensor": {
          if (!this.downloader) throw new Error("The current tensor is not created with a specified data downloader.");
          if (this.isDownloading) throw new Error("The current tensor is being downloaded.");
          try {
            this.isDownloading = true;
            let s = await this.downloader();
            return this.downloader = void 0, this.dataLocation = "cpu", this.cpuData = s, r && this.disposer && (this.disposer(), this.disposer = void 0), s;
          } finally {
            this.isDownloading = false;
          }
        }
        default:
          throw new Error(`cannot get data from location: ${this.dataLocation}`);
      }
    }
    dispose() {
      if (this.isDownloading) throw new Error("The current tensor is being downloaded.");
      this.disposer && (this.disposer(), this.disposer = void 0), this.cpuData = void 0, this.gpuTextureData = void 0, this.gpuBufferData = void 0, this.mlTensorData = void 0, this.downloader = void 0, this.isDownloading = void 0, this.dataLocation = "none";
    }
    ensureValid() {
      if (this.dataLocation === "none") throw new Error("The tensor is disposed.");
    }
    reshape(r) {
      if (this.ensureValid(), this.downloader || this.disposer) throw new Error("Cannot reshape a tensor that owns GPU resource.");
      return Za(this, r);
    }
  };
});
var Le;
var en = G(() => {
  "use strict";
  Yt();
  Le = ce;
});
var Qa;
var es;
var ot;
var at;
var Ge;
var $e;
var tn = G(() => {
  "use strict";
  Kr();
  Qa = (a, r) => {
    (typeof ie.trace > "u" ? !ie.wasm.trace : !ie.trace) || console.timeStamp(`${a}::ORT::${r}`);
  }, es = (a, r) => {
    let s = new Error().stack?.split(/\r\n|\r|\n/g) || [], f = false;
    for (let i = 0; i < s.length; i++) {
      if (f && !s[i].includes("TRACE_FUNC")) {
        let p = `FUNC_${a}::${s[i].trim().split(" ")[1]}`;
        r && (p += `::${r}`), Qa("CPU", p);
        return;
      }
      s[i].includes("TRACE_FUNC") && (f = true);
    }
  }, ot = (a) => {
    (typeof ie.trace > "u" ? !ie.wasm.trace : !ie.trace) || es("BEGIN", a);
  }, at = (a) => {
    (typeof ie.trace > "u" ? !ie.wasm.trace : !ie.trace) || es("END", a);
  }, Ge = (a) => {
    (typeof ie.trace > "u" ? !ie.wasm.trace : !ie.trace) || console.time(`ORT::${a}`);
  }, $e = (a) => {
    (typeof ie.trace > "u" ? !ie.wasm.trace : !ie.trace) || console.timeEnd(`ORT::${a}`);
  };
});
var Jt;
var ts = G(() => {
  "use strict";
  Zr();
  en();
  tn();
  Jt = class a {
    constructor(r) {
      this.handler = r;
    }
    async run(r, s, f) {
      ot(), Ge("InferenceSession.run");
      let i = {}, p = {};
      if (typeof r != "object" || r === null || r instanceof Le || Array.isArray(r)) throw new TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");
      let l = true;
      if (typeof s == "object") {
        if (s === null) throw new TypeError("Unexpected argument[1]: cannot be null.");
        if (s instanceof Le) throw new TypeError("'fetches' cannot be a Tensor");
        if (Array.isArray(s)) {
          if (s.length === 0) throw new TypeError("'fetches' cannot be an empty array.");
          l = false;
          for (let w of s) {
            if (typeof w != "string") throw new TypeError("'fetches' must be a string array or an object.");
            if (this.outputNames.indexOf(w) === -1) throw new RangeError(`'fetches' contains invalid output name: ${w}.`);
            i[w] = null;
          }
          if (typeof f == "object" && f !== null) p = f;
          else if (typeof f < "u") throw new TypeError("'options' must be an object.");
        } else {
          let w = false, S = Object.getOwnPropertyNames(s);
          for (let v of this.outputNames) if (S.indexOf(v) !== -1) {
            let T = s[v];
            (T === null || T instanceof Le) && (w = true, l = false, i[v] = T);
          }
          if (w) {
            if (typeof f == "object" && f !== null) p = f;
            else if (typeof f < "u") throw new TypeError("'options' must be an object.");
          } else p = s;
        }
      } else if (typeof s < "u") throw new TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");
      for (let w of this.inputNames) if (typeof r[w] > "u") throw new Error(`input '${w}' is missing in 'feeds'.`);
      if (l) for (let w of this.outputNames) i[w] = null;
      let b = await this.handler.run(r, i, p), g = {};
      for (let w in b) if (Object.hasOwnProperty.call(b, w)) {
        let S = b[w];
        S instanceof Le ? g[w] = S : g[w] = new Le(S.type, S.data, S.dims);
      }
      return $e("InferenceSession.run"), at(), g;
    }
    async release() {
      return this.handler.dispose();
    }
    static async create(r, s, f, i) {
      ot(), Ge("InferenceSession.create");
      let p, l = {};
      if (typeof r == "string") {
        if (p = r, typeof s == "object" && s !== null) l = s;
        else if (typeof s < "u") throw new TypeError("'options' must be an object.");
      } else if (r instanceof Uint8Array) {
        if (p = r, typeof s == "object" && s !== null) l = s;
        else if (typeof s < "u") throw new TypeError("'options' must be an object.");
      } else if (r instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && r instanceof SharedArrayBuffer) {
        let S = r, v = 0, T = r.byteLength;
        if (typeof s == "object" && s !== null) l = s;
        else if (typeof s == "number") {
          if (v = s, !Number.isSafeInteger(v)) throw new RangeError("'byteOffset' must be an integer.");
          if (v < 0 || v >= S.byteLength) throw new RangeError(`'byteOffset' is out of range [0, ${S.byteLength}).`);
          if (T = r.byteLength - v, typeof f == "number") {
            if (T = f, !Number.isSafeInteger(T)) throw new RangeError("'byteLength' must be an integer.");
            if (T <= 0 || v + T > S.byteLength) throw new RangeError(`'byteLength' is out of range (0, ${S.byteLength - v}].`);
            if (typeof i == "object" && i !== null) l = i;
            else if (typeof i < "u") throw new TypeError("'options' must be an object.");
          } else if (typeof f < "u") throw new TypeError("'byteLength' must be a number.");
        } else if (typeof s < "u") throw new TypeError("'options' must be an object.");
        p = new Uint8Array(S, v, T);
      } else throw new TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");
      let [b, g] = await Da(l), w = await b.createInferenceSessionHandler(p, g);
      return $e("InferenceSession.create"), at(), new a(w);
    }
    startProfiling() {
      this.handler.startProfiling();
    }
    endProfiling() {
      this.handler.endProfiling();
    }
    get inputNames() {
      return this.handler.inputNames;
    }
    get outputNames() {
      return this.handler.outputNames;
    }
    get inputMetadata() {
      return this.handler.inputMetadata;
    }
    get outputMetadata() {
      return this.handler.outputMetadata;
    }
  };
});
var bc;
var rs = G(() => {
  "use strict";
  ts();
  bc = Jt;
});
var ns = G(() => {
  "use strict";
});
var os = G(() => {
  "use strict";
});
var as = G(() => {
  "use strict";
});
var ss = G(() => {
  "use strict";
});
var rn = {};
At(rn, { InferenceSession: () => bc, TRACE: () => Qa, TRACE_EVENT_BEGIN: () => Ge, TRACE_EVENT_END: () => $e, TRACE_FUNC_BEGIN: () => ot, TRACE_FUNC_END: () => at, Tensor: () => Le, env: () => ee, registerBackend: () => rt });
var ze = G(() => {
  "use strict";
  Pa();
  Na();
  rs();
  en();
  ns();
  os();
  tn();
  as();
  ss();
});
var Xt = G(() => {
  "use strict";
});
var cs = {};
At(cs, { default: () => gc });
var us;
var fs;
var gc;
var ds = G(() => {
  "use strict";
  nn();
  Ve();
  Zt();
  us = "ort-wasm-proxy-worker", fs = globalThis.self?.name === us;
  fs && (self.onmessage = (a) => {
    let { type: r, in: s } = a.data;
    try {
      switch (r) {
        case "init-wasm":
          Kt(s.wasm).then(() => {
            Qt(s).then(() => {
              postMessage({ type: r });
            }, (f) => {
              postMessage({ type: r, err: f });
            });
          }, (f) => {
            postMessage({ type: r, err: f });
          });
          break;
        case "init-ep": {
          let { epName: f, env: i } = s;
          er(i, f).then(() => {
            postMessage({ type: r });
          }, (p) => {
            postMessage({ type: r, err: p });
          });
          break;
        }
        case "copy-from": {
          let { buffer: f } = s, i = Lt(f);
          postMessage({ type: r, out: i });
          break;
        }
        case "create": {
          let { model: f, options: i } = s;
          tr(f, i).then((p) => {
            postMessage({ type: r, out: p });
          }, (p) => {
            postMessage({ type: r, err: p });
          });
          break;
        }
        case "release":
          rr(s), postMessage({ type: r });
          break;
        case "run": {
          let { sessionId: f, inputIndices: i, inputs: p, outputIndices: l, options: b } = s;
          nr(f, i, p, l, new Array(l.length).fill(null), b).then((g) => {
            g.some((w) => w[3] !== "cpu") ? postMessage({ type: r, err: "Proxy does not support non-cpu tensor location." }) : postMessage({ type: r, out: g }, ar([...p, ...g]));
          }, (g) => {
            postMessage({ type: r, err: g });
          });
          break;
        }
        case "end-profiling":
          or(s), postMessage({ type: r });
          break;
        default:
      }
    } catch (f) {
      postMessage({ type: r, err: f });
    }
  });
  gc = fs ? null : (a) => new Worker(a ?? ye, { type: "module", name: us });
});
var ps = {};
At(ps, { default: () => yc });
async function ls(a = {}) {
  var r = a, s = !!globalThis.window, f = !!globalThis.WorkerGlobalScope, i = f && self.name?.startsWith("em-pthread");
  r.mountExternalData = (e, t) => {
    e.startsWith("./") && (e = e.substring(2)), (r.ed || (r.ed = /* @__PURE__ */ new Map())).set(e, t);
  }, r.unmountExternalData = () => {
    delete r.ed, delete r.Te, delete r.Se, delete r.Ue;
  }, globalThis.SharedArrayBuffer ?? new WebAssembly.Memory({ initial: 0, maximum: 0, shared: true }).buffer.constructor;
  let p = () => {
    let e = (t) => (...n) => {
      let o = Me;
      return n = t(...n), Me != o ? new Promise((u, c) => {
        Cr = { resolve: u, reject: c };
      }) : n;
    };
    (() => {
      for (let t of ["_OrtAppendExecutionProvider", "_OrtCreateSession", "_OrtRun", "_OrtRunWithBinding", "_OrtBindInput"]) r[t] = e(r[t]);
    })(), typeof jsepRunAsync < "u" && (r._OrtRun = jsepRunAsync(r._OrtRun), r._OrtRunWithBinding = jsepRunAsync(r._OrtRunWithBinding)), p = void 0;
  };
  r.asyncInit = () => {
    p?.();
  };
  var l, b, g = (e, t) => {
    throw t;
  }, w = import.meta.url, S = "";
  if (s || f) {
    try {
      S = new URL(".", w).href;
    } catch {
    }
    f && (b = (e) => {
      var t = new XMLHttpRequest();
      return t.open("GET", e, false), t.responseType = "arraybuffer", t.send(null), new Uint8Array(t.response);
    }), l = async (e) => {
      if (oe(e)) return new Promise((n, o) => {
        var u = new XMLHttpRequest();
        u.open("GET", e, true), u.responseType = "arraybuffer", u.onload = () => {
          u.status == 200 || u.status == 0 && u.response ? n(u.response) : o(u.status);
        }, u.onerror = o, u.send(null);
      });
      var t = await fetch(e, { credentials: "same-origin" });
      if (t.ok) return t.arrayBuffer();
      throw Error(t.status + " : " + t.url);
    };
  }
  var v, T, A, C, _, k, U = console.log.bind(console), M = console.error.bind(console), Y = U, O = M, $ = false, oe = (e) => e.startsWith("file://");
  function d() {
    ke.buffer != Z.buffer && se();
  }
  if (i) {
    let e = function(t) {
      try {
        var n = t.data, o = n.$c;
        if (o === "load") {
          let u = [];
          self.onmessage = (c) => u.push(c), k = () => {
            postMessage({ $c: "loaded" });
            for (let c of u) e(c);
            self.onmessage = e;
          };
          for (let c of n.ue) r[c] && !r[c].proxy || (r[c] = (...h) => {
            postMessage({ $c: "callHandler", te: c, args: h });
          }, c == "print" && (Y = r[c]), c == "printErr" && (O = r[c]));
          ke = n.Me, se(), T = n.Ne, wt(), jt();
        } else if (o === "run") {
          (function(u) {
            var c = (d(), E)[u + 52 >>> 2 >>> 0];
            u = (d(), E)[u + 56 >>> 2 >>> 0], Fo(c, c - u), D(c);
          })(n.Xc), zr(n.Xc, 0, 0, 1, 0, 0), wn(), Br(n.Xc), te || (vo(), te = true);
          try {
            ei(n.ze, n.kd);
          } catch (u) {
            if (u != "unwind") throw u;
          }
        } else n.target !== "setimmediate" && (o === "checkMailbox" ? te && _t() : o && (O(`worker: received unknown command ${o}`), O(n)));
      } catch (u) {
        throw _o(), u;
      }
    };
    var Vc = e, te = false;
    self.onunhandledrejection = (t) => {
      throw t.reason || t;
    }, self.onmessage = e;
  }
  var Z, X, De, K, I, E, R, ae, pe, J, ge, ne = false;
  function se() {
    var e = ke.buffer;
    r.HEAP8 = Z = new Int8Array(e), De = new Int16Array(e), r.HEAPU8 = X = new Uint8Array(e), K = new Uint16Array(e), r.HEAP32 = I = new Int32Array(e), r.HEAPU32 = E = new Uint32Array(e), R = new Float32Array(e), ae = new Float64Array(e), pe = new BigInt64Array(e), J = new BigUint64Array(e);
  }
  function wr() {
    ne = true, i ? k() : Ne.hc();
  }
  function we(e) {
    throw O(e = "Aborted(" + e + ")"), $ = true, e = new WebAssembly.RuntimeError(e + ". Build with -sASSERTIONS for more info."), _?.(e), e;
  }
  function qe() {
    return { a: { qa: Af, f: ti, K: ri, k: ni, p: oi, l: ai, fa: si, b: ii, da: ui, gc: An, q: fi, ea: On, Ua: Mn, cc: Cn, ec: Dn, Va: Pn, Sa: Un, La: _n, Ra: Rn, oa: Nn, dc: Wn, ac: kn, Ta: Fn, bc: Gn, _a: ci, Ba: li, Xb: pi, Vb: hi, Aa: gi, O: yi, J: wi, Wb: Ti, ka: Li, Yb: Bi, Oa: Oi, _b: Ci, Ea: Di, Tb: Pi, Ca: Ui, Na: Br, Xa: _i, U: ki, n: Vi, c: Ir, qb: ji, w: Hi, N: qi, A: Yi, j: Ji, o: Jn, rb: Xi, H: Zi, T: Ki, g: Qi, u: eu, m: tu, i: ru, Ia: nu, Ja: ou, Ka: au, Ga: Qn, Ha: eo, Ub: to, ab: iu, Za: cu, Z: du, pb: lu, Da: pu, Ya: uu, X: mu, Wa: hu, $b: bu, G: su, db: gu, _: yu, pa: Ft, Zb: Tu, cb: wu, bb: vu, lb: Uu, z: _u, sa: Ru, ra: Nu, nb: Wu, Y: ku, v: Fu, kb: Gu, jb: $u, ib: zu, mb: Vu, gb: ju, fb: Hu, eb: qu, Pa: po, Qa: mo, fc: vr, W: ho, Fa: bo, ma: go, Ma: yo, la: wo, Fb: fc, va: nc, Gb: uc, wa: rc, E: zf, e: Of, r: Lf, x: If, C: kf, Ib: Qf, ca: Kf, D: Df, xa: ec, aa: oc, ha: Zf, Jb: Xf, Kb: Jf, za: jf, Lb: qf, ya: Yf, Mb: Hf, ua: ic, ba: tc, d: Bf, B: Cf, s: Mf, Eb: cc, t: Uf, y: Gf, F: Pf, I: _f, L: $f, Nb: Vf, R: ac, ia: Wf, $: sc, Pb: Nf, Rb: Rf, Ob: Ff, h: Ju, a: ke, $a: Ye, Hb: Xu, V: Zu, M: Ku, na: Qu, Db: ef, ja: tf, S: rf, Ab: nf, Bb: of, vb: af, wb: sf, P: uf, xb: ff, yb: cf, ta: df, Sb: lf, ob: pf, Q: mf, hb: hf, Cb: bf, sb: gf, tb: wf, ub: Tf, ga: vf, zb: Ef, Qb: Sf } };
  }
  async function wt() {
    function e(o, u) {
      var c = Ne = o.exports;
      o = {};
      for (let [h, m] of Object.entries(c)) typeof m == "function" ? (c = Ri(m), o[h] = c) : o[h] = m;
      return Ne = o, Ne = (function() {
        var h = Ne, m = (x) => (N) => x(N) >>> 0, y = (x) => () => x() >>> 0;
        return (h = Object.assign({}, h)).ic = m(h.ic), h.Nc = y(h.Nc), h.Pc = m(h.Pc), h.Bd = /* @__PURE__ */ ((x) => (N, F) => x(N, F) >>> 0)(h.Bd), h.Gd = m(h.Gd), h.Hd = y(h.Hd), h.Ld = m(h.Ld), h;
      })(), gn.push(Ne.sd), To = (o = Ne).ic, vo = o.jc, r._OrtInit = o.kc, r._OrtGetLastError = o.lc, r._OrtCreateSessionOptions = o.mc, r._OrtAppendExecutionProvider = o.nc, r._OrtAddFreeDimensionOverride = o.oc, r._OrtAddSessionConfigEntry = o.pc, r._OrtReleaseSessionOptions = o.qc, r._OrtCreateSession = o.rc, r._OrtReleaseSession = o.sc, r._OrtGetInputOutputCount = o.tc, r._OrtGetInputOutputMetadata = o.uc, r._OrtFree = o.vc, r._OrtCreateTensor = o.wc, r._OrtGetTensorData = o.xc, r._OrtReleaseTensor = o.yc, r._OrtCreateRunOptions = o.zc, r._OrtAddRunConfigEntry = o.Ac, r._OrtReleaseRunOptions = o.Bc, r._OrtCreateBinding = o.Cc, r._OrtBindInput = o.Dc, r._OrtBindOutput = o.Ec, r._OrtClearBoundOutputs = o.Fc, r._OrtReleaseBinding = o.Gc, r._OrtRunWithBinding = o.Hc, r._OrtRun = o.Ic, r._OrtEndProfiling = o.Jc, Eo = r._OrtCreateWebGpuInstance = o.Kc, r._wgpuCreateInstance = o.Lc, Nr = r._OrtGetWebGpuDevice = o.Mc, zt = o.Nc, ve = r._free = o.Oc, Ke = r._malloc = o.Pc, So = r._wgpuBufferRelease = o.Qc, xo = o.Rc, Ao = o.Sc, Io = o.Tc, Lo = o.Uc, Bo = o.Vc, Oo = o.Yc, Mo = o.Zc, Co = o.hd, Do = o.id, Po = o.jd, Wr = o.ld, kr = o.md, Fr = o.nd, Gr = o.od, St = o.pd, $r = o.qd, Uo = o.rd, zr = o.ud, _o = o.vd, Ro = o.wd, No = o.xd, Vr = o.yd, Wo = o.zd, ko = o.Ad, jr = o.Bd, W = o.Cd, xt = o.Dd, Fo = o.Ed, D = o.Fd, Vt = o.Gd, P = o.Hd, Go = o.Id, Hr = o.Jd, $o = o.Kd, zo = o.Ld, Vo = o.Md, qr = o.Nd, jo = o.Od, Ho = o.Pd, qo = o.Qd, Yo = o.Rd, Jo = o.Sd, Xo = o.Td, Zo = o.Ud, Ko = o.Vd, Qo = o.Wd, ea = o.Xd, ta = o.Yd, ra = o.Zd, na = o._d, oa = o.$d, aa = o.ae, sa = o.be, ia = o.ce, ua = o.de, fa = o.fe, ca = o.ge, da = o.he, la = o.ie, pa = o.je, ma = o.ke, ha = o.le, ba = o.me, ga = o.Ae, ya = o.Be, wa = o.Ce, Ta = o.De, va = o.Ee, Ea = o.Fe, Sa = o.Ge, xa = o.He, Aa = o.Ie, Ia = o.Je, La = o.Ke, Ba = o.nf, Oa = o.of, Ma = o.pf, Ca = o.qf, T = u, Ne;
    }
    var t, n = qe();
    return r.instantiateWasm ? new Promise((o) => {
      r.instantiateWasm(n, (u, c) => {
        o(e(u, c));
      });
    }) : i ? e(new WebAssembly.Instance(T, qe()), T) : (ge ??= r.locateFile ? r.locateFile ? r.locateFile("ort-wasm-simd-threaded.asyncify.wasm", S) : S + "ort-wasm-simd-threaded.asyncify.wasm" : new URL("ort-wasm-simd-threaded.asyncify.wasm", import.meta.url).href, t = await (async function(o) {
      var u = ge;
      if (!v && !oe(u)) try {
        var c = fetch(u, { credentials: "same-origin" });
        return await WebAssembly.instantiateStreaming(c, o);
      } catch (h) {
        O(`wasm streaming compile failed: ${h}`), O("falling back to ArrayBuffer instantiation");
      }
      return (async function(h, m) {
        try {
          var y = await (async function(x) {
            if (!v) try {
              var N = await l(x);
              return new Uint8Array(N);
            } catch {
            }
            if (x == ge && v) x = new Uint8Array(v);
            else {
              if (!b) throw "both async and sync fetching of the wasm failed";
              x = b(x);
            }
            return x;
          })(h);
          return await WebAssembly.instantiate(y, m);
        } catch (x) {
          O(`failed to asynchronously prepare wasm: ${x}`), we(x);
        }
      })(u, o);
    })(n), e(t.instance, t.module));
  }
  class Tt {
    name = "ExitStatus";
    constructor(t) {
      this.message = `Program terminated with exit(${t})`, this.status = t;
    }
  }
  var Se = (e) => {
    e.terminate(), e.onmessage = () => {
    };
  }, xe = [], Be = 0, re = null, Q = (e) => {
    We.length == 0 && (vn(), Tn(We[0]));
    var t = We.pop();
    if (!t) return 6;
    vt.push(t), Je[e.Xc] = t, t.Xc = e.Xc;
    var n = { $c: "run", ze: e.ye, kd: e.kd, Xc: e.Xc };
    return t.postMessage(n, e.oe), 0;
  }, z = 0, H = (e, t, ...n) => {
    var o, u = 16 * n.length, c = P(), h = Vt(u), m = h >>> 3;
    for (o of n) typeof o == "bigint" ? ((d(), pe)[m++ >>> 0] = 1n, (d(), pe)[m++ >>> 0] = o) : ((d(), pe)[m++ >>> 0] = 0n, (d(), ae)[m++ >>> 0] = o);
    return e = Ro(e, 0, u, h, t), D(c), e;
  };
  function Ye(e) {
    if (i) return H(0, 1, e);
    if (A = e, !(0 < z)) {
      for (var t of vt) Se(t);
      for (t of We) Se(t);
      We = [], vt = [], Je = {}, $ = true;
    }
    g(0, new Tt(e));
  }
  function Tr(e) {
    if (i) return H(1, 0, e);
    vr(e);
  }
  var vr = (e) => {
    if (A = e, i) throw Tr(e), "unwind";
    Ye(e);
  }, We = [], vt = [], gn = [], Je = {}, yn = (e) => {
    var t = e.Xc;
    delete Je[t], We.push(e), vt.splice(vt.indexOf(e), 1), e.Xc = 0, No(t);
  };
  function wn() {
    gn.forEach((e) => e());
  }
  var Tn = (e) => new Promise((t) => {
    e.onmessage = (u) => {
      var c = u.data;
      if (u = c.$c, c.gd && c.gd != zt()) {
        var h = Je[c.gd];
        h ? h.postMessage(c, c.oe) : O(`Internal error! Worker sent a message "${u}" to target pthread ${c.gd}, but that thread no longer exists!`);
      } else u === "checkMailbox" ? _t() : u === "spawnThread" ? Q(c) : u === "cleanupThread" ? me(() => {
        yn(Je[c.Le]);
      }) : u === "loaded" ? (e.loaded = true, t(e)) : c.target === "setimmediate" ? e.postMessage(c) : u === "uncaughtException" ? e.onerror(c.error) : u === "callHandler" ? r[c.te](...c.args) : u && O(`worker sent an unknown command ${u}`);
    }, e.onerror = (u) => {
      throw O(`worker sent an error! ${u.filename}:${u.lineno}: ${u.message}`), u;
    };
    var n, o = [];
    for (n of []) r.propertyIsEnumerable(n) && o.push(n);
    e.postMessage({ $c: "load", ue: o, Me: ke, Ne: T });
  });
  function vn() {
    var e = new Worker((() => {
      let t = URL;
      return import.meta.url > "file:" && import.meta.url < "file;" ? new t("ort.webgpu.bundle.min.mjs", import.meta.url) : new URL(import.meta.url);
    })(), { type: "module", workerData: "em-pthread", name: "em-pthread" });
    We.push(e);
  }
  var ke, ei = (e, t) => {
    z = 0, e = qr(e, t), 0 < z ? A = e : Vr(e);
  }, Pt = [], Ut = 0, ue = (e) => -9007199254740992 > e || 9007199254740992 < e ? NaN : Number(e);
  function ti(e) {
    var t = new Er(e >>>= 0);
    return (d(), Z)[t.ad + 12 >>> 0] == 0 && (En(t, true), Ut--), Sn(t, false), Pt.push(t), zo(e);
  }
  var dt = 0, ri = () => {
    W(0, 0);
    var e = Pt.pop();
    Go(e.td), dt = 0;
  };
  function En(e, t) {
    t = t ? 1 : 0, (d(), Z)[e.ad + 12 >>> 0] = t;
  }
  function Sn(e, t) {
    t = t ? 1 : 0, (d(), Z)[e.ad + 13 >>> 0] = t;
  }
  class Er {
    constructor(t) {
      this.td = t, this.ad = t - 24;
    }
  }
  var Sr = (e) => {
    var t = dt;
    if (!t) return xt(0), 0;
    var n = new Er(t);
    (d(), E)[n.ad + 16 >>> 2 >>> 0] = t;
    var o = (d(), E)[n.ad + 4 >>> 2 >>> 0];
    if (!o) return xt(0), t;
    for (var u of e) {
      if (u === 0 || u === o) break;
      if ($o(u, o, n.ad + 16)) return xt(u), t;
    }
    return xt(o), t;
  };
  function ni() {
    return Sr([]);
  }
  function oi(e) {
    return Sr([e >>> 0]);
  }
  function ai(e, t, n, o) {
    return Sr([e >>> 0, t >>> 0, n >>> 0, o >>> 0]);
  }
  var si = () => {
    var e = Pt.pop();
    e || we("no exception to throw");
    var t = e.td;
    throw (d(), Z)[e.ad + 13 >>> 0] == 0 && (Pt.push(e), Sn(e, true), En(e, false), Ut++), Hr(t), dt = t;
  };
  function ii(e, t, n) {
    var o = new Er(e >>>= 0);
    throw t >>>= 0, n >>>= 0, (d(), E)[o.ad + 16 >>> 2 >>> 0] = 0, (d(), E)[o.ad + 4 >>> 2 >>> 0] = t, (d(), E)[o.ad + 8 >>> 2 >>> 0] = n, Hr(e), Ut++, dt = e;
  }
  var ui = () => Ut;
  function xn(e, t, n, o) {
    return i ? H(2, 1, e, t, n, o) : An(e, t, n, o);
  }
  function An(e, t, n, o) {
    if (e >>>= 0, t >>>= 0, n >>>= 0, o >>>= 0, !globalThis.SharedArrayBuffer) return 6;
    var u = [];
    return i && u.length === 0 ? xn(e, t, n, o) : (e = { ye: n, Xc: e, kd: o, oe: u }, i ? (e.$c = "spawnThread", postMessage(e, u), 0) : Q(e));
  }
  function fi(e) {
    throw dt ||= e >>> 0, dt;
  }
  var In = globalThis.TextDecoder && new TextDecoder(), Ln = (e, t, n, o) => {
    if (n = t + n, o) return n;
    for (; e[t] && !(t >= n); ) ++t;
    return t;
  }, Bn = (e, t = 0, n, o) => {
    if (16 < (n = Ln(e, t >>>= 0, n, o)) - t && e.buffer && In) return In.decode(e.buffer instanceof ArrayBuffer ? e.subarray(t, n) : e.slice(t, n));
    for (o = ""; t < n; ) {
      var u = e[t++];
      if (128 & u) {
        var c = 63 & e[t++];
        if ((224 & u) == 192) o += String.fromCharCode((31 & u) << 6 | c);
        else {
          var h = 63 & e[t++];
          65536 > (u = (240 & u) == 224 ? (15 & u) << 12 | c << 6 | h : (7 & u) << 18 | c << 12 | h << 6 | 63 & e[t++]) ? o += String.fromCharCode(u) : (u -= 65536, o += String.fromCharCode(55296 | u >> 10, 56320 | 1023 & u));
        }
      } else o += String.fromCharCode(u);
    }
    return o;
  }, lt = (e, t, n) => (e >>>= 0) ? Bn((d(), X), e, t, n) : "";
  function On(e, t, n) {
    return i ? H(3, 1, e, t, n) : 0;
  }
  function Mn(e, t) {
    if (i) return H(4, 1, e, t);
  }
  function Cn(e, t) {
    if (i) return H(5, 1, e, t);
  }
  function Dn(e, t, n) {
    if (i) return H(6, 1, e, t, n);
  }
  function Pn(e, t, n) {
    return i ? H(7, 1, e, t, n) : 0;
  }
  function Un(e, t) {
    if (i) return H(8, 1, e, t);
  }
  function _n(e, t, n) {
    if (i) return H(9, 1, e, t, n);
  }
  function Rn(e, t, n, o) {
    if (i) return H(10, 1, e, t, n, o);
  }
  function Nn(e, t, n, o) {
    if (i) return H(11, 1, e, t, n, o);
  }
  function Wn(e, t, n, o) {
    if (i) return H(12, 1, e, t, n, o);
  }
  function kn(e) {
    if (i) return H(13, 1, e);
  }
  function Fn(e, t) {
    if (i) return H(14, 1, e, t);
  }
  function Gn(e, t, n) {
    if (i) return H(15, 1, e, t, n);
  }
  var ci = () => we(""), Oe = (e) => {
    e >>>= 0;
    for (var t = ""; ; ) {
      var n = (d(), X)[e++ >>> 0];
      if (!n) return t;
      t += String.fromCharCode(n);
    }
  }, xr = {}, Ar = {}, di = {}, pt = class extends Error {
    constructor(e) {
      super(e), this.name = "BindingError";
    }
  };
  function Pe(e, t, n = {}) {
    return (function(o, u, c = {}) {
      var h = u.name;
      if (!o) throw new pt(`type "${h}" must have a positive integer typeid pointer`);
      if (Ar.hasOwnProperty(o)) {
        if (c.ve) return;
        throw new pt(`Cannot register type '${h}' twice`);
      }
      Ar[o] = u, delete di[o], xr.hasOwnProperty(o) && (u = xr[o], delete xr[o], u.forEach((m) => m()));
    })(e, t, n);
  }
  var $n = (e, t, n) => {
    switch (t) {
      case 1:
        return n ? (o) => (d(), Z)[o >>> 0] : (o) => (d(), X)[o >>> 0];
      case 2:
        return n ? (o) => (d(), De)[o >>> 1 >>> 0] : (o) => (d(), K)[o >>> 1 >>> 0];
      case 4:
        return n ? (o) => (d(), I)[o >>> 2 >>> 0] : (o) => (d(), E)[o >>> 2 >>> 0];
      case 8:
        return n ? (o) => (d(), pe)[o >>> 3 >>> 0] : (o) => (d(), J)[o >>> 3 >>> 0];
      default:
        throw new TypeError(`invalid integer width (${t}): ${e}`);
    }
  };
  function li(e, t, n, o, u) {
    e >>>= 0, n >>>= 0, t = Oe(t >>> 0);
    let c = (h) => h;
    if (o = o === 0n) {
      let h = 8 * n;
      c = (m) => BigInt.asUintN(h, m), u = c(u);
    }
    Pe(e, { name: t, Wc: c, cd: (h, m) => (typeof m == "number" && (m = BigInt(m)), m), bd: $n(t, n, !o), dd: null });
  }
  function pi(e, t, n, o) {
    Pe(e >>>= 0, { name: t = Oe(t >>> 0), Wc: function(u) {
      return !!u;
    }, cd: function(u, c) {
      return c ? n : o;
    }, bd: function(u) {
      return this.Wc((d(), X)[u >>> 0]);
    }, dd: null });
  }
  var zn = [], Xe = [0, 1, , 1, null, 1, true, 1, false, 1];
  function Ir(e) {
    9 < (e >>>= 0) && --Xe[e + 1] === 0 && (Xe[e] = void 0, zn.push(e));
  }
  var Te = (e) => {
    if (!e) throw new pt(`Cannot use deleted val. handle = ${e}`);
    return Xe[e];
  }, Ae = (e) => {
    switch (e) {
      case void 0:
        return 2;
      case null:
        return 4;
      case true:
        return 6;
      case false:
        return 8;
      default:
        let t = zn.pop() || Xe.length;
        return Xe[t] = e, Xe[t + 1] = 1, t;
    }
  };
  function Lr(e) {
    return this.Wc((d(), E)[e >>> 2 >>> 0]);
  }
  var mi = { name: "emscripten::val", Wc: (e) => {
    var t = Te(e);
    return Ir(e), t;
  }, cd: (e, t) => Ae(t), bd: Lr, dd: null };
  function hi(e) {
    return Pe(e >>> 0, mi);
  }
  var bi = (e, t) => {
    switch (t) {
      case 4:
        return function(n) {
          return this.Wc((d(), R)[n >>> 2 >>> 0]);
        };
      case 8:
        return function(n) {
          return this.Wc((d(), ae)[n >>> 3 >>> 0]);
        };
      default:
        throw new TypeError(`invalid float width (${t}): ${e}`);
    }
  };
  function gi(e, t, n) {
    n >>>= 0, Pe(e >>>= 0, { name: t = Oe(t >>> 0), Wc: (o) => o, cd: (o, u) => u, bd: bi(t, n), dd: null });
  }
  function yi(e, t, n, o, u) {
    e >>>= 0, n >>>= 0, t = Oe(t >>> 0);
    let c = (m) => m;
    if (o === 0) {
      var h = 32 - 8 * n;
      c = (m) => m << h >>> h, u = c(u);
    }
    Pe(e, { name: t, Wc: c, cd: (m, y) => y, bd: $n(t, n, o !== 0), dd: null });
  }
  function wi(e, t, n) {
    function o(c) {
      var h = (d(), E)[c >>> 2 >>> 0];
      return c = (d(), E)[c + 4 >>> 2 >>> 0], new u((d(), Z).buffer, c, h);
    }
    var u = [Int8Array, Uint8Array, Int16Array, Uint16Array, Int32Array, Uint32Array, Float32Array, Float64Array, BigInt64Array, BigUint64Array][t];
    Pe(e >>>= 0, { name: n = Oe(n >>> 0), Wc: o, bd: o }, { ve: true });
  }
  var Ue = (e, t, n) => {
    var o = (d(), X);
    if (t >>>= 0, 0 < n) {
      var u = t;
      n = t + n - 1;
      for (var c = 0; c < e.length; ++c) {
        var h = e.codePointAt(c);
        if (127 >= h) {
          if (t >= n) break;
          o[t++ >>> 0] = h;
        } else if (2047 >= h) {
          if (t + 1 >= n) break;
          o[t++ >>> 0] = 192 | h >> 6, o[t++ >>> 0] = 128 | 63 & h;
        } else if (65535 >= h) {
          if (t + 2 >= n) break;
          o[t++ >>> 0] = 224 | h >> 12, o[t++ >>> 0] = 128 | h >> 6 & 63, o[t++ >>> 0] = 128 | 63 & h;
        } else {
          if (t + 3 >= n) break;
          o[t++ >>> 0] = 240 | h >> 18, o[t++ >>> 0] = 128 | h >> 12 & 63, o[t++ >>> 0] = 128 | h >> 6 & 63, o[t++ >>> 0] = 128 | 63 & h, c++;
        }
      }
      o[t >>> 0] = 0, e = t - u;
    } else e = 0;
    return e;
  }, _e = (e) => {
    for (var t = 0, n = 0; n < e.length; ++n) {
      var o = e.charCodeAt(n);
      127 >= o ? t++ : 2047 >= o ? t += 2 : 55296 <= o && 57343 >= o ? (t += 4, ++n) : t += 3;
    }
    return t;
  };
  function Ti(e, t) {
    Pe(e >>>= 0, { name: t = Oe(t >>> 0), Wc(n) {
      var o = (d(), E)[n >>> 2 >>> 0];
      return o = lt(n + 4, o, true), ve(n), o;
    }, cd(n, o) {
      o instanceof ArrayBuffer && (o = new Uint8Array(o));
      var u = typeof o == "string";
      if (!(u || ArrayBuffer.isView(o) && o.BYTES_PER_ELEMENT == 1)) throw new pt("Cannot pass non-string to std::string");
      var c = u ? _e(o) : o.length, h = Ke(4 + c + 1), m = h + 4;
      return (d(), E)[h >>> 2 >>> 0] = c, u ? Ue(o, m, c + 1) : (d(), X).set(o, m >>> 0), n !== null && n.push(ve, h), h;
    }, bd: Lr, dd(n) {
      ve(n);
    } });
  }
  var Vn = globalThis.TextDecoder ? new TextDecoder("utf-16le") : void 0, vi = (e, t, n) => {
    if (e >>>= 1, 16 < (t = Ln((d(), K), e, t / 2, n)) - e && Vn) return Vn.decode((d(), K).slice(e, t));
    for (n = ""; e < t; ++e) {
      var o = (d(), K)[e >>> 0];
      n += String.fromCharCode(o);
    }
    return n;
  }, Ei = (e, t, n) => {
    if (n ??= 2147483647, 2 > n) return 0;
    var o = t;
    n = (n -= 2) < 2 * e.length ? n / 2 : e.length;
    for (var u = 0; u < n; ++u) {
      var c = e.charCodeAt(u);
      (d(), De)[t >>> 1 >>> 0] = c, t += 2;
    }
    return (d(), De)[t >>> 1 >>> 0] = 0, t - o;
  }, Si = (e) => 2 * e.length, xi = (e, t, n) => {
    var o = "";
    e >>>= 2;
    for (var u = 0; !(u >= t / 4); u++) {
      var c = (d(), E)[e + u >>> 0];
      if (!c && !n) break;
      o += String.fromCodePoint(c);
    }
    return o;
  }, Ai = (e, t, n) => {
    if (t >>>= 0, n ??= 2147483647, 4 > n) return 0;
    var o = t;
    n = o + n - 4;
    for (var u = 0; u < e.length; ++u) {
      var c = e.codePointAt(u);
      if (65535 < c && u++, (d(), I)[t >>> 2 >>> 0] = c, (t += 4) + 4 > n) break;
    }
    return (d(), I)[t >>> 2 >>> 0] = 0, t - o;
  }, Ii = (e) => {
    for (var t = 0, n = 0; n < e.length; ++n) 65535 < e.codePointAt(n) && n++, t += 4;
    return t;
  };
  function Li(e, t, n) {
    if (e >>>= 0, t >>>= 0, n = Oe(n >>>= 0), t === 2) var o = vi, u = Ei, c = Si;
    else o = xi, u = Ai, c = Ii;
    Pe(e, { name: n, Wc: (h) => {
      var m = (d(), E)[h >>> 2 >>> 0];
      return m = o(h + 4, m * t, true), ve(h), m;
    }, cd: (h, m) => {
      if (typeof m != "string") throw new pt(`Cannot pass non-string to C++ string type ${n}`);
      var y = c(m), x = Ke(4 + y + t);
      return (d(), E)[x >>> 2 >>> 0] = y / t, u(m, x + 4, y + t), h !== null && h.push(ve, x), x;
    }, bd: Lr, dd(h) {
      ve(h);
    } });
  }
  function Bi(e, t) {
    Pe(e >>>= 0, { we: true, name: t = Oe(t >>> 0), Wc: () => {
    }, cd: () => {
    } });
  }
  function Oi(e) {
    zr(e >>> 0, !f, 1, !s, 131072, false), wn();
  }
  var me = (e) => {
    if (!$) try {
      if (e(), !(0 < z)) try {
        i ? zt() && Vr(A) : vr(A);
      } catch (t) {
        t instanceof Tt || t == "unwind" || g(0, t);
      }
    } catch (t) {
      t instanceof Tt || t == "unwind" || g(0, t);
    }
  }, Mi = !Atomics.waitAsync || globalThis.navigator?.userAgent && 91 > Number((navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./) || [])[2]);
  function Br(e) {
    e >>>= 0, Mi || (Atomics.waitAsync((d(), I), e >>> 2, e).value.then(_t), e += 128, Atomics.store((d(), I), e >>> 2, 1));
  }
  var _t = () => me(() => {
    var e = zt();
    e && (Br(e), ko());
  });
  function Ci(e, t) {
    (e >>>= 0) == t >>> 0 ? setTimeout(_t) : i ? postMessage({ gd: e, $c: "checkMailbox" }) : (e = Je[e]) && e.postMessage({ $c: "checkMailbox" });
  }
  var Or = [];
  function Di(e, t, n, o, u) {
    for (t >>>= 0, u >>>= 0, Or.length = 0, n = u >>> 3, o = u + o >>> 3; n < o; ) {
      var c;
      c = (d(), pe)[n++ >>> 0] ? (d(), pe)[n++ >>> 0] : (d(), ae)[n++ >>> 0], Or.push(c);
    }
    return (t ? Yr[t] : xf[e])(...Or);
  }
  var Pi = () => {
    z = 0;
  };
  function Ui(e) {
    e >>>= 0, i ? postMessage({ $c: "cleanupThread", Le: e }) : yn(Je[e]);
  }
  function _i(e) {
  }
  var Rt = (e) => {
    try {
      e();
    } catch (t) {
      we(t);
    }
  };
  function Ri(e) {
    var t = (...n) => {
      Nt.push(e);
      try {
        return e(...n);
      } finally {
        $ || (Nt.pop(), Me && Fe === 1 && Nt.length === 0 && (Fe = 0, z += 1, Rt(Oa), typeof Fibers < "u" && Fibers.We()));
      }
    };
    return qn.set(e, t), t;
  }
  var Fe = 0, Me = null, jn = 0, Nt = [], Mr = /* @__PURE__ */ new Map(), Hn = /* @__PURE__ */ new Map(), qn = /* @__PURE__ */ new Map(), Ni = 0, Cr = null, Wi = [], Yn = (e) => (function(t) {
    if (!$) {
      if (Fe === 0) {
        var n = false, o = false;
        t((u = 0) => {
          if (!$ && (jn = u, n = true, o)) {
            Fe = 2, Rt(() => Ma(Me)), typeof MainLoop < "u" && MainLoop.se && MainLoop.resume(), u = false;
            try {
              var c = (function() {
                var y = (d(), I)[Me + 8 >>> 2 >>> 0];
                return y = Hn.get(y), y = qn.get(y), --z, y();
              })();
            } catch (y) {
              c = y, u = true;
            }
            var h = false;
            if (!Me) {
              var m = Cr;
              m && (Cr = null, (u ? m.reject : m.resolve)(c), h = true);
            }
            if (u && !h) throw c;
          }
        }), o = true, n || (Fe = 1, Me = (function() {
          var u = Ke(65548), c = u + 12;
          if ((d(), E)[u >>> 2 >>> 0] = c, (d(), E)[u + 4 >>> 2 >>> 0] = c + 65536, c = Nt[0], !Mr.has(c)) {
            var h = Ni++;
            Mr.set(c, h), Hn.set(h, c);
          }
          return c = Mr.get(c), (d(), I)[u + 8 >>> 2 >>> 0] = c, u;
        })(), typeof MainLoop < "u" && MainLoop.se && MainLoop.pause(), Rt(() => Ba(Me)));
      } else Fe === 2 ? (Fe = 0, Rt(Ca), ve(Me), Me = null, Wi.forEach(me)) : we(`invalid state: ${Fe}`);
      return jn;
    }
  })((t) => {
    e().then(t);
  });
  function ki(e) {
    return e >>>= 0, Yn(async () => {
      var t = await Te(e);
      return Ae(t);
    });
  }
  var Dr = [], Fi = (e) => {
    var t = Dr.length;
    return Dr.push(e), t;
  }, Gi = (e, t) => {
    for (var n = Array(e), o = 0; o < e; ++o) {
      var u = o, c = (d(), E)[t + 4 * o >>> 2 >>> 0], h = Ar[c];
      if (h === void 0) throw e = `parameter ${o}`, c = To(c), t = Oe(c), ve(c), new pt(`${e} has unknown type ${t}`);
      n[u] = h;
    }
    return n;
  }, $i = (e, t, n) => {
    var o = [];
    return e = e(o, n), o.length && ((d(), E)[t >>> 2 >>> 0] = Ae(o)), e;
  }, zi = {}, Wt = (e) => {
    var t = zi[e];
    return t === void 0 ? Oe(e) : t;
  };
  function Vi(e, t, n) {
    var [o, ...u] = Gi(e, t >>> 0);
    t = o.cd.bind(o);
    var c = u.map((y) => y.bd.bind(y));
    e--;
    var h = { toValue: Te };
    switch (e = c.map((y, x) => {
      var N = `argFromPtr${x}`;
      return h[N] = y, `${N}(args${x ? "+" + 8 * x : ""})`;
    }), n) {
      case 0:
        var m = "toValue(handle)";
        break;
      case 2:
        m = "new (toValue(handle))";
        break;
      case 3:
        m = "";
        break;
      case 1:
        h.getStringOrSymbol = Wt, m = "toValue(handle)[getStringOrSymbol(methodName)]";
    }
    return m += `(${e})`, o.we || (h.toReturnWire = t, h.emval_returnValue = $i, m = `return emval_returnValue(toReturnWire, destructorsRef, ${m})`), m = `return function (handle, methodName, destructorsRef, args) {
  ${m}
  }`, n = new Function(Object.keys(h), m)(...Object.values(h)), m = `methodCaller<(${u.map((y) => y.name)}) => ${o.name}>`, Fi(Object.defineProperty(n, "name", { value: m }));
  }
  function ji(e, t) {
    return t >>>= 0, (e = Te(e >>> 0)) == Te(t);
  }
  function Hi(e) {
    return (e >>>= 0) ? (e = Wt(e), Ae(globalThis[e])) : Ae(globalThis);
  }
  function qi(e) {
    return e = Wt(e >>> 0), Ae(r[e]);
  }
  function Yi(e, t) {
    return t >>>= 0, e = Te(e >>> 0), t = Te(t), Ae(e[t]);
  }
  function Ji(e) {
    9 < (e >>>= 0) && (Xe[e + 1] += 1);
  }
  function Jn(e, t, n, o, u) {
    return Dr[e >>> 0](t >>> 0, n >>> 0, o >>> 0, u >>> 0);
  }
  function Xi(e, t, n, o, u) {
    return Jn(e >>> 0, t >>> 0, n >>> 0, o >>> 0, u >>> 0);
  }
  function Zi() {
    return Ae([]);
  }
  function Ki(e) {
    e = Te(e >>> 0);
    for (var t = Array(e.length), n = 0; n < e.length; n++) t[n] = e[n];
    return Ae(t);
  }
  function Qi(e) {
    return Ae(Wt(e >>> 0));
  }
  function eu() {
    return Ae({});
  }
  function tu(e) {
    for (var t = Te(e >>>= 0); t.length; ) {
      var n = t.pop();
      t.pop()(n);
    }
    Ir(e);
  }
  function ru(e, t, n) {
    t >>>= 0, n >>>= 0, e = Te(e >>> 0), t = Te(t), n = Te(n), e[t] = n;
  }
  function nu(e, t) {
    e = ue(e), t >>>= 0, e = new Date(1e3 * e), (d(), I)[t >>> 2 >>> 0] = e.getUTCSeconds(), (d(), I)[t + 4 >>> 2 >>> 0] = e.getUTCMinutes(), (d(), I)[t + 8 >>> 2 >>> 0] = e.getUTCHours(), (d(), I)[t + 12 >>> 2 >>> 0] = e.getUTCDate(), (d(), I)[t + 16 >>> 2 >>> 0] = e.getUTCMonth(), (d(), I)[t + 20 >>> 2 >>> 0] = e.getUTCFullYear() - 1900, (d(), I)[t + 24 >>> 2 >>> 0] = e.getUTCDay(), e = (e.getTime() - Date.UTC(e.getUTCFullYear(), 0, 1, 0, 0, 0, 0)) / 864e5 | 0, (d(), I)[t + 28 >>> 2 >>> 0] = e;
  }
  var Xn = (e) => e % 4 == 0 && (e % 100 != 0 || e % 400 == 0), Zn = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335], Kn = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  function ou(e, t) {
    e = ue(e), t >>>= 0, e = new Date(1e3 * e), (d(), I)[t >>> 2 >>> 0] = e.getSeconds(), (d(), I)[t + 4 >>> 2 >>> 0] = e.getMinutes(), (d(), I)[t + 8 >>> 2 >>> 0] = e.getHours(), (d(), I)[t + 12 >>> 2 >>> 0] = e.getDate(), (d(), I)[t + 16 >>> 2 >>> 0] = e.getMonth(), (d(), I)[t + 20 >>> 2 >>> 0] = e.getFullYear() - 1900, (d(), I)[t + 24 >>> 2 >>> 0] = e.getDay();
    var n = (Xn(e.getFullYear()) ? Zn : Kn)[e.getMonth()] + e.getDate() - 1 | 0;
    (d(), I)[t + 28 >>> 2 >>> 0] = n, (d(), I)[t + 36 >>> 2 >>> 0] = -60 * e.getTimezoneOffset(), n = new Date(e.getFullYear(), 6, 1).getTimezoneOffset();
    var o = new Date(e.getFullYear(), 0, 1).getTimezoneOffset();
    e = 0 | (n != o && e.getTimezoneOffset() == Math.min(o, n)), (d(), I)[t + 32 >>> 2 >>> 0] = e;
  }
  function au(e) {
    e >>>= 0;
    var t = new Date((d(), I)[e + 20 >>> 2 >>> 0] + 1900, (d(), I)[e + 16 >>> 2 >>> 0], (d(), I)[e + 12 >>> 2 >>> 0], (d(), I)[e + 8 >>> 2 >>> 0], (d(), I)[e + 4 >>> 2 >>> 0], (d(), I)[e >>> 2 >>> 0], 0), n = (d(), I)[e + 32 >>> 2 >>> 0], o = t.getTimezoneOffset(), u = new Date(t.getFullYear(), 6, 1).getTimezoneOffset(), c = new Date(t.getFullYear(), 0, 1).getTimezoneOffset(), h = Math.min(c, u);
    return 0 > n ? (d(), I)[e + 32 >>> 2 >>> 0] = +(u != c && h == o) : 0 < n != (h == o) && (u = Math.max(c, u), t.setTime(t.getTime() + 6e4 * ((0 < n ? h : u) - o))), (d(), I)[e + 24 >>> 2 >>> 0] = t.getDay(), n = (Xn(t.getFullYear()) ? Zn : Kn)[t.getMonth()] + t.getDate() - 1 | 0, (d(), I)[e + 28 >>> 2 >>> 0] = n, (d(), I)[e >>> 2 >>> 0] = t.getSeconds(), (d(), I)[e + 4 >>> 2 >>> 0] = t.getMinutes(), (d(), I)[e + 8 >>> 2 >>> 0] = t.getHours(), (d(), I)[e + 12 >>> 2 >>> 0] = t.getDate(), (d(), I)[e + 16 >>> 2 >>> 0] = t.getMonth(), (d(), I)[e + 20 >>> 2 >>> 0] = t.getYear(), e = t.getTime(), BigInt(isNaN(e) ? -1 : e / 1e3);
  }
  function Qn(e, t, n, o, u, c, h) {
    return i ? H(16, 1, e, t, n, o, u, c, h) : -52;
  }
  function eo(e, t, n, o, u, c) {
    if (i) return H(17, 1, e, t, n, o, u, c);
  }
  var Et = {}, su = () => performance.timeOrigin + performance.now();
  function to(e, t) {
    if (i) return H(18, 1, e, t);
    if (Et[e] && (clearTimeout(Et[e].id), delete Et[e]), !t) return 0;
    var n = setTimeout(() => {
      delete Et[e], me(() => Wo(e, performance.timeOrigin + performance.now()));
    }, t);
    return Et[e] = { id: n, Ve: t }, 0;
  }
  function iu(e, t, n, o) {
    e >>>= 0, t >>>= 0, n >>>= 0, o >>>= 0;
    var u = (/* @__PURE__ */ new Date()).getFullYear(), c = new Date(u, 0, 1).getTimezoneOffset();
    u = new Date(u, 6, 1).getTimezoneOffset();
    var h = Math.max(c, u);
    (d(), E)[e >>> 2 >>> 0] = 60 * h, (d(), I)[t >>> 2 >>> 0] = +(c != u), e = (t = (m) => {
      var y = Math.abs(m);
      return `UTC${0 <= m ? "-" : "+"}${String(Math.floor(y / 60)).padStart(2, "0")}${String(y % 60).padStart(2, "0")}`;
    })(c), t = t(u), u < c ? (Ue(e, n, 17), Ue(t, o, 17)) : (Ue(e, o, 17), Ue(t, n, 17));
  }
  var uu = () => Date.now(), fu = 1;
  function cu(e, t, n) {
    if (n >>>= 0, !(0 <= e && 3 >= e)) return 28;
    if (e === 0) e = Date.now();
    else {
      if (!fu) return 52;
      e = performance.timeOrigin + performance.now();
    }
    return e = Math.round(1e6 * e), (d(), pe)[n >>> 3 >>> 0] = BigInt(e), 0;
  }
  var Pr = [], ro = (e, t) => {
    Pr.length = 0;
    for (var n; n = (d(), X)[e++ >>> 0]; ) {
      var o = n != 105;
      t += (o &= n != 112) && t % 8 ? 4 : 0, Pr.push(n == 112 ? (d(), E)[t >>> 2 >>> 0] : n == 106 ? (d(), pe)[t >>> 3 >>> 0] : n == 105 ? (d(), I)[t >>> 2 >>> 0] : (d(), ae)[t >>> 3 >>> 0]), t += o ? 8 : 4;
    }
    return Pr;
  };
  function du(e, t, n) {
    return e >>>= 0, t = ro(t >>> 0, n >>> 0), Yr[e](...t);
  }
  function lu(e, t, n) {
    return e >>>= 0, t = ro(t >>> 0, n >>> 0), Yr[e](...t);
  }
  var pu = () => {
  };
  function mu(e, t) {
    return O(lt(e >>> 0, t >>> 0));
  }
  var hu = () => {
    throw z += 1, "unwind";
  };
  function bu() {
    return 4294901760;
  }
  var gu = () => 1, yu = () => navigator.hardwareConcurrency, Ze = {}, no = (e) => {
    var t = _e(e) + 1, n = Ke(t);
    return n && Ue(e, n, t), n;
  }, kt = (e) => {
    var t;
    return (t = /\bwasm-function\[\d+\]:(0x[0-9a-f]+)/.exec(e)) ? +t[1] : (t = /:(\d+):\d+(?:\)|$)/.exec(e)) ? 2147483648 | +t[1] : 0;
  }, oo = (e) => {
    for (var t of e) (e = kt(t)) && (Ze[e] = t);
  };
  function wu() {
    var e = Error().stack.toString().split(`
`);
    return e[0] == "Error" && e.shift(), oo(e), Ze.ee = kt(e[3]), Ze.xe = e, Ze.ee;
  }
  function Ft(e) {
    if (!(e = Ze[e >>> 0])) return 0;
    var t;
    if (t = /^\s+at .*\.wasm\.(.*) \(.*\)$/.exec(e)) e = t[1];
    else if (t = /^\s+at (.*) \(.*\)$/.exec(e)) e = t[1];
    else {
      if (!(t = /^(.+?)@/.exec(e))) return 0;
      e = t[1];
    }
    return ve(Ft.ne ?? 0), Ft.ne = no(e), Ft.ne;
  }
  function Tu(e) {
    e >>>= 0;
    var t = (d(), X).length;
    if (e <= t || 4294901760 < e) return false;
    for (var n = 1; 4 >= n; n *= 2) {
      var o = t * (1 + 0.2 / n);
      o = Math.min(o, e + 100663296);
      e: {
        o = (Math.min(4294901760, 65536 * Math.ceil(Math.max(e, o) / 65536)) - ke.buffer.byteLength + 65535) / 65536 | 0;
        try {
          ke.grow(o), se();
          var u = 1;
          break e;
        } catch {
        }
        u = void 0;
      }
      if (u) return true;
    }
    return false;
  }
  function vu(e, t, n) {
    if (e >>>= 0, t >>>= 0, Ze.ee == e) var o = Ze.xe;
    else (o = Error().stack.toString().split(`
`))[0] == "Error" && o.shift(), oo(o);
    for (var u = 3; o[u] && kt(o[u]) != e; ) ++u;
    for (e = 0; e < n && o[e + u]; ++e) (d(), I)[t + 4 * e >>> 2 >>> 0] = kt(o[e + u]);
    return e;
  }
  var Ce = (e) => {
    var t = _e(e) + 1, n = Vt(t);
    return Ue(e, n, t), n;
  }, mt = (e) => (d(), E)[e >>> 2 >>> 0] + 4294967296 * (d(), I)[e + 4 >>> 2 >>> 0], fe = [], ao = (e, t) => {
    fe[e >>> 0] = t;
  }, Re = [], Gt = [], ht = (e, t) => {
    Gt[e] = new Promise((n) => t.finally(() => n(e)));
  }, B = (e) => {
    if (e) return fe[e >>> 0];
  }, Ur = (e, t) => {
    for (e = (d(), E)[e >>> 2 >>> 0]; e; e = (d(), E)[e >>> 2 >>> 0]) t[(d(), I)[e + 4 >>> 2 >>> 0]](e);
  }, $t = (e, t, n) => {
    (d(), E)[e >>> 2 >>> 0] = t, (d(), E)[e + 4 >>> 2 >>> 0] = n;
  }, so = (e) => {
    var t = (d(), E)[e >>> 2 >>> 0];
    return e = (d(), E)[e + 4 >>> 2 >>> 0], lt(t, e);
  }, Ie = (e) => {
    var t = (d(), E)[e >>> 2 >>> 0];
    return e = (d(), E)[e + 4 >>> 2 >>> 0], t ? lt(t, e) : e === 0 ? "" : void 0;
  }, Eu = (e) => {
    var t = Ie(e + 4), n = (n = (d(), E)[e + 12 >>> 2 >>> 0]) ? B(n) : "auto";
    if (e += 16) {
      var o = B((d(), E)[e + 4 >>> 2 >>> 0]), u = (d(), E)[e + 16 >>> 2 >>> 0], c = (d(), E)[e + 20 >>> 2 >>> 0];
      if (u) {
        for (var h = {}, m = 0; m < u; ++m) {
          var y = c + 24 * m;
          h[so(y + 4)] = (d(), ae)[y + 16 >>> 3 >>> 0];
        }
        u = h;
      } else u = void 0;
      e = { module: o, constants: u, entryPoint: Ie(e + 8) };
    } else e = void 0;
    return { label: t, layout: n, compute: e };
  }, io = (e, t) => {
    function n(c, h, m, y = 0) {
      c = e[c] ?? y, (d(), E)[h + m >>> 2 >>> 0] = c;
    }
    function o(c, h, m, y = 0) {
      h += m, c = e[c] ?? y, (d(), E)[h >>> 2 >>> 0] = c, y = (d(), E)[h >>> 2 >>> 0], (d(), E)[h + 4 >>> 2 >>> 0] = (c - y) / 4294967296;
    }
    var u = (d(), E)[t >>> 2 >>> 0];
    n("maxTextureDimension1D", t, 4), n("maxTextureDimension2D", t, 8), n("maxTextureDimension3D", t, 12), n("maxTextureArrayLayers", t, 16), n("maxBindGroups", t, 20), n("maxBindGroupsPlusVertexBuffers", t, 24), n("maxBindingsPerBindGroup", t, 28), n("maxDynamicUniformBuffersPerPipelineLayout", t, 32), n("maxDynamicStorageBuffersPerPipelineLayout", t, 36), n("maxSampledTexturesPerShaderStage", t, 40), n("maxSamplersPerShaderStage", t, 44), n("maxStorageBuffersPerShaderStage", t, 48), n("maxStorageTexturesPerShaderStage", t, 52), n("maxUniformBuffersPerShaderStage", t, 56), n("minUniformBufferOffsetAlignment", t, 80), n("minStorageBufferOffsetAlignment", t, 84), o("maxUniformBufferBindingSize", t, 64), o("maxStorageBufferBindingSize", t, 72), n("maxVertexBuffers", t, 88), o("maxBufferSize", t, 96), n("maxVertexAttributes", t, 104), n("maxVertexBufferArrayStride", t, 108), n("maxInterStageShaderVariables", t, 112), n("maxColorAttachments", t, 116), n("maxColorAttachmentBytesPerSample", t, 120), n("maxComputeWorkgroupStorageSize", t, 124), n("maxComputeInvocationsPerWorkgroup", t, 128), n("maxComputeWorkgroupSizeX", t, 132), n("maxComputeWorkgroupSizeY", t, 136), n("maxComputeWorkgroupSizeZ", t, 140), n("maxComputeWorkgroupsPerDimension", t, 144), n("maxImmediateSize", t, 148), u !== 0 && (d(), n("maxStorageBuffersInVertexStage", u, 8, e.maxStorageBuffersPerShaderStage), n("maxStorageBuffersInFragmentStage", u, 16, e.maxStorageBuffersPerShaderStage), n("maxStorageTexturesInVertexStage", u, 12, e.maxStorageTexturesPerShaderStage), n("maxStorageTexturesInFragmentStage", u, 20, e.maxStorageTexturesPerShaderStage));
  }, Su = (e, t) => {
    (d(), E)[t + 52 >>> 2 >>> 0] = e.subgroupMinSize, (d(), E)[t + 56 >>> 2 >>> 0] = e.subgroupMaxSize;
    var n = no(e.vendor + e.architecture + e.device + e.description), o = _e(e.vendor);
    $t(t + 4, n, o), n += o, o = _e(e.architecture), $t(t + 12, n, o), n += o, o = _e(e.device), $t(t + 20, n, o), n += o, o = _e(e.description), $t(t + 28, n, o), n += o, (d(), I)[t + 36 >>> 2 >>> 0] = 2, n = e.isFallbackAdapter ? 3 : 4, (d(), I)[t + 40 >>> 2 >>> 0] = n, (d(), E)[t + 44 >>> 2 >>> 0] = 0, (d(), E)[t + 48 >>> 2 >>> 0] = 0, Ur(t, { 327739: (u) => {
      let c = 0, h = 0;
      if (e.subgroupMatrixConfigs) {
        c = e.subgroupMatrixConfigs.length, h = Ke(20 * c);
        for (let [m, y] of e.subgroupMatrixConfigs.entries()) {
          let x = h + 20 * m, N = fo.indexOf(y.componentType), F = fo.indexOf(y.resultComponentType);
          (d(), I)[x >>> 2 >>> 0] = N, (d(), I)[x + 4 >>> 2 >>> 0] = F, (d(), E)[x + 8 >>> 2 >>> 0] = y.M, (d(), E)[x + 12 >>> 2 >>> 0] = y.N, (d(), E)[x + 16 >>> 2 >>> 0] = y.K;
        }
      }
      (d(), E)[u + 12 >>> 2 >>> 0] = h, (d(), E)[u + 8 >>> 2 >>> 0] = c;
    } });
  }, xu = [, , "uniform", "storage", "read-only-storage"], Au = [, "validation", "out-of-memory", "internal"], Iu = [, "compatibility", "core"], uo = { 1: "core-features-and-limits", 2: "depth-clip-control", 3: "depth32float-stencil8", 4: "texture-compression-bc", 5: "texture-compression-bc-sliced-3d", 6: "texture-compression-etc2", 7: "texture-compression-astc", 8: "texture-compression-astc-sliced-3d", 9: "timestamp-query", 10: "indirect-first-instance", 11: "shader-f16", 12: "rg11b10ufloat-renderable", 13: "bgra8unorm-storage", 14: "float32-filterable", 15: "float32-blendable", 16: "clip-distances", 17: "dual-source-blending", 18: "subgroups", 19: "texture-formats-tier1", 20: "texture-formats-tier2", 21: "primitive-index", 22: "texture-component-swizzle", 23: "subgroup-size-control", 327692: "chromium-experimental-unorm16-texture-formats", 327729: "chromium-experimental-multi-draw-indirect", 327732: "chromium-experimental-subgroup-matrix" }, Lu = [, "low-power", "high-performance"], Bu = [, "occlusion", "timestamp"], Ou = [, , "filtering", "non-filtering", "comparison"], Mu = [, , "write-only", "read-only", "read-write"], fo = [, "f32", "f16", "u32", "i32", "u8", "i8"], Cu = [, "r8unorm", "r8snorm", "r8uint", "r8sint", "r16unorm", "r16snorm", "r16uint", "r16sint", "r16float", "rg8unorm", "rg8snorm", "rg8uint", "rg8sint", "r32float", "r32uint", "r32sint", "rg16unorm", "rg16snorm", "rg16uint", "rg16sint", "rg16float", "rgba8unorm", "rgba8unorm-srgb", "rgba8snorm", "rgba8uint", "rgba8sint", "bgra8unorm", "bgra8unorm-srgb", "rgb10a2uint", "rgb10a2unorm", "rg11b10ufloat", "rgb9e5ufloat", "rg32float", "rg32uint", "rg32sint", "rgba16unorm", "rgba16snorm", "rgba16uint", "rgba16sint", "rgba16float", "rgba32float", "rgba32uint", "rgba32sint", "stencil8", "depth16unorm", "depth24plus", "depth24plus-stencil8", "depth32float", "depth32float-stencil8", "bc1-rgba-unorm", "bc1-rgba-unorm-srgb", "bc2-rgba-unorm", "bc2-rgba-unorm-srgb", "bc3-rgba-unorm", "bc3-rgba-unorm-srgb", "bc4-r-unorm", "bc4-r-snorm", "bc5-rg-unorm", "bc5-rg-snorm", "bc6h-rgb-ufloat", "bc6h-rgb-float", "bc7-rgba-unorm", "bc7-rgba-unorm-srgb", "etc2-rgb8unorm", "etc2-rgb8unorm-srgb", "etc2-rgb8a1unorm", "etc2-rgb8a1unorm-srgb", "etc2-rgba8unorm", "etc2-rgba8unorm-srgb", "eac-r11unorm", "eac-r11snorm", "eac-rg11unorm", "eac-rg11snorm", "astc-4x4-unorm", "astc-4x4-unorm-srgb", "astc-5x4-unorm", "astc-5x4-unorm-srgb", "astc-5x5-unorm", "astc-5x5-unorm-srgb", "astc-6x5-unorm", "astc-6x5-unorm-srgb", "astc-6x6-unorm", "astc-6x6-unorm-srgb", "astc-8x5-unorm", "astc-8x5-unorm-srgb", "astc-8x6-unorm", "astc-8x6-unorm-srgb", "astc-8x8-unorm", "astc-8x8-unorm-srgb", "astc-10x5-unorm", "astc-10x5-unorm-srgb", "astc-10x6-unorm", "astc-10x6-unorm-srgb", "astc-10x8-unorm", "astc-10x8-unorm-srgb", "astc-10x10-unorm", "astc-10x10-unorm-srgb", "astc-12x10-unorm", "astc-12x10-unorm-srgb", "astc-12x12-unorm", "astc-12x12-unorm-srgb"], Du = [, , "float", "unfilterable-float", "depth", "sint", "uint"], co = [, "1d", "2d", "2d-array", "cube", "cube-array", "3d"], Pu = { undefined: 1, unknown: 1, destroyed: 2 };
  function Uu(e, t, n, o, u, c) {
    t = ue(t), n = ue(n), o >>>= 0, u >>>= 0, c >>>= 0;
    var h = B(e >>> 0);
    if (e = {}, c) {
      var m = (d(), E)[c + 12 >>> 2 >>> 0];
      if (m) {
        var y = (d(), E)[c + 16 >>> 2 >>> 0];
        e.requiredFeatures = Array.from((d(), E).subarray(y >>> 2 >>> 0, y + 4 * m >>> 2 >>> 0), (L) => uo[L]);
      }
      if (m = (d(), E)[c + 20 >>> 2 >>> 0]) {
        let L = function(he, de, Qe, et = false) {
          de += Qe, (de = (d(), E)[de >>> 2 >>> 0]) == 4294967295 || et && de == 0 || (x[he] = de);
        }, q = function(he, de, Qe) {
          de += Qe, Qe = (d(), E)[de >>> 2 >>> 0];
          var et = (d(), E)[de + 4 >>> 2 >>> 0];
          Qe == 4294967295 && et == 4294967295 || (x[he] = mt(de));
        };
        var N = L, F = q;
        y = (d(), E)[m >>> 2 >>> 0];
        var x = {};
        L("maxTextureDimension1D", m, 4), L("maxTextureDimension2D", m, 8), L("maxTextureDimension3D", m, 12), L("maxTextureArrayLayers", m, 16), L("maxBindGroups", m, 20), L("maxBindGroupsPlusVertexBuffers", m, 24), L("maxBindingsPerBindGroup", m, 28), L("maxDynamicUniformBuffersPerPipelineLayout", m, 32), L("maxDynamicStorageBuffersPerPipelineLayout", m, 36), L("maxSampledTexturesPerShaderStage", m, 40), L("maxSamplersPerShaderStage", m, 44), L("maxStorageBuffersPerShaderStage", m, 48), L("maxStorageTexturesPerShaderStage", m, 52), L("maxUniformBuffersPerShaderStage", m, 56), L("minUniformBufferOffsetAlignment", m, 80), L("minStorageBufferOffsetAlignment", m, 84), q("maxUniformBufferBindingSize", m, 64), q("maxStorageBufferBindingSize", m, 72), L("maxVertexBuffers", m, 88), q("maxBufferSize", m, 96), L("maxVertexAttributes", m, 104), L("maxVertexBufferArrayStride", m, 108), L("maxInterStageShaderVariables", m, 112), L("maxColorAttachments", m, 116), L("maxColorAttachmentBytesPerSample", m, 120), L("maxComputeWorkgroupStorageSize", m, 124), L("maxComputeInvocationsPerWorkgroup", m, 128), L("maxComputeWorkgroupSizeX", m, 132), L("maxComputeWorkgroupSizeY", m, 136), L("maxComputeWorkgroupSizeZ", m, 140), L("maxComputeWorkgroupsPerDimension", m, 144), L("maxImmediateSize", m, 148, true), y !== 0 && (d(), "maxStorageBuffersInVertexStage" in GPUSupportedLimits.prototype && (L("maxStorageBuffersInVertexStage", y, 8), L("maxStorageTexturesInVertexStage", y, 12), L("maxStorageBuffersInFragmentStage", y, 16), L("maxStorageTexturesInFragmentStage", y, 20))), e.requiredLimits = x;
      }
      (m = (d(), E)[c + 24 >>> 2 >>> 0]) && (m = { label: Ie(m + 4) }, e.defaultQueue = m), e.label = Ie(c + 4);
    }
    z += 1, ht(t, h.requestDevice(e).then((L) => {
      --z, me(() => {
        fe[u >>> 0] = L.queue, fe[o >>> 0] = L, z += 1, ht(n, L.lost.then((q) => {
          me(() => {
            L.onuncapturederror = () => {
            };
            var he = P(), de = Ce(q.message);
            kr(n, Pu[q.reason], de), D(he);
          }), --z;
        })), L.onuncapturederror = (q) => {
          var he = 5;
          q.error instanceof GPUValidationError ? he = 2 : q.error instanceof GPUOutOfMemoryError ? he = 3 : q.error instanceof GPUInternalError && (he = 4);
          var de = P();
          q = Ce(q.error.message), Uo(o, he, q), D(de);
        }, "adapterInfo" in L || (L.adapterInfo = h.info), $r(t, 1, o, 0);
      });
    }, (L) => {
      --z, me(() => {
        var q = P(), he = Ce(L.message);
        $r(t, 3, o, he), n && kr(n, 4, he), D(q);
      });
    }));
  }
  function _u(e) {
    var t = B(e >>>= 0), n = Re[e];
    if (n) {
      for (var o = 0; o < n.length; ++o) n[o]();
      delete Re[e];
    }
    t.destroy();
  }
  function Ru(e, t, n) {
    n >>>= 0;
    var o = B(e >>>= 0);
    n == 4294967295 && (n = void 0);
    try {
      var u = o.getMappedRange(t >>> 0, n);
    } catch {
      return 0;
    }
    var c = jr(16, u.byteLength);
    return (d(), X).set(new Uint8Array(u), c >>> 0), Re[e].push(() => ve(c)), c;
  }
  function Nu(e, t, n) {
    n >>>= 0;
    var o = B(e >>>= 0);
    n == 4294967295 && (n = void 0);
    try {
      var u = o.getMappedRange(t >>> 0, n);
    } catch {
      return 0;
    }
    var c = jr(16, u.byteLength);
    return (d(), X).fill(0, c, u.byteLength), Re[e].push(() => {
      new Uint8Array(u).set((d(), X).subarray(c >>> 0, c + u.byteLength >>> 0)), ve(c);
    }), c;
  }
  function Wu(e, t, n, o, u) {
    e >>>= 0, t = ue(t), n = ue(n), u >>>= 0;
    var c = B(e);
    Re[e] = [], u == 4294967295 && (u = void 0), z += 1, ht(t, c.mapAsync(n, o >>> 0, u).then(() => {
      --z, me(() => {
        Fr(t, 1, 0);
      });
    }, (h) => {
      --z, me(() => {
        P();
        var m = Ce(h.message);
        Fr(t, h.name === "AbortError" ? 4 : h.name === "OperationError" ? 3 : 0, m), delete Re[e];
      });
    }));
  }
  function ku(e) {
    var t = B(e >>>= 0), n = Re[e];
    if (n) {
      for (var o = 0; o < n.length; ++o) n[o]();
      delete Re[e], t.unmap();
    }
  }
  function Fu(e) {
    delete fe[e >>> 0];
  }
  function Gu(e, t, n) {
    e >>>= 0, t >>>= 0, n >>>= 0;
    var o = !!(d(), E)[t + 32 >>> 2 >>> 0];
    t = { label: Ie(t + 4), usage: (d(), E)[t + 16 >>> 2 >>> 0], size: mt(t + 24), mappedAtCreation: o }, e = B(e);
    try {
      var u = e.createBuffer(t);
    } catch {
      return false;
    }
    return fe[n >>> 0] = u, o && (Re[n] = []), true;
  }
  function $u(e, t, n, o) {
    e >>>= 0, t = ue(t), o >>>= 0, n = Eu(n >>> 0), e = B(e), z += 1, ht(t, e.createComputePipelineAsync(n).then((u) => {
      --z, me(() => {
        fe[o >>> 0] = u, Wr(t, 1, o, 0);
      });
    }, (u) => {
      --z, me(() => {
        var c = P(), h = Ce(u.message);
        Wr(t, u.reason === "validation" ? 3 : u.reason === "internal" ? 4 : 0, o, h), D(c);
      });
    }));
  }
  function zu(e, t, n) {
    e >>>= 0, t >>>= 0, n >>>= 0;
    var o = (d(), E)[t >>> 2 >>> 0], u = (d(), I)[o + 4 >>> 2 >>> 0];
    t = { label: Ie(t + 4), code: "" }, u === 2 && (t.code = so(o + 8)), e = B(e).createShaderModule(t), fe[n >>> 0] = e;
  }
  var Vu = (e) => {
    (e = B(e)).onuncapturederror = null, e.destroy();
  };
  function ju(e, t) {
    t = ue(t), e = B(e >>> 0), z += 1, ht(t, e.popErrorScope().then((n) => {
      --z, me(() => {
        var o = 5;
        n ? n instanceof GPUValidationError ? o = 2 : n instanceof GPUOutOfMemoryError ? o = 3 : n instanceof GPUInternalError && (o = 4) : o = 1;
        var u = P(), c = n ? Ce(n.message) : 0;
        Gr(t, 1, o, c), D(u);
      });
    }, (n) => {
      --z, me(() => {
        var o = P(), u = Ce(n.message);
        Gr(t, 1, 5, u), D(o);
      });
    }));
  }
  function Hu(e, t, n, o) {
    if (t = ue(t), o >>>= 0, n >>>= 0) {
      var u = { featureLevel: Iu[(d(), I)[n + 4 >>> 2 >>> 0]], powerPreference: Lu[(d(), I)[n + 8 >>> 2 >>> 0]], forceFallbackAdapter: !!(d(), E)[n + 12 >>> 2 >>> 0] };
      (e = (d(), E)[n >>> 2 >>> 0]) !== 0 && (d(), u.Ye = !!(d(), E)[e + 8 >>> 2 >>> 0]);
    }
    "gpu" in navigator ? (z += 1, ht(t, navigator.gpu.requestAdapter(u).then((c) => {
      --z, me(() => {
        if (c) fe[o >>> 0] = c, St(t, 1, o, 0);
        else {
          var h = P(), m = Ce("WebGPU not available on this browser (requestAdapter returned null)");
          St(t, 3, o, m), D(h);
        }
      });
    }, (c) => {
      --z, me(() => {
        var h = P(), m = Ce(c.message);
        St(t, 4, o, m), D(h);
      });
    }))) : (u = P(), e = Ce("WebGPU not available on this browser (navigator.gpu is not available)"), St(t, 3, o, e), D(u));
  }
  function qu(e, t, n) {
    return e >>>= 0, t >>>= 0, n >>>= 0, Yn(async () => {
      var o = [];
      if (n) {
        var u = (d(), I)[n >>> 2 >>> 0];
        o.length = t + 1, o[t] = new Promise((m) => setTimeout(m, u, 0));
      } else o.length = t;
      for (var c = 0; c < t; ++c) {
        var h = mt(e + 8 * c);
        if (!(h in Gt)) return h;
        o[c] = Gt[h];
      }
      return o = await Promise.race(o), delete Gt[o], o;
    });
  }
  var _r, Rr = {}, lo = () => {
    if (!_r) {
      var e, t = { USER: "web_user", LOGNAME: "web_user", PATH: "/", PWD: "/", HOME: "/home/web_user", LANG: (globalThis.navigator?.language ?? "C").replace("-", "_") + ".UTF-8", _: "./this.program" };
      for (e in Rr) Rr[e] === void 0 ? delete t[e] : t[e] = Rr[e];
      var n = [];
      for (e in t) n.push(`${e}=${t[e]}`);
      _r = n;
    }
    return _r;
  };
  function po(e, t) {
    if (i) return H(19, 1, e, t);
    e >>>= 0, t >>>= 0;
    var n, o = 0, u = 0;
    for (n of lo()) {
      var c = t + o;
      (d(), E)[e + u >>> 2 >>> 0] = c, o += Ue(n, c, 1 / 0) + 1, u += 4;
    }
    return 0;
  }
  function mo(e, t) {
    if (i) return H(20, 1, e, t);
    e >>>= 0, t >>>= 0;
    var n = lo();
    for (var o of ((d(), E)[e >>> 2 >>> 0] = n.length, e = 0, n)) e += _e(o) + 1;
    return (d(), E)[t >>> 2 >>> 0] = e, 0;
  }
  function ho(e) {
    return i ? H(21, 1, e) : 52;
  }
  function bo(e, t, n, o, u) {
    return i ? H(22, 1, e, t, n, o, u) : 52;
  }
  function go(e, t, n, o) {
    return i ? H(23, 1, e, t, n, o) : 52;
  }
  function yo(e, t, n, o) {
    return i ? H(24, 1, e, t, n, o) : 70;
  }
  var Yu = [null, [], []];
  function wo(e, t, n, o) {
    if (i) return H(25, 1, e, t, n, o);
    t >>>= 0, n >>>= 0, o >>>= 0;
    for (var u = 0, c = 0; c < n; c++) {
      var h = (d(), E)[t >>> 2 >>> 0], m = (d(), E)[t + 4 >>> 2 >>> 0];
      t += 8;
      for (var y = 0; y < m; y++) {
        var x = e, N = (d(), X)[h + y >>> 0], F = Yu[x];
        N === 0 || N === 10 ? ((x === 1 ? Y : O)(Bn(F)), F.length = 0) : F.push(N);
      }
      u += m;
    }
    return (d(), E)[o >>> 2 >>> 0] = u, 0;
  }
  function Ju(e) {
    return e >>> 0;
  }
  function Xu(e, t) {
    return io(B(e >>> 0).limits, t >>> 0), 1;
  }
  function Zu(e, t) {
    return B(e >>> 0).features.has(uo[t]);
  }
  function Ku(e) {
    return BigInt(B(e >>> 0).size);
  }
  function Qu(e) {
    return BigInt(B(e >>> 0).usage);
  }
  function ef(e, t) {
    if (e >>>= 0, t >>>= 0) {
      var n = Ie(t + 4);
      n = { label: n, timestampWrites: t = (t = (d(), E)[t + 12 >>> 2 >>> 0]) !== 0 ? { querySet: B((d(), E)[t + 4 >>> 2 >>> 0]), beginningOfPassWriteIndex: (d(), E)[t + 8 >>> 2 >>> 0], endOfPassWriteIndex: (d(), E)[t + 12 >>> 2 >>> 0] } : void 0 };
    }
    return t = B(e), e = Bo(0), n = t.beginComputePass(n), fe[e >>> 0] = n, e;
  }
  function tf(e, t, n, o) {
    n = ue(n), (o = ue(o)) == -1 && (o = void 0), (e = B(e >>> 0)).clearBuffer(B(t >>> 0), n, o);
  }
  function rf(e, t, n, o, u, c) {
    n = ue(n), u = ue(u), c = ue(c), B(e >>> 0).copyBufferToBuffer(B(t >>> 0), n, B(o >>> 0), u, c);
  }
  function nf(e) {
    var t = B(e >>> 0);
    return e = Io(0), t = t.finish(), fe[e >>> 0] = t, e;
  }
  function of(e, t, n, o, u, c) {
    c = ue(c), B(e >>> 0).resolveQuerySet(B(t >>> 0), n, o, B(u >>> 0), c);
  }
  function af(e, t, n, o) {
    B(e >>> 0).dispatchWorkgroups(t, n, o);
  }
  function sf(e, t, n) {
    n = ue(n), B(e >>> 0).dispatchWorkgroupsIndirect(B(t >>> 0), n);
  }
  function uf(e) {
    B(e >>> 0).end();
  }
  function ff(e, t, n, o, u) {
    o >>>= 0, u >>>= 0, e = B(e >>> 0), n = B(n >>> 0), o == 0 ? e.setBindGroup(t, n) : e.setBindGroup(t, n, (d(), E), u >>> 2, o);
  }
  function cf(e, t) {
    B(e >>> 0).setPipeline(B(t >>> 0));
  }
  function df(e, t, n) {
    B(e >>> 0).Xe(B(t >>> 0), n);
  }
  function lf(e, t) {
    function n(u) {
      var c = (d(), E)[u + 8 >>> 2 >>> 0], h = (d(), E)[u + 32 >>> 2 >>> 0], m = (d(), E)[u + 36 >>> 2 >>> 0], y = 0;
      return Ur(u, { 14: (x) => {
        y = (d(), E)[x + 8 >>> 2 >>> 0];
      } }), c ? ((h = mt(u + 24)) == -1 && (h = void 0), c = { buffer: B(c), offset: mt(u + 16), size: h }) : c = B(h || m || y), { binding: (d(), E)[u + 4 >>> 2 >>> 0], resource: c };
    }
    e >>>= 0, t = { label: Ie((t >>>= 0) + 4), layout: B((d(), E)[t + 12 >>> 2 >>> 0]), entries: (function(u, c) {
      for (var h = [], m = 0; m < u; ++m) h.push(n(c + 40 * m));
      return h;
    })((d(), E)[t + 16 >>> 2 >>> 0], (d(), E)[t + 20 >>> 2 >>> 0]) }, e = B(e);
    var o = xo(0);
    return ao(o, e.createBindGroup(t)), o;
  }
  function pf(e, t) {
    function n(y) {
      var x = (d(), E)[y + 4 >>> 2 >>> 0];
      if (x) return { type: xu[x], hasDynamicOffset: !!(d(), E)[y + 8 >>> 2 >>> 0], minBindingSize: mt(y + 16) };
    }
    function o(y) {
      if (y = (d(), E)[y + 4 >>> 2 >>> 0]) return { type: Ou[y] };
    }
    function u(y) {
      var x = (d(), E)[y + 4 >>> 2 >>> 0];
      if (x) return { sampleType: Du[x], viewDimension: co[(d(), I)[y + 8 >>> 2 >>> 0]], multisampled: !!(d(), E)[y + 12 >>> 2 >>> 0] };
    }
    function c(y) {
      var x = (d(), E)[y + 4 >>> 2 >>> 0];
      if (x) return { access: Mu[x], format: Cu[(d(), I)[y + 8 >>> 2 >>> 0]], viewDimension: co[(d(), I)[y + 12 >>> 2 >>> 0]] };
    }
    function h(y) {
      var x = { binding: (d(), E)[y + 4 >>> 2 >>> 0], visibility: (d(), E)[y + 8 >>> 2 >>> 0], buffer: n(y + 24), sampler: o(y + 48), texture: u(y + 56), storageTexture: c(y + 72) };
      return Ur(y, { 13: () => {
        x.externalTexture = {};
      } }), x;
    }
    e >>>= 0, t = { label: Ie((t >>>= 0) + 4), entries: (function(y, x) {
      for (var N = [], F = 0; F < y; ++F) N.push(h(x + 88 * F));
      return N;
    })((d(), E)[t + 12 >>> 2 >>> 0], (d(), E)[t + 16 >>> 2 >>> 0]) }, e = B(e);
    var m = Ao(0);
    return ao(m, e.createBindGroupLayout(t)), m;
  }
  function mf(e, t) {
    var n;
    return e >>>= 0, (t >>>= 0) && (n = { label: Ie(t + 4) }), t = B(e), e = Lo(0), n = t.createCommandEncoder(n), fe[e >>> 0] = n, e;
  }
  function hf(e, t) {
    e >>>= 0, t >>>= 0;
    for (var n = (d(), E)[t + 12 >>> 2 >>> 0], o = (d(), E)[t + 16 >>> 2 >>> 0], u = [], c = 0; c < n; ++c) u.push(B((d(), E)[o + 4 * c >>> 2 >>> 0]));
    return t = { label: Ie(t + 4), bindGroupLayouts: u, immediateSize: (d(), E)[t + 20 >>> 2 >>> 0] }, n = B(e), e = Oo(0), t = n.createPipelineLayout(t), fe[e >>> 0] = t, e;
  }
  function bf(e, t) {
    e >>>= 0, t >>>= 0, t = { type: Bu[(d(), I)[t + 12 >>> 2 >>> 0]], count: (d(), E)[t + 16 >>> 2 >>> 0] };
    var n = B(e);
    return e = Mo(0), t = n.createQuerySet(t), fe[e >>> 0] = t, e;
  }
  function gf(e, t) {
    return Su(B(e >>> 0).adapterInfo, t >>> 0), 1;
  }
  var yf = { "core-features-and-limits": 1, "depth-clip-control": 2, "depth32float-stencil8": 3, "texture-compression-bc": 4, "texture-compression-bc-sliced-3d": 5, "texture-compression-etc2": 6, "texture-compression-astc": 7, "texture-compression-astc-sliced-3d": 8, "timestamp-query": 9, "indirect-first-instance": 10, "shader-f16": 11, "rg11b10ufloat-renderable": 12, "bgra8unorm-storage": 13, "float32-filterable": 14, "float32-blendable": 15, "clip-distances": 16, "dual-source-blending": 17, subgroups: 18, "texture-formats-tier1": 19, "texture-formats-tier2": 20, "primitive-index": 21, "texture-component-swizzle": 22, "subgroup-size-control": 23, "chromium-experimental-unorm16-texture-formats": 327692, "chromium-experimental-multi-draw-indirect": 327729, "chromium-experimental-subgroup-matrix": 327732 };
  function wf(e, t) {
    t >>>= 0;
    var n = B(e >>> 0);
    e = Ke(4 * n.features.size);
    var o = 0, u = 0;
    for (let c of n.features) 0 <= (n = yf[c]) && ((d(), I)[e + o >>> 2 >>> 0] = n, o += 4, u++);
    (d(), E)[t + 4 >>> 2 >>> 0] = e, (d(), E)[t >>> 2 >>> 0] = u;
  }
  function Tf(e, t) {
    return io(B(e >>> 0).limits, t >>> 0), 1;
  }
  function vf(e, t) {
    B(e >>> 0).pushErrorScope(Au[t]);
  }
  function Ef(e, t, n) {
    t >>>= 0, n >>>= 0, e = B(e >>> 0), t = Array.from((d(), I).subarray(n >>> 2 >>> 0, n + 4 * t >>> 2 >>> 0), (o) => B(o)), e.submit(t);
  }
  function Sf(e, t, n, o, u) {
    n = ue(n), o >>>= 0, u >>>= 0, e = B(e >>> 0), t = B(t >>> 0), o = (d(), X).subarray(o >>> 0, o + u >>> 0), e.writeBuffer(t, n, o, 0, u);
  }
  i || (function() {
    for (var e = r.numThreads - 1; e--; ) vn();
    xe.push(async () => {
      var t = (async function() {
        if (!i) return Promise.all(We.map(Tn));
      })();
      Be++, await t, --Be == 0 && re && (t = re, re = null, t());
    });
  })(), i || (ke = new WebAssembly.Memory({ initial: 256, maximum: 65536, shared: true }), se()), r.wasmBinary && (v = r.wasmBinary), r.stackSave = () => P(), r.stackRestore = (e) => D(e), r.stackAlloc = (e) => Vt(e), r.setValue = function(e, t, n = "i8") {
    switch (n.endsWith("*") && (n = "*"), n) {
      case "i1":
      case "i8":
        (d(), Z)[e >>> 0] = t;
        break;
      case "i16":
        (d(), De)[e >>> 1 >>> 0] = t;
        break;
      case "i32":
        (d(), I)[e >>> 2 >>> 0] = t;
        break;
      case "i64":
        (d(), pe)[e >>> 3 >>> 0] = BigInt(t);
        break;
      case "float":
        (d(), R)[e >>> 2 >>> 0] = t;
        break;
      case "double":
        (d(), ae)[e >>> 3 >>> 0] = t;
        break;
      case "*":
        (d(), E)[e >>> 2 >>> 0] = t;
        break;
      default:
        we(`invalid type for setValue: ${n}`);
    }
  }, r.getValue = function(e, t = "i8") {
    switch (t.endsWith("*") && (t = "*"), t) {
      case "i1":
      case "i8":
        return (d(), Z)[e >>> 0];
      case "i16":
        return (d(), De)[e >>> 1 >>> 0];
      case "i32":
        return (d(), I)[e >>> 2 >>> 0];
      case "i64":
        return (d(), pe)[e >>> 3 >>> 0];
      case "float":
        return (d(), R)[e >>> 2 >>> 0];
      case "double":
        return (d(), ae)[e >>> 3 >>> 0];
      case "*":
        return (d(), E)[e >>> 2 >>> 0];
      default:
        we(`invalid type for getValue: ${t}`);
    }
  }, r.UTF8ToString = lt, r.stringToUTF8 = Ue, r.lengthBytesUTF8 = _e;
  var To, vo, Eo, Nr, zt, ve, Ke, So, xo, Ao, Io, Lo, Bo, Oo, Mo, Co, Do, Po, Wr, kr, Fr, Gr, St, $r, Uo, zr, _o, Ro, No, Vr, Wo, ko, jr, W, xt, Fo, D, Vt, P, Go, Hr, $o, zo, Vo, qr, jo, Ho, qo, Yo, Jo, Xo, Zo, Ko, Qo, ea, ta, ra, na, oa, aa, sa, ia, ua, fa, ca, da, la, pa, ma, ha, ba, ga, ya, wa, Ta, va, Ea, Sa, xa, Aa, Ia, La, Ba, Oa, Ma, Ca, Ne, xf = [Ye, Tr, xn, On, Mn, Cn, Dn, Pn, Un, _n, Rn, Nn, Wn, kn, Fn, Gn, Qn, eo, to, po, mo, ho, bo, go, yo, wo], Yr = { 1274364: (e, t, n, o, u) => {
    if (r === void 0 || !r.ed) return 1;
    if ((e = lt(Number(e >>> 0))).startsWith("./") && (e = e.substring(2)), !(e = r.ed.get(e))) return 2;
    if (t = Number(t >>> 0), n = Number(n >>> 0), o = Number(o >>> 0), t + n > e.byteLength) return 3;
    try {
      let c = e.subarray(t, t + n);
      switch (u) {
        case 0:
          (d(), X).set(c, o >>> 0);
          break;
        case 1:
          r.pe ? r.pe(o, c) : r.Re(o, c);
          break;
        default:
          return 4;
      }
      return 0;
    } catch {
      return 4;
    }
  }, 1275188: (e, t, n) => {
    r.re(e, (d(), X).subarray(t >>> 0, t + n >>> 0));
  }, 1275252: () => r.Pe(), 1275294: (e) => {
    r.qe(e);
  }, 1275331: () => typeof wasmOffsetConverter < "u" };
  function Af() {
    return typeof wasmOffsetConverter < "u";
  }
  function If(e, t, n, o) {
    var u = P();
    try {
      return Ko(e, t, n, o);
    } catch (c) {
      if (D(u), c !== c + 0) throw c;
      W(1, 0);
    }
  }
  function Lf(e, t, n) {
    var o = P();
    try {
      return Jo(e, t, n);
    } catch (u) {
      if (D(o), u !== u + 0) throw u;
      W(1, 0);
    }
  }
  function Bf(e) {
    var t = P();
    try {
      jo(e);
    } catch (n) {
      if (D(t), n !== n + 0) throw n;
      W(1, 0);
    }
  }
  function Of(e, t) {
    var n = P();
    try {
      return qr(e, t);
    } catch (o) {
      if (D(n), o !== o + 0) throw o;
      W(1, 0);
    }
  }
  function Mf(e, t, n) {
    var o = P();
    try {
      Vo(e, t, n);
    } catch (u) {
      if (D(o), u !== u + 0) throw u;
      W(1, 0);
    }
  }
  function Cf(e, t) {
    var n = P();
    try {
      Qo(e, t);
    } catch (o) {
      if (D(n), o !== o + 0) throw o;
      W(1, 0);
    }
  }
  function Df(e, t, n, o, u, c, h) {
    var m = P();
    try {
      return Yo(e, t, n, o, u, c, h);
    } catch (y) {
      if (D(m), y !== y + 0) throw y;
      W(1, 0);
    }
  }
  function Pf(e, t, n, o, u, c) {
    var h = P();
    try {
      Ho(e, t, n, o, u, c);
    } catch (m) {
      if (D(h), m !== m + 0) throw m;
      W(1, 0);
    }
  }
  function Uf(e, t, n, o) {
    var u = P();
    try {
      Zo(e, t, n, o);
    } catch (c) {
      if (D(u), c !== c + 0) throw c;
      W(1, 0);
    }
  }
  function _f(e, t, n, o, u, c, h) {
    var m = P();
    try {
      ta(e, t, n, o, u, c, h);
    } catch (y) {
      if (D(m), y !== y + 0) throw y;
      W(1, 0);
    }
  }
  function Rf(e, t, n, o, u, c, h) {
    var m = P();
    try {
      ra(e, t, n, o, u, c, h);
    } catch (y) {
      if (D(m), y !== y + 0) throw y;
      W(1, 0);
    }
  }
  function Nf(e, t, n, o, u, c, h, m) {
    var y = P();
    try {
      la(e, t, n, o, u, c, h, m);
    } catch (x) {
      if (D(y), x !== x + 0) throw x;
      W(1, 0);
    }
  }
  function Wf(e, t, n, o, u, c, h, m, y, x, N, F) {
    var L = P();
    try {
      na(e, t, n, o, u, c, h, m, y, x, N, F);
    } catch (q) {
      if (D(L), q !== q + 0) throw q;
      W(1, 0);
    }
  }
  function kf(e, t, n, o, u) {
    var c = P();
    try {
      return ea(e, t, n, o, u);
    } catch (h) {
      if (D(c), h !== h + 0) throw h;
      W(1, 0);
    }
  }
  function Ff(e, t, n, o, u, c) {
    var h = P();
    try {
      pa(e, t, n, o, u, c);
    } catch (m) {
      if (D(h), m !== m + 0) throw m;
      W(1, 0);
    }
  }
  function Gf(e, t, n, o, u) {
    var c = P();
    try {
      qo(e, t, n, o, u);
    } catch (h) {
      if (D(c), h !== h + 0) throw h;
      W(1, 0);
    }
  }
  function $f(e, t, n, o, u, c, h, m) {
    var y = P();
    try {
      Xo(e, t, n, o, u, c, h, m);
    } catch (x) {
      if (D(y), x !== x + 0) throw x;
      W(1, 0);
    }
  }
  function zf(e) {
    var t = P();
    try {
      return ma(e);
    } catch (n) {
      if (D(t), n !== n + 0) throw n;
      W(1, 0);
    }
  }
  function Vf(e, t, n, o, u, c, h, m, y) {
    var x = P();
    try {
      aa(e, t, n, o, u, c, h, m, y);
    } catch (N) {
      if (D(x), N !== N + 0) throw N;
      W(1, 0);
    }
  }
  function jf(e, t, n) {
    var o = P();
    try {
      return ha(e, t, n);
    } catch (u) {
      if (D(o), u !== u + 0) throw u;
      W(1, 0);
    }
  }
  function Hf(e, t) {
    var n = P();
    try {
      return La(e, t);
    } catch (o) {
      if (D(n), o !== o + 0) throw o;
      return W(1, 0), 0n;
    }
  }
  function qf(e, t, n, o) {
    var u = P();
    try {
      return ba(e, t, n, o);
    } catch (c) {
      if (D(u), c !== c + 0) throw c;
      W(1, 0);
    }
  }
  function Yf(e) {
    var t = P();
    try {
      return oa(e);
    } catch (n) {
      if (D(t), n !== n + 0) throw n;
      return W(1, 0), 0n;
    }
  }
  function Jf(e, t, n, o) {
    var u = P();
    try {
      return ga(e, t, n, o);
    } catch (c) {
      if (D(u), c !== c + 0) throw c;
      W(1, 0);
    }
  }
  function Xf(e, t, n, o, u) {
    var c = P();
    try {
      return ya(e, t, n, o, u);
    } catch (h) {
      if (D(c), h !== h + 0) throw h;
      W(1, 0);
    }
  }
  function Zf(e, t, n, o, u, c) {
    var h = P();
    try {
      return wa(e, t, n, o, u, c);
    } catch (m) {
      if (D(h), m !== m + 0) throw m;
      W(1, 0);
    }
  }
  function Kf(e, t, n, o, u, c) {
    var h = P();
    try {
      return ca(e, t, n, o, u, c);
    } catch (m) {
      if (D(h), m !== m + 0) throw m;
      W(1, 0);
    }
  }
  function Qf(e, t, n, o, u, c) {
    var h = P();
    try {
      return Ta(e, t, n, o, u, c);
    } catch (m) {
      if (D(h), m !== m + 0) throw m;
      W(1, 0);
    }
  }
  function ec(e, t, n, o, u, c, h, m) {
    var y = P();
    try {
      return da(e, t, n, o, u, c, h, m);
    } catch (x) {
      if (D(y), x !== x + 0) throw x;
      W(1, 0);
    }
  }
  function tc(e, t, n, o, u) {
    var c = P();
    try {
      return va(e, t, n, o, u);
    } catch (h) {
      if (D(c), h !== h + 0) throw h;
      return W(1, 0), 0n;
    }
  }
  function rc(e, t, n, o) {
    var u = P();
    try {
      return Ea(e, t, n, o);
    } catch (c) {
      if (D(u), c !== c + 0) throw c;
      W(1, 0);
    }
  }
  function nc(e, t, n, o) {
    var u = P();
    try {
      return Sa(e, t, n, o);
    } catch (c) {
      if (D(u), c !== c + 0) throw c;
      W(1, 0);
    }
  }
  function oc(e, t, n, o, u, c, h, m, y, x, N, F) {
    var L = P();
    try {
      return xa(e, t, n, o, u, c, h, m, y, x, N, F);
    } catch (q) {
      if (D(L), q !== q + 0) throw q;
      W(1, 0);
    }
  }
  function ac(e, t, n, o, u, c, h, m, y, x, N) {
    var F = P();
    try {
      Aa(e, t, n, o, u, c, h, m, y, x, N);
    } catch (L) {
      if (D(F), L !== L + 0) throw L;
      W(1, 0);
    }
  }
  function sc(e, t, n, o, u, c, h, m, y, x, N, F, L, q, he, de) {
    var Qe = P();
    try {
      Ia(e, t, n, o, u, c, h, m, y, x, N, F, L, q, he, de);
    } catch (et) {
      if (D(Qe), et !== et + 0) throw et;
      W(1, 0);
    }
  }
  function ic(e, t, n) {
    var o = P();
    try {
      return ia(e, t, n);
    } catch (u) {
      if (D(o), u !== u + 0) throw u;
      return W(1, 0), 0n;
    }
  }
  function uc(e, t, n) {
    var o = P();
    try {
      return sa(e, t, n);
    } catch (u) {
      if (D(o), u !== u + 0) throw u;
      W(1, 0);
    }
  }
  function fc(e, t, n) {
    var o = P();
    try {
      return ua(e, t, n);
    } catch (u) {
      if (D(o), u !== u + 0) throw u;
      W(1, 0);
    }
  }
  function cc(e, t, n, o) {
    var u = P();
    try {
      fa(e, t, n, o);
    } catch (c) {
      if (D(u), c !== c + 0) throw c;
      W(1, 0);
    }
  }
  function jt() {
    if (0 < Be) re = jt;
    else if (i) C?.(r), wr();
    else {
      for (var e = xe; 0 < e.length; ) e.shift()(r);
      0 < Be ? re = jt : (r.calledRun = true, $ || (wr(), C?.(r)));
    }
  }
  return i || (Ne = await wt(), jt()), r.PTR_SIZE = 4, r.webgpuInit = (e) => {
    let t = /* @__PURE__ */ new WeakMap(), n, o, u = 1;
    r.webgpuRegisterDevice = (m) => {
      if (o !== void 0) throw Error("another WebGPU EP inference session is being created.");
      if (m) {
        var y = t.get(m);
        if (!y) {
          let x = ((N, F = 0) => {
            var L = Po(F);
            return F = Do(F, L), fe[L >>> 0] = N.queue, fe[F >>> 0] = N, F;
          })(m, y = Eo());
          y = [u++, y, x], t.set(m, y);
        }
        return n = m, o = y[0], y;
      }
      n = void 0, o = 0;
    };
    let c = /* @__PURE__ */ new Map();
    r.webgpuOnCreateSession = (m) => {
      if (o !== void 0) {
        var y = o;
        if (o = void 0, m) {
          let x = Nr(y);
          c.set(m, x), y === 0 && e(n ?? B(x));
        }
        n = void 0;
      }
    }, r.webgpuOnReleaseSession = (m) => {
      c.delete(m);
    };
    let h = /* @__PURE__ */ Symbol("gpuBufferMetadata");
    r.webgpuRegisterBuffer = (m, y, x) => {
      if (x) return m[h] = [x, NaN], x;
      if (x = m[h]) return x[1]++, x[0];
      if ((y = c.get(y)) === void 0) throw Error("Invalid session handle passed to webgpuRegisterBuffer");
      return y = ((N, F = 0) => (N.mapState === "unmapped" || we(), F = Co(F), fe[F >>> 0] = N, F))(m, y), m[h] = [y, 1], y;
    }, r.webgpuUnregisterBuffer = (m) => {
      let y = m[h];
      if (!y) throw Error("Buffer is not registered");
      y[1]--, y[1] === 0 && (So(y[0]), delete m[h]);
    }, r.webgpuGetBuffer = (m) => B(m), r.webgpuCreateDownloader = (m, y, x) => {
      if ((x = c.get(x)) === void 0) throw Error("Invalid session handle passed to webgpuRegisterBuffer");
      let N = B(x), F = 16 * Math.ceil(Number(y) / 16);
      return async () => {
        let L = N.createBuffer({ size: F, usage: 9 });
        try {
          let q = N.createCommandEncoder();
          return q.copyBufferToBuffer(m, 0, L, 0, F), N.queue.submit([q.finish()]), await L.mapAsync(GPUMapMode.READ), L.getMappedRange().slice(0, y);
        } finally {
          L.destroy();
        }
      };
    }, r.pe = (m, y) => {
      var x = y.buffer;
      let N = y.byteOffset, F = y.byteLength;
      if (y = 16 * Math.ceil(Number(F) / 16), m = B(m), !n) {
        var L = Nr(o);
        n = B(L);
      }
      let q = (L = n.createBuffer({ mappedAtCreation: true, size: y, usage: 6 })).getMappedRange();
      new Uint8Array(q).set(new Uint8Array(x, N, F)), L.unmap(), (x = n.createCommandEncoder()).copyBufferToBuffer(L, 0, m, 0, y), n.queue.submit([x.finish()]), L.destroy();
    };
  }, r.webnnInit = (e) => {
    let t = e[0];
    [r.Pe, r.qe, r.webnnEnsureTensor, r.re, r.webnnDownloadTensor, r.Oe, r.webnnEnableTraceEvent] = e.slice(1), r.webnnReleaseTensorId = r.qe, r.webnnUploadTensor = r.re, r.webnnRegisterMLContext = r.Oe, r.webnnOnRunStart = (n) => t.onRunStart(n), r.webnnOnRunEnd = t.onRunEnd.bind(t), r.webnnOnReleaseSession = (n) => {
      t.onReleaseSession(n);
    }, r.webnnCreateMLTensorDownloader = (n, o) => t.createMLTensorDownloader(n, o), r.webnnRegisterMLTensor = (n, o, u, c) => t.registerMLTensor(n, o, u, c), r.webnnCreateMLContext = (n) => t.createMLContext(n), r.webnnRegisterGraphInput = t.registerGraphInput.bind(t), r.webnnIsGraphInput = t.isGraphInput.bind(t), r.webnnRegisterGraphOutput = t.registerGraphOutput.bind(t), r.webnnIsGraphOutput = t.isGraphOutput.bind(t), r.webnnCreateTemporaryTensor = t.createTemporaryTensor.bind(t), r.webnnIsGraphInputOutputTypeSupported = t.isGraphInputOutputTypeSupported.bind(t);
  }, ne ? r : new Promise((e, t) => {
    C = e, _ = t;
  });
}
var yc;
var wc;
var ms = G(() => {
  "use strict";
  yc = ls, wc = globalThis.self?.name?.startsWith("em-pthread");
  wc && ls();
});
var gs;
var an;
var Tc;
var ye;
var ys;
var on;
var vc;
var Ec;
var ws;
var Sc;
var hs;
var Ts;
var bs;
var vs;
var Zt = G(() => {
  "use strict";
  Xt();
  gs = typeof location > "u" ? void 0 : location.origin, an = import.meta.url > "file:" && import.meta.url < "file;", Tc = () => {
    if (true) {
      if (an) {
        let a = URL;
        return new URL(new a("ort.webgpu.bundle.min.mjs", import.meta.url).href, gs).href;
      }
      return import.meta.url;
    }
  }, ye = Tc(), ys = () => {
    if (ye && !ye.startsWith("blob:")) return ye.substring(0, ye.lastIndexOf("/") + 1);
  }, on = (a, r) => {
    try {
      let s = r ?? ye;
      return (s ? new URL(a, s) : new URL(a)).origin === gs;
    } catch {
      return false;
    }
  }, vc = (a, r) => {
    let s = r ?? ye;
    try {
      return (s ? new URL(a, s) : new URL(a)).href;
    } catch {
      return;
    }
  }, Ec = (a, r) => `${r ?? "./"}${a}`, ws = async (a) => {
    let s = await (await fetch(a, { credentials: "same-origin" })).blob();
    return URL.createObjectURL(s);
  }, Sc = async (a) => (await import(
    /*webpackIgnore:true*/
    /*@vite-ignore*/
    a
  )).default, hs = (ds(), Ht(cs)).default, Ts = async () => {
    if (!ye) throw new Error("Failed to load proxy worker: cannot determine the script source URL.");
    if (on(ye)) return [void 0, hs()];
    let a = await ws(ye);
    return [a, hs(a)];
  }, bs = (ms(), Ht(ps)).default, vs = async (a, r, s, f) => {
    let i = bs && !(a || r);
    if (i) if (ye) i = on(ye) || f && !s;
    else if (f && !s) i = true;
    else throw new Error("cannot determine the script source URL.");
    if (i) return [void 0, bs];
    {
      let p = "ort-wasm-simd-threaded.asyncify.mjs", l = a ?? vc(p, r), b = s && l && !on(l, r), g = b ? await ws(l) : l ?? Ec(p, r);
      return [b ? g : void 0, await Sc(g)];
    }
  };
});
var sn;
var un;
var sr;
var Es;
var xc;
var Ac;
var Ic;
var Kt;
var j;
var Ve = G(() => {
  "use strict";
  Zt();
  un = false, sr = false, Es = false, xc = () => {
    if (typeof SharedArrayBuffer > "u") return false;
    try {
      return typeof MessageChannel < "u" && new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)), WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 5, 4, 1, 3, 1, 1, 10, 11, 1, 9, 0, 65, 0, 254, 16, 2, 0, 26, 11]));
    } catch {
      return false;
    }
  }, Ac = () => {
    try {
      return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 10, 30, 1, 28, 0, 65, 0, 253, 15, 253, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 253, 186, 1, 26, 11]));
    } catch {
      return false;
    }
  }, Ic = () => {
    try {
      return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0, 10, 19, 1, 17, 0, 65, 1, 253, 15, 65, 2, 253, 15, 65, 3, 253, 15, 253, 147, 2, 11]));
    } catch {
      return false;
    }
  }, Kt = async (a) => {
    if (un) return Promise.resolve();
    if (sr) throw new Error("multiple calls to 'initializeWebAssembly()' detected.");
    if (Es) throw new Error("previous call to 'initializeWebAssembly()' failed.");
    sr = true;
    let r = a.initTimeout, s = a.numThreads;
    if (a.simd !== false) {
      if (a.simd === "relaxed") {
        if (!Ic()) throw new Error("Relaxed WebAssembly SIMD is not supported in the current environment.");
      } else if (!Ac()) throw new Error("WebAssembly SIMD is not supported in the current environment.");
    }
    let f = xc();
    s > 1 && !f && (typeof self < "u" && !self.crossOriginIsolated && console.warn("env.wasm.numThreads is set to " + s + ", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."), console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."), a.numThreads = s = 1);
    let i = a.wasmPaths, p = typeof i == "string" ? i : void 0, l = i?.mjs, b = l?.href ?? l, g = i?.wasm, w = g?.href ?? g, S = a.wasmBinary, [v, T] = await vs(b, p, s > 1, !!S || !!w), A = false, C = [];
    if (r > 0 && C.push(new Promise((_) => {
      setTimeout(() => {
        A = true, _();
      }, r);
    })), C.push(new Promise((_, k) => {
      let U = { numThreads: s };
      if (S) U.wasmBinary = S, U.locateFile = (M) => M;
      else if (w || p) U.locateFile = (M) => w ?? p + M;
      else if (b && b.indexOf("blob:") !== 0) U.locateFile = (M) => new URL(M, b).href;
      else if (v) {
        let M = ys();
        M && (U.locateFile = (Y) => M + Y);
      }
      T(U).then((M) => {
        sr = false, un = true, sn = M, _(), v && URL.revokeObjectURL(v);
      }, (M) => {
        sr = false, Es = true, k(M);
      });
    })), await Promise.race(C), A) throw new Error(`WebAssembly backend initializing failed due to timeout: ${r}ms`);
  }, j = () => {
    if (un && sn) return sn;
    throw new Error("WebAssembly is not initialized yet.");
  };
});
var be;
var Bt;
var V;
var ir = G(() => {
  "use strict";
  Ve();
  be = (a, r) => {
    let s = j(), f = s.lengthBytesUTF8(a) + 1, i = s._malloc(f);
    return s.stringToUTF8(a, i, f), r.push(i), i;
  }, Bt = (a, r, s, f) => {
    if (typeof a == "object" && a !== null) {
      if (s.has(a)) throw new Error("Circular reference in options");
      s.add(a);
    }
    Object.entries(a).forEach(([i, p]) => {
      let l = r ? r + i : i;
      if (typeof p == "object") Bt(p, l + ".", s, f);
      else if (typeof p == "string" || typeof p == "number") f(l, p.toString());
      else if (typeof p == "boolean") f(l, p ? "1" : "0");
      else throw new Error(`Can't handle extra config type: ${typeof p}`);
    });
  }, V = (a) => {
    let r = j(), s = r.stackSave();
    try {
      let f = r.PTR_SIZE, i = r.stackAlloc(2 * f);
      r._OrtGetLastError(i, i + f);
      let p = Number(r.getValue(i, f === 4 ? "i32" : "i64")), l = r.getValue(i + f, "*"), b = l ? r.UTF8ToString(l) : "";
      throw new Error(`${a} ERROR_CODE: ${p}, ERROR_MESSAGE: ${b}`);
    } finally {
      r.stackRestore(s);
    }
  };
});
var Ss;
var xs = G(() => {
  "use strict";
  Ve();
  ir();
  Ss = (a) => {
    let r = j(), s = 0, f = [], i = a || {};
    try {
      if (a?.logSeverityLevel === void 0) i.logSeverityLevel = 2;
      else if (typeof a.logSeverityLevel != "number" || !Number.isInteger(a.logSeverityLevel) || a.logSeverityLevel < 0 || a.logSeverityLevel > 4) throw new Error(`log severity level is not valid: ${a.logSeverityLevel}`);
      if (a?.logVerbosityLevel === void 0) i.logVerbosityLevel = 0;
      else if (typeof a.logVerbosityLevel != "number" || !Number.isInteger(a.logVerbosityLevel)) throw new Error(`log verbosity level is not valid: ${a.logVerbosityLevel}`);
      a?.terminate === void 0 && (i.terminate = false);
      let p = 0;
      return a?.tag !== void 0 && (p = be(a.tag, f)), s = r._OrtCreateRunOptions(i.logSeverityLevel, i.logVerbosityLevel, !!i.terminate, p), s === 0 && V("Can't create run options."), a?.extra !== void 0 && Bt(a.extra, "", /* @__PURE__ */ new WeakSet(), (l, b) => {
        let g = be(l, f), w = be(b, f);
        r._OrtAddRunConfigEntry(s, g, w) !== 0 && V(`Can't set a run config entry: ${l} - ${b}.`);
      }), [s, f];
    } catch (p) {
      throw s !== 0 && r._OrtReleaseRunOptions(s), f.forEach((l) => r._free(l)), p;
    }
  };
});
var Lc;
var Bc;
var Oc;
var Ot;
var je;
var Mc;
var As;
var Is = G(() => {
  "use strict";
  Ve();
  ir();
  Lc = (a) => {
    switch (a) {
      case "disabled":
        return 0;
      case "basic":
        return 1;
      case "extended":
        return 2;
      case "layout":
        return 3;
      case "all":
        return 99;
      default:
        throw new Error(`unsupported graph optimization level: ${a}`);
    }
  }, Bc = (a) => {
    switch (a) {
      case "sequential":
        return 0;
      case "parallel":
        return 1;
      default:
        throw new Error(`unsupported execution mode: ${a}`);
    }
  }, Oc = (a) => {
    a.extra || (a.extra = {}), a.extra.session || (a.extra.session = {});
    let r = a.extra.session;
    r.use_ort_model_bytes_directly || (r.use_ort_model_bytes_directly = "1"), a.executionProviders && a.executionProviders.some((s) => (typeof s == "string" ? s : s.name) === "webgpu") && (a.enableMemPattern = false);
  }, Ot = (a, r, s, f) => {
    let i = be(r, f), p = be(s, f);
    j()._OrtAddSessionConfigEntry(a, i, p) !== 0 && V(`Can't set a session config entry: ${r} - ${s}.`);
  }, je = (a, r, s, f) => {
    let i = be(r, f), p = be(s, f);
    a.push([i, p]);
  }, Mc = async (a, r, s) => {
    let f = r.executionProviders;
    for (let i of f) {
      let p = typeof i == "string" ? i : i.name, l = [];
      switch (p) {
        case "webnn":
          if (p = "WEBNN", Ot(a, "session.disable_quant_qdq", "1", s), Ot(a, "session.disable_qdq_constant_folding", "1", s), typeof i != "string") {
            let T = i?.deviceType;
            T && Ot(a, "deviceType", T, s);
          }
          break;
        case "webgpu":
          {
            p = "WebGPU";
            let v;
            if (typeof i != "string") {
              let A = i;
              if (A.device) if (typeof GPUDevice < "u" && A.device instanceof GPUDevice) v = A.device;
              else throw new Error("Invalid GPU device set in WebGPU EP options.");
              let { enableGraphCapture: C } = r;
              if (typeof C == "boolean" && C && je(l, "enableGraphCapture", "1", s), typeof A.preferredLayout == "string" && je(l, "preferredLayout", A.preferredLayout, s), A.forceCpuNodeNames) {
                let _ = Array.isArray(A.forceCpuNodeNames) ? A.forceCpuNodeNames : [A.forceCpuNodeNames];
                je(l, "forceCpuNodeNames", _.join(`
`), s);
              }
              A.validationMode && je(l, "validationMode", A.validationMode, s);
              for (let _ of ["storageBufferCacheMode", "uniformBufferCacheMode", "queryResolveBufferCacheMode", "defaultBufferCacheMode"]) {
                let k = A[_];
                if (k) {
                  if (k !== "disabled" && k !== "lazyRelease" && k !== "simple" && k !== "bucket") throw new Error(`${_} must be one of 'disabled', 'lazyRelease', 'simple' or 'bucket': ${k}`);
                  je(l, _, k, s);
                }
              }
            }
            let T = j().webgpuRegisterDevice(v);
            if (T) {
              let [A, C, _] = T;
              je(l, "deviceId", A.toString(), s), je(l, "webgpuInstance", C.toString(), s), je(l, "webgpuDevice", _.toString(), s);
            }
          }
          break;
        case "wasm":
        case "cpu":
          continue;
        default:
          throw new Error(`not supported execution provider: ${p}`);
      }
      let b = be(p, s), g = l.length, w = 0, S = 0;
      if (g > 0) {
        w = j()._malloc(g * j().PTR_SIZE), s.push(w), S = j()._malloc(g * j().PTR_SIZE), s.push(S);
        for (let v = 0; v < g; v++) j().setValue(w + v * j().PTR_SIZE, l[v][0], "*"), j().setValue(S + v * j().PTR_SIZE, l[v][1], "*");
      }
      await j()._OrtAppendExecutionProvider(a, b, w, S, g) !== 0 && V(`Can't append execution provider: ${p}.`);
    }
  }, As = async (a) => {
    let r = j(), s = 0, f = [], i = a || {};
    Oc(i);
    try {
      let p = Lc(i.graphOptimizationLevel ?? "all"), l = Bc(i.executionMode ?? "sequential"), b = typeof i.logId == "string" ? be(i.logId, f) : 0, g = i.logSeverityLevel ?? 2;
      if (!Number.isInteger(g) || g < 0 || g > 4) throw new Error(`log severity level is not valid: ${g}`);
      let w = i.logVerbosityLevel ?? 0;
      if (!Number.isInteger(w) || w < 0 || w > 4) throw new Error(`log verbosity level is not valid: ${w}`);
      let S = typeof i.optimizedModelFilePath == "string" ? be(i.optimizedModelFilePath, f) : 0;
      if (s = r._OrtCreateSessionOptions(p, !!i.enableCpuMemArena, !!i.enableMemPattern, l, !!i.enableProfiling, 0, b, g, w, S), s === 0 && V("Can't create session options."), i.executionProviders && await Mc(s, i, f), i.enableGraphCapture !== void 0) {
        if (typeof i.enableGraphCapture != "boolean") throw new Error(`enableGraphCapture must be a boolean value: ${i.enableGraphCapture}`);
        Ot(s, "enableGraphCapture", i.enableGraphCapture.toString(), f);
      }
      if (i.freeDimensionOverrides) for (let [v, T] of Object.entries(i.freeDimensionOverrides)) {
        if (typeof v != "string") throw new Error(`free dimension override name must be a string: ${v}`);
        if (typeof T != "number" || !Number.isInteger(T) || T < 0) throw new Error(`free dimension override value must be a non-negative integer: ${T}`);
        let A = be(v, f);
        r._OrtAddFreeDimensionOverride(s, A, T) !== 0 && V(`Can't set a free dimension override: ${v} - ${T}.`);
      }
      return i.extra !== void 0 && Bt(i.extra, "", /* @__PURE__ */ new WeakSet(), (v, T) => {
        Ot(s, v, T, f);
      }), [s, f];
    } catch (p) {
      throw s !== 0 && r._OrtReleaseSessionOptions(s) !== 0 && V("Can't release session options."), f.forEach((l) => r._free(l)), p;
    }
  };
});
var He;
var ur;
var bt;
var it;
var Mt;
var fr;
var cr;
var fn;
var ut = G(() => {
  "use strict";
  He = (a) => {
    switch (a) {
      case "int8":
        return 3;
      case "uint8":
        return 2;
      case "bool":
        return 9;
      case "int16":
        return 5;
      case "uint16":
        return 4;
      case "int32":
        return 6;
      case "uint32":
        return 12;
      case "float16":
        return 10;
      case "float32":
        return 1;
      case "float64":
        return 11;
      case "string":
        return 8;
      case "int64":
        return 7;
      case "uint64":
        return 13;
      case "int4":
        return 22;
      case "uint4":
        return 21;
      default:
        throw new Error(`unsupported data type: ${a}`);
    }
  }, ur = (a) => {
    switch (a) {
      case 3:
        return "int8";
      case 2:
        return "uint8";
      case 9:
        return "bool";
      case 5:
        return "int16";
      case 4:
        return "uint16";
      case 6:
        return "int32";
      case 12:
        return "uint32";
      case 10:
        return "float16";
      case 1:
        return "float32";
      case 11:
        return "float64";
      case 8:
        return "string";
      case 7:
        return "int64";
      case 13:
        return "uint64";
      case 22:
        return "int4";
      case 21:
        return "uint4";
      default:
        throw new Error(`unsupported data type: ${a}`);
    }
  }, bt = (a, r) => {
    let s = [-1, 4, 1, 1, 2, 2, 4, 8, -1, 1, 2, 8, 4, 8, -1, -1, -1, -1, -1, -1, -1, 0.5, 0.5][a], f = typeof r == "number" ? r : r.reduce((i, p) => i * p, 1);
    return s > 0 ? Math.ceil(f * s) : void 0;
  }, it = (a) => {
    switch (a) {
      case "float16":
        return typeof Float16Array < "u" ? Float16Array : Uint16Array;
      case "float32":
        return Float32Array;
      case "uint8":
        return Uint8Array;
      case "int8":
        return Int8Array;
      case "uint16":
        return Uint16Array;
      case "int16":
        return Int16Array;
      case "int32":
        return Int32Array;
      case "bool":
        return Uint8Array;
      case "float64":
        return Float64Array;
      case "uint32":
        return Uint32Array;
      case "int64":
        return BigInt64Array;
      case "uint64":
        return BigUint64Array;
      default:
        throw new Error(`unsupported type: ${a}`);
    }
  }, Mt = (a) => {
    switch (a) {
      case "verbose":
        return 0;
      case "info":
        return 1;
      case "warning":
        return 2;
      case "error":
        return 3;
      case "fatal":
        return 4;
      default:
        throw new Error(`unsupported logging level: ${a}`);
    }
  }, fr = (a) => a === "float32" || a === "float16" || a === "int32" || a === "int64" || a === "uint32" || a === "uint8" || a === "bool" || a === "uint4" || a === "int4", cr = (a) => a === "float32" || a === "float16" || a === "int32" || a === "int64" || a === "uint32" || a === "uint64" || a === "int8" || a === "uint8" || a === "bool" || a === "uint4" || a === "int4", fn = (a) => {
    switch (a) {
      case "none":
        return 0;
      case "cpu":
        return 1;
      case "cpu-pinned":
        return 2;
      case "texture":
        return 3;
      case "gpu-buffer":
        return 4;
      case "ml-tensor":
        return 5;
      default:
        throw new Error(`unsupported data location: ${a}`);
    }
  };
});
var Ct;
var cn = G(() => {
  "use strict";
  Xt();
  Ct = async (a) => {
    if (typeof a == "string") if (false) try {
      let { readFile: r } = Xr("node:fs/promises");
      return new Uint8Array(await r(a));
    } catch (r) {
      if (r.code === "ERR_FS_FILE_TOO_LARGE") {
        let { createReadStream: s } = Xr("node:fs"), f = s(a), i = [];
        for await (let p of f) i.push(p);
        return new Uint8Array(Buffer.concat(i));
      }
      throw r;
    }
    else {
      let r = await fetch(a);
      if (!r.ok) throw new Error(`failed to load external data file: ${a}`);
      let s = r.headers.get("Content-Length"), f = s ? parseInt(s, 10) : 0;
      if (f < 1073741824) return new Uint8Array(await r.arrayBuffer());
      {
        if (!r.body) throw new Error(`failed to load external data file: ${a}, no response body.`);
        let i = r.body.getReader(), p;
        try {
          p = new ArrayBuffer(f);
        } catch (b) {
          if (b instanceof RangeError) {
            let g = Math.ceil(f / 65536);
            p = new WebAssembly.Memory({ initial: g, maximum: g }).buffer;
          } else throw b;
        }
        let l = 0;
        for (; ; ) {
          let { done: b, value: g } = await i.read();
          if (b) break;
          let w = g.byteLength;
          new Uint8Array(p, l, w).set(g), l += w;
        }
        return new Uint8Array(p, 0, f);
      }
    }
    else return a instanceof Blob ? new Uint8Array(await a.arrayBuffer()) : a instanceof Uint8Array ? a : new Uint8Array(a);
  };
});
var Ls;
var Bs = G(() => {
  "use strict";
  ut();
  Ls = (a, r) => new (it(r))(a);
});
var Cc;
var Dc;
var Os;
var Ms;
var Cs;
var Pc;
var le;
var dn = G(() => {
  "use strict";
  ut();
  Cc = ["V", "I", "W", "E", "F"], Dc = (a, r) => {
    console.log(`[${Cc[a]},${(/* @__PURE__ */ new Date()).toISOString()}]${r}`);
  }, Cs = (a, r) => {
    Os = a, Ms = r;
  }, Pc = (a, r) => {
    let s = Mt(a), f = Mt(Os);
    s >= f && Dc(s, typeof r == "function" ? r() : r);
  }, le = (...a) => {
    Ms && Pc(...a);
  };
});
var Ps;
var Uc;
var Us;
var _c;
var Ds;
var Rc;
var _s;
var dr;
var lr;
var ln;
var Rs;
var Ns = G(() => {
  "use strict";
  ut();
  dn();
  Ps = /* @__PURE__ */ new Map([["float32", 32], ["float16", 16], ["int32", 32], ["uint32", 32], ["int64", 64], ["uint64", 64], ["int8", 8], ["uint8", 8], ["int4", 4], ["uint4", 4]]), Uc = (a, r) => {
    if (r === "int32") return a;
    let s = Ps.get(r);
    if (!s) throw new Error(`WebNN backend does not support data type: ${r}`);
    let f = s / 8;
    if (a.byteLength % f !== 0) throw new Error(`Invalid Uint8Array length - must be a multiple of ${f}.`);
    let i = a.byteLength / f, p = new (it(r))(a.buffer, a.byteOffset, i);
    switch (r) {
      case "int64":
      case "uint64": {
        let l = new Int32Array(i);
        for (let b = 0; b < i; b++) {
          let g = p[b];
          if (g > 2147483647n || g < -2147483648n) throw new Error("Can not convert int64 data to int32 - value out of range.");
          l[b] = Number(g);
        }
        return new Uint8Array(l.buffer);
      }
      case "int8":
      case "uint8":
      case "uint32": {
        if (r === "uint32" && p.some((b) => b > 2147483647)) throw new Error("Can not convert uint32 data to int32 - value out of range.");
        let l = Int32Array.from(p, Number);
        return new Uint8Array(l.buffer);
      }
      default:
        throw new Error(`Unsupported data conversion from ${r} to 'int32'`);
    }
  }, Us = (a, r) => {
    if (r === "int32") return a;
    if (a.byteLength % 4 !== 0) throw new Error("Invalid Uint8Array length - must be a multiple of 4 (int32).");
    let s = a.byteLength / 4, f = new Int32Array(a.buffer, a.byteOffset, s);
    switch (r) {
      case "int64": {
        let i = BigInt64Array.from(f, BigInt);
        return new Uint8Array(i.buffer);
      }
      case "uint64": {
        if (f.some((p) => p < 0)) throw new Error("Can not convert int32 data to uin64 - negative value found.");
        let i = BigUint64Array.from(f, BigInt);
        return new Uint8Array(i.buffer);
      }
      case "int8": {
        if (f.some((p) => p < -128 || p > 127)) throw new Error("Can not convert int32 data to int8 - value out of range.");
        let i = Int8Array.from(f, Number);
        return new Uint8Array(i.buffer);
      }
      case "uint8": {
        if (f.some((i) => i < 0 || i > 255)) throw new Error("Can not convert int32 data to uint8 - value out of range.");
        return Uint8Array.from(f, Number);
      }
      case "uint32": {
        if (f.some((p) => p < 0)) throw new Error("Can not convert int32 data to uint32 - negative value found.");
        let i = Uint32Array.from(f, Number);
        return new Uint8Array(i.buffer);
      }
      default:
        throw new Error(`Unsupported data conversion from 'int32' to ${r}`);
    }
  }, _c = 1, Ds = () => _c++, Rc = /* @__PURE__ */ new Map([["int8", "int32"], ["uint8", "int32"], ["uint32", "int32"], ["int64", "int32"]]), _s = (a, r) => {
    let s = Ps.get(a);
    if (!s) throw new Error(`WebNN backend does not support data type: ${a}`);
    return r.length > 0 ? Math.ceil(r.reduce((f, i) => f * i) * s / 8) : 0;
  }, dr = class {
    constructor(r) {
      this.isDataConverted = false;
      let { sessionId: s, context: f, tensor: i, dataType: p, shape: l, fallbackDataType: b } = r;
      this.sessionId = s, this.mlContext = f, this.mlTensor = i, this.dataType = p, this.tensorShape = l, this.fallbackDataType = b;
    }
    get tensor() {
      return this.mlTensor;
    }
    get type() {
      return this.dataType;
    }
    get fallbackType() {
      return this.fallbackDataType;
    }
    get shape() {
      return this.tensorShape;
    }
    get byteLength() {
      return _s(this.dataType, this.tensorShape);
    }
    destroy() {
      le("verbose", () => "[WebNN] TensorWrapper.destroy"), this.mlTensor.destroy();
    }
    write(r) {
      this.mlContext.writeTensor(this.mlTensor, r);
    }
    async read(r) {
      if (this.fallbackDataType) {
        let s = await this.mlContext.readTensor(this.mlTensor), f = Us(new Uint8Array(s), this.dataType);
        if (r) {
          (r instanceof ArrayBuffer ? new Uint8Array(r) : new Uint8Array(r.buffer, r.byteOffset, r.byteLength)).set(f);
          return;
        } else return new Uint8Array(f).buffer;
      } else return r ? this.mlContext.readTensor(this.mlTensor, r) : this.mlContext.readTensor(this.mlTensor);
    }
    canReuseTensor(r, s, f) {
      return this.mlContext === r && this.dataType === s && this.tensorShape.length === f.length && this.tensorShape.every((i, p) => i === f[p]);
    }
    setIsDataConverted(r) {
      this.isDataConverted = r;
    }
  }, lr = class {
    constructor(r, s) {
      this.tensorManager = r;
      this.wrapper = s;
    }
    get tensorWrapper() {
      return this.wrapper;
    }
    releaseTensor() {
      this.tensorWrapper && (this.tensorManager.releaseTensor(this.tensorWrapper), this.wrapper = void 0);
    }
    async ensureTensor(r, s, f, i) {
      let p = this.tensorManager.getMLContext(r), l = this.tensorManager.getMLOpSupportLimits(r), b;
      if (!l?.input.dataTypes.includes(s)) {
        if (b = Rc.get(s), !b || !l?.input.dataTypes.includes(b)) throw new Error(`WebNN backend does not support data type: ${s}`);
        le("verbose", () => `[WebNN] TensorIdTracker.ensureTensor: fallback dataType from ${s} to ${b}`);
      }
      if (this.wrapper) {
        if (this.wrapper.canReuseTensor(p, s, f)) return this.wrapper.tensor;
        if (i) {
          if (this.wrapper.byteLength !== _s(s, f)) throw new Error("Unable to copy data to tensor with different size.");
          this.activeUpload = new Uint8Array(await this.wrapper.read());
        }
        this.tensorManager.releaseTensor(this.wrapper);
      }
      let g = typeof MLTensorUsage > "u" ? void 0 : MLTensorUsage.READ | MLTensorUsage.WRITE;
      return this.wrapper = await this.tensorManager.getCachedTensor(r, s, f, g, true, true, b), i && this.activeUpload && (this.wrapper.write(this.activeUpload), this.activeUpload = void 0), this.wrapper.tensor;
    }
    upload(r) {
      let s = r;
      if (this.wrapper) {
        if (this.wrapper.fallbackType) if (this.wrapper.fallbackType === "int32") s = Uc(r, this.wrapper.type), this.wrapper.setIsDataConverted(true);
        else throw new Error(`Unsupported fallback data type: ${this.wrapper.fallbackType}`);
        if (r.byteLength === this.wrapper.byteLength) {
          this.wrapper.write(s);
          return;
        } else le("verbose", () => "Data size does not match tensor size. Releasing tensor."), this.releaseTensor();
      }
      this.activeUpload ? this.activeUpload.set(s) : this.activeUpload = new Uint8Array(s);
    }
    async download(r) {
      if (this.activeUpload) {
        let s = this.wrapper?.isDataConverted ? Us(this.activeUpload, this.wrapper?.type) : this.activeUpload;
        if (r) {
          r instanceof ArrayBuffer ? new Uint8Array(r).set(s) : new Uint8Array(r.buffer, r.byteOffset, r.byteLength).set(s);
          return;
        } else return s.buffer;
      }
      if (!this.wrapper) throw new Error("Tensor has not been created.");
      return r ? this.wrapper.read(r) : this.wrapper.read();
    }
  }, ln = class {
    constructor(r) {
      this.backend = r;
      this.tensorTrackersById = /* @__PURE__ */ new Map();
      this.freeTensors = [];
      this.externalTensors = /* @__PURE__ */ new Set();
    }
    getMLContext(r) {
      let s = this.backend.getMLContext(r);
      if (!s) throw new Error("MLContext not found for session.");
      return s;
    }
    getMLOpSupportLimits(r) {
      return this.backend.getMLOpSupportLimits(r);
    }
    reserveTensorId() {
      let r = Ds();
      return this.tensorTrackersById.set(r, new lr(this)), r;
    }
    releaseTensorId(r) {
      let s = this.tensorTrackersById.get(r);
      s && (this.tensorTrackersById.delete(r), s.tensorWrapper && this.releaseTensor(s.tensorWrapper));
    }
    async ensureTensor(r, s, f, i, p) {
      le("verbose", () => `[WebNN] TensorManager.ensureTensor {tensorId: ${s}, dataType: ${f}, shape: ${i}, copyOld: ${p}}`);
      let l = this.tensorTrackersById.get(s);
      if (!l) throw new Error("Tensor not found.");
      return l.ensureTensor(r, f, i, p);
    }
    upload(r, s) {
      let f = this.tensorTrackersById.get(r);
      if (!f) throw new Error("Tensor not found.");
      f.upload(s);
    }
    async download(r, s) {
      le("verbose", () => `[WebNN] TensorManager.download {tensorId: ${r}, dstBuffer: ${s?.byteLength}}`);
      let f = this.tensorTrackersById.get(r);
      if (!f) throw new Error("Tensor not found.");
      return f.download(s);
    }
    releaseTensorsForSession(r) {
      for (let s of this.freeTensors) s.sessionId === r && s.destroy();
      this.freeTensors = this.freeTensors.filter((s) => s.sessionId !== r);
    }
    registerTensor(r, s, f, i) {
      let p = this.getMLContext(r), l = Ds(), b = new dr({ sessionId: r, context: p, tensor: s, dataType: f, shape: i });
      return this.tensorTrackersById.set(l, new lr(this, b)), this.externalTensors.add(b), l;
    }
    async getCachedTensor(r, s, f, i, p, l, b) {
      let g = this.getMLContext(r);
      for (let [S, v] of this.freeTensors.entries()) if (v.canReuseTensor(g, s, f)) {
        le("verbose", () => `[WebNN] Reusing tensor {dataType: ${s}, ${b ? `fallbackDataType: ${b},` : ""} shape: ${f}`);
        let T = this.freeTensors.splice(S, 1)[0];
        return T.sessionId = r, T;
      }
      le("verbose", () => `[WebNN] MLContext.createTensor {dataType: ${s}, ${b ? `fallbackDataType: ${b},` : ""} shape: ${f}}`);
      let w = await g.createTensor({ dataType: b ?? s, shape: f, dimensions: f, usage: i, writable: p, readable: l });
      return new dr({ sessionId: r, context: g, tensor: w, dataType: s, shape: f, fallbackDataType: b });
    }
    releaseTensor(r) {
      this.externalTensors.has(r) && this.externalTensors.delete(r), this.freeTensors.push(r);
    }
  }, Rs = (...a) => new ln(...a);
});
var Ws = {};
At(Ws, { WebNNBackend: () => pn });
var pr;
var Nc;
var pn;
var ks = G(() => {
  "use strict";
  ut();
  Ve();
  Bs();
  Ns();
  dn();
  pr = /* @__PURE__ */ new Map([[1, "float32"], [10, "float16"], [6, "int32"], [12, "uint32"], [7, "int64"], [13, "uint64"], [22, "int4"], [21, "uint4"], [3, "int8"], [2, "uint8"], [9, "uint8"]]), Nc = (a, r) => {
    if (a === r) return true;
    if (a === void 0 || r === void 0) return false;
    let s = Object.keys(a).sort(), f = Object.keys(r).sort();
    return s.length === f.length && s.every((i, p) => i === f[p] && a[i] === r[i]);
  }, pn = class {
    constructor(r) {
      this.tensorManager = Rs(this);
      this.mlContextBySessionId = /* @__PURE__ */ new Map();
      this.sessionIdsByMLContext = /* @__PURE__ */ new Map();
      this.mlContextCache = [];
      this.sessionGraphInputs = /* @__PURE__ */ new Map();
      this.sessionGraphOutputs = /* @__PURE__ */ new Map();
      this.temporaryGraphInputs = [];
      this.temporaryGraphOutputs = [];
      this.temporarySessionTensorIds = /* @__PURE__ */ new Map();
      this.mlOpSupportLimitsBySessionId = /* @__PURE__ */ new Map();
      Cs(r.logLevel, !!r.debug);
    }
    get currentSessionId() {
      if (this.activeSessionId === void 0) throw new Error("No active session");
      return this.activeSessionId;
    }
    onRunStart(r) {
      le("verbose", () => `[WebNN] onRunStart {sessionId: ${r}}`), this.activeSessionId = r;
    }
    onRunEnd(r) {
      le("verbose", () => `[WebNN] onRunEnd {sessionId: ${r}}`);
      let s = this.temporarySessionTensorIds.get(r);
      if (s) {
        for (let f of s) le("verbose", () => `[WebNN] releasing temporary tensor {tensorId: ${f}}`), this.tensorManager.releaseTensorId(f);
        this.temporarySessionTensorIds.delete(r), this.activeSessionId = void 0;
      }
    }
    async createMLContext(r) {
      if (r instanceof GPUDevice) {
        let f = this.mlContextCache.findIndex((i) => i.gpuDevice === r);
        if (f !== -1) return this.mlContextCache[f].mlContext;
        {
          let i = await navigator.ml.createContext(r);
          return this.mlContextCache.push({ gpuDevice: r, mlContext: i }), i;
        }
      } else if (r === void 0) {
        let f = this.mlContextCache.findIndex((i) => i.options === void 0 && i.gpuDevice === void 0);
        if (f !== -1) return this.mlContextCache[f].mlContext;
        {
          let i = await navigator.ml.createContext();
          return this.mlContextCache.push({ mlContext: i }), i;
        }
      }
      let s = this.mlContextCache.findIndex((f) => Nc(f.options, r));
      if (s !== -1) return this.mlContextCache[s].mlContext;
      {
        let f = await navigator.ml.createContext(r);
        return this.mlContextCache.push({ options: r, mlContext: f }), f;
      }
    }
    registerMLContext(r, s) {
      this.mlContextBySessionId.set(r, s);
      let f = this.sessionIdsByMLContext.get(s);
      f || (f = /* @__PURE__ */ new Set(), this.sessionIdsByMLContext.set(s, f)), f.add(r), this.mlOpSupportLimitsBySessionId.has(r) || this.mlOpSupportLimitsBySessionId.set(r, s.opSupportLimits()), this.temporaryGraphInputs.length > 0 && (this.sessionGraphInputs.set(r, this.temporaryGraphInputs), this.temporaryGraphInputs = []), this.temporaryGraphOutputs.length > 0 && (this.sessionGraphOutputs.set(r, this.temporaryGraphOutputs), this.temporaryGraphOutputs = []);
    }
    onReleaseSession(r) {
      this.sessionGraphInputs.delete(r), this.sessionGraphOutputs.delete(r);
      let s = this.mlContextBySessionId.get(r);
      if (!s) return;
      this.tensorManager.releaseTensorsForSession(r), this.mlContextBySessionId.delete(r), this.mlOpSupportLimitsBySessionId.delete(r);
      let f = this.sessionIdsByMLContext.get(s);
      if (f.delete(r), f.size === 0) {
        this.sessionIdsByMLContext.delete(s);
        let i = this.mlContextCache.findIndex((p) => p.mlContext === s);
        i !== -1 && this.mlContextCache.splice(i, 1);
      }
    }
    getMLContext(r) {
      return this.mlContextBySessionId.get(r);
    }
    getMLOpSupportLimits(r) {
      return this.mlOpSupportLimitsBySessionId.get(r);
    }
    reserveTensorId() {
      return this.tensorManager.reserveTensorId();
    }
    releaseTensorId(r) {
      le("verbose", () => `[WebNN] releaseTensorId {tensorId: ${r}}`), this.tensorManager.releaseTensorId(r);
    }
    async ensureTensor(r, s, f, i, p) {
      let l = pr.get(f);
      if (!l) throw new Error(`Unsupported ONNX data type: ${f}`);
      return this.tensorManager.ensureTensor(r ?? this.currentSessionId, s, l, i, p);
    }
    async createTemporaryTensor(r, s, f) {
      le("verbose", () => `[WebNN] createTemporaryTensor {onnxDataType: ${s}, shape: ${f}}`);
      let i = pr.get(s);
      if (!i) throw new Error(`Unsupported ONNX data type: ${s}`);
      let p = this.tensorManager.reserveTensorId();
      await this.tensorManager.ensureTensor(r, p, i, f, false);
      let l = this.temporarySessionTensorIds.get(r);
      return l ? l.push(p) : this.temporarySessionTensorIds.set(r, [p]), p;
    }
    uploadTensor(r, s) {
      if (!j().shouldTransferToMLTensor) throw new Error("Trying to upload to a MLTensor while shouldTransferToMLTensor is false");
      le("verbose", () => `[WebNN] uploadTensor {tensorId: ${r}, data: ${s.byteLength}}`), this.tensorManager.upload(r, s);
    }
    async downloadTensor(r, s) {
      return this.tensorManager.download(r, s);
    }
    createMLTensorDownloader(r, s) {
      return async () => {
        let f = await this.tensorManager.download(r);
        return Ls(f, s);
      };
    }
    registerMLTensor(r, s, f, i) {
      let p = pr.get(f);
      if (!p) throw new Error(`Unsupported ONNX data type: ${f}`);
      let l = this.tensorManager.registerTensor(r, s, p, i);
      return le("verbose", () => `[WebNN] registerMLTensor {tensor: ${s}, dataType: ${p}, dimensions: ${i}} -> {tensorId: ${l}}`), l;
    }
    registerGraphInput(r) {
      this.temporaryGraphInputs.push(r);
    }
    registerGraphOutput(r) {
      this.temporaryGraphOutputs.push(r);
    }
    isGraphInput(r, s) {
      let f = this.sessionGraphInputs.get(r);
      return f ? f.includes(s) : false;
    }
    isGraphOutput(r, s) {
      let f = this.sessionGraphOutputs.get(r);
      return f ? f.includes(s) : false;
    }
    isGraphInputOutputTypeSupported(r, s, f = true) {
      let i = pr.get(He(s)), p = this.mlOpSupportLimitsBySessionId.get(r);
      return typeof i > "u" ? false : f ? !!p?.input.dataTypes.includes(i) : !!p?.output.dataTypes.includes(i);
    }
    flush() {
    }
  };
});
var Wc;
var Qt;
var er;
var ft;
var kc;
var Fs;
var Lt;
var tr;
var rr;
var Gs;
var nr;
var or;
var ar;
var nn = G(() => {
  "use strict";
  ze();
  xs();
  Is();
  ut();
  Ve();
  ir();
  cn();
  Wc = (a, r) => {
    j()._OrtInit(a, r) !== 0 && V("Can't initialize onnxruntime.");
  }, Qt = async (a) => {
    Wc(a.wasm.numThreads, Mt(a.logLevel));
  }, er = async (a, r) => {
    j().asyncInit?.();
    let s = a.webgpu.adapter;
    if (r === "webgpu") {
      if (typeof navigator > "u" || !navigator.gpu) throw new Error("WebGPU is not supported in current environment");
      if (s) {
        if (typeof s.limits != "object" || typeof s.features != "object" || typeof s.requestDevice != "function") throw new Error("Invalid GPU adapter set in `env.webgpu.adapter`. It must be a GPUAdapter object.");
      } else {
        let f = a.webgpu.powerPreference;
        if (f !== void 0 && f !== "low-power" && f !== "high-performance") throw new Error(`Invalid powerPreference setting: "${f}"`);
        let i = a.webgpu.forceFallbackAdapter;
        if (i !== void 0 && typeof i != "boolean") throw new Error(`Invalid forceFallbackAdapter setting: "${i}"`);
        if (s = await navigator.gpu.requestAdapter({ powerPreference: f, forceFallbackAdapter: i }), !s) throw new Error('Failed to get GPU adapter. You may need to enable flag "--enable-unsafe-webgpu" if you are using Chrome.');
      }
    }
    if (r === "webnn" && (typeof navigator > "u" || !navigator.ml)) throw new Error("WebNN is not supported in current environment");
    if (r === "webgpu" && j().webgpuInit((f) => {
      a.webgpu.device = f;
    }), r === "webnn") {
      let f = new (ks(), Ht(Ws)).WebNNBackend(a);
      j().webnnInit([f, () => f.reserveTensorId(), (i) => f.releaseTensorId(i), async (i, p, l, b, g) => f.ensureTensor(i, p, l, b, g), (i, p) => {
        f.uploadTensor(i, p);
      }, async (i, p) => f.downloadTensor(i, p), (i, p) => f.registerMLContext(i, p), !!a.trace]);
    }
  }, ft = /* @__PURE__ */ new Map(), kc = (a) => {
    let r = j(), s = r.stackSave();
    try {
      let f = r.PTR_SIZE, i = r.stackAlloc(2 * f);
      r._OrtGetInputOutputCount(a, i, i + f) !== 0 && V("Can't get session input/output count.");
      let l = f === 4 ? "i32" : "i64";
      return [Number(r.getValue(i, l)), Number(r.getValue(i + f, l))];
    } finally {
      r.stackRestore(s);
    }
  }, Fs = (a, r) => {
    let s = j(), f = s.stackSave(), i = 0;
    try {
      let p = s.PTR_SIZE, l = s.stackAlloc(2 * p);
      s._OrtGetInputOutputMetadata(a, r, l, l + p) !== 0 && V("Can't get session input/output metadata.");
      let g = Number(s.getValue(l, "*"));
      i = Number(s.getValue(l + p, "*"));
      let w = s.HEAP32[i / 4];
      if (w === 0) return [g, 0];
      let S = s.HEAPU32[i / 4 + 1], v = [];
      for (let T = 0; T < S; T++) {
        let A = Number(s.getValue(i + 8 + T * p, "*"));
        v.push(A !== 0 ? s.UTF8ToString(A) : Number(s.getValue(i + 8 + (T + S) * p, "*")));
      }
      return [g, w, v];
    } finally {
      s.stackRestore(f), i !== 0 && s._OrtFree(i);
    }
  }, Lt = (a) => {
    let r = j(), s = r._malloc(a.byteLength);
    if (s === 0) throw new Error(`Can't create a session. failed to allocate a buffer of size ${a.byteLength}.`);
    return r.HEAPU8.set(a, s), [s, a.byteLength];
  }, tr = async (a, r) => {
    let s, f, i = j();
    Array.isArray(a) ? [s, f] = a : a.buffer === i.HEAPU8.buffer ? [s, f] = [a.byteOffset, a.byteLength] : [s, f] = Lt(a);
    let p = 0, l = 0, b = 0, g = [], w = [], S = [];
    try {
      if ([l, g] = await As(r), r?.externalData && i.mountExternalData) {
        let O = [];
        for (let $ of r.externalData) {
          let oe = typeof $ == "string" ? $ : $.path, d = typeof $ == "string" ? $ : $.data;
          O.push(Ct(d).then((te) => {
            i.mountExternalData(oe, te);
          }));
        }
        await Promise.all(O);
      }
      for (let O of r?.executionProviders ?? []) if ((typeof O == "string" ? O : O.name) === "webnn") {
        if (i.shouldTransferToMLTensor = false, typeof O != "string") {
          let oe = O, d = oe?.context, te = oe?.gpuDevice, Z = oe?.deviceType, X = oe?.powerPreference;
          d ? i.currentContext = d : te ? i.currentContext = await i.webnnCreateMLContext(te) : i.currentContext = await i.webnnCreateMLContext({ deviceType: Z, powerPreference: X });
        } else i.currentContext = await i.webnnCreateMLContext();
        break;
      }
      p = await i._OrtCreateSession(s, f, l), i.webgpuOnCreateSession?.(p), p === 0 && V("Can't create a session."), i.jsepOnCreateSession?.(), i.currentContext && (i.webnnRegisterMLContext(p, i.currentContext), i.currentContext = void 0, i.shouldTransferToMLTensor = true);
      let [v, T] = kc(p), A = !!r?.enableGraphCapture, C = [], _ = [], k = [], U = [], M = [];
      for (let O = 0; O < v; O++) {
        let [$, oe, d] = Fs(p, O);
        $ === 0 && V("Can't get an input name."), w.push($);
        let te = i.UTF8ToString($);
        C.push(te), k.push(oe === 0 ? { name: te, isTensor: false } : { name: te, isTensor: true, type: ur(oe), shape: d });
      }
      for (let O = 0; O < T; O++) {
        let [$, oe, d] = Fs(p, O + v);
        $ === 0 && V("Can't get an output name."), S.push($);
        let te = i.UTF8ToString($);
        _.push(te), U.push(oe === 0 ? { name: te, isTensor: false } : { name: te, isTensor: true, type: ur(oe), shape: d });
        {
          if (A && r?.preferredOutputLocation === void 0) {
            M.push("gpu-buffer");
            continue;
          }
          let Z = typeof r?.preferredOutputLocation == "string" ? r.preferredOutputLocation : r?.preferredOutputLocation?.[te] ?? "cpu", X = i.webnnIsGraphOutput;
          if (Z === "cpu" && X && X(p, te)) {
            M.push("ml-tensor-cpu-output");
            continue;
          }
          if (Z !== "cpu" && Z !== "cpu-pinned" && Z !== "gpu-buffer" && Z !== "ml-tensor") throw new Error(`Not supported preferred output location: ${Z}.`);
          if (A && Z !== "gpu-buffer") throw new Error(`Not supported preferred output location: ${Z}. Only 'gpu-buffer' location is supported when enableGraphCapture is true.`);
          M.push(Z);
        }
      }
      let Y = null;
      return M.some((O) => O === "gpu-buffer" || O === "ml-tensor" || O === "ml-tensor-cpu-output") && (b = i._OrtCreateBinding(p), b === 0 && V("Can't create IO binding."), Y = { handle: b, outputPreferredLocations: M, outputPreferredLocationsEncoded: M.map((O) => O === "ml-tensor-cpu-output" ? "ml-tensor" : O).map((O) => fn(O)) }), ft.set(p, [p, w, S, Y, A, false]), [p, C, _, k, U];
    } catch (v) {
      throw w.forEach((T) => i._OrtFree(T)), S.forEach((T) => i._OrtFree(T)), b !== 0 && i._OrtReleaseBinding(b) !== 0 && V("Can't release IO binding."), p !== 0 && i._OrtReleaseSession(p) !== 0 && V("Can't release session."), v;
    } finally {
      i._free(s), l !== 0 && i._OrtReleaseSessionOptions(l) !== 0 && V("Can't release session options."), g.forEach((v) => i._free(v)), i.unmountExternalData?.();
    }
  }, rr = (a) => {
    let r = j(), s = ft.get(a);
    if (!s) throw new Error(`cannot release session. invalid session id: ${a}`);
    let [f, i, p, l, b] = s;
    l && (b && r._OrtClearBoundOutputs(l.handle) !== 0 && V("Can't clear bound outputs."), r._OrtReleaseBinding(l.handle) !== 0 && V("Can't release IO binding.")), r.jsepOnReleaseSession?.(a), r.webnnOnReleaseSession?.(a), r.webgpuOnReleaseSession?.(a), i.forEach((g) => r._OrtFree(g)), p.forEach((g) => r._OrtFree(g)), r._OrtReleaseSession(f) !== 0 && V("Can't release session."), ft.delete(a);
  }, Gs = async (a, r, s, f, i, p, l = false) => {
    if (!a) {
      r.push(0);
      return;
    }
    let b = j(), g = b.PTR_SIZE, w = a[0], S = a[1], v = a[3], T = v, A, C;
    if (w === "string" && (v === "gpu-buffer" || v === "ml-tensor")) throw new Error("String tensor is not supported on GPU.");
    if (l && v !== "gpu-buffer") throw new Error(`External buffer must be provided for input/output index ${p} when enableGraphCapture is true.`);
    if (v === "gpu-buffer") {
      let U = a[2].gpuBuffer;
      C = bt(He(w), S);
      {
        let M = b.webgpuRegisterBuffer;
        if (!M) throw new Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');
        A = M(U, f);
      }
    } else if (v === "ml-tensor") {
      let U = a[2].mlTensor;
      C = bt(He(w), S);
      let M = b.webnnRegisterMLTensor;
      if (!M) throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');
      A = M(f, U, He(w), S);
    } else {
      let U = a[2];
      if (Array.isArray(U)) {
        C = g * U.length, A = b._malloc(C), s.push(A);
        for (let M = 0; M < U.length; M++) {
          if (typeof U[M] != "string") throw new TypeError(`tensor data at index ${M} is not a string`);
          b.setValue(A + M * g, be(U[M], s), "*");
        }
      } else {
        let M = b.webnnIsGraphInput, Y = b.webnnIsGraphOutput;
        if (w !== "string" && M && Y) {
          let O = b.UTF8ToString(i);
          if (M(f, O) || Y(f, O)) {
            let $ = He(w);
            C = bt($, S), T = "ml-tensor";
            let oe = b.webnnCreateTemporaryTensor, d = b.webnnUploadTensor;
            if (!oe || !d) throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');
            let te = await oe(f, $, S);
            d(te, new Uint8Array(U.buffer, U.byteOffset, U.byteLength)), A = te;
          } else C = U.byteLength, A = b._malloc(C), s.push(A), b.HEAPU8.set(new Uint8Array(U.buffer, U.byteOffset, C), A);
        } else C = U.byteLength, A = b._malloc(C), s.push(A), b.HEAPU8.set(new Uint8Array(U.buffer, U.byteOffset, C), A);
      }
    }
    let _ = b.stackSave(), k = b.stackAlloc(4 * S.length);
    try {
      S.forEach((M, Y) => b.setValue(k + Y * g, M, g === 4 ? "i32" : "i64"));
      let U = b._OrtCreateTensor(He(w), A, C, k, S.length, fn(T));
      U === 0 && V(`Can't create tensor for input/output. session=${f}, index=${p}.`), r.push(U);
    } finally {
      b.stackRestore(_);
    }
  }, nr = async (a, r, s, f, i, p) => {
    let l = j(), b = l.PTR_SIZE, g = ft.get(a);
    if (!g) throw new Error(`cannot run inference. invalid session id: ${a}`);
    let w = g[0], S = g[1], v = g[2], T = g[3], A = g[4], C = g[5], _ = r.length, k = f.length, U = 0, M = [], Y = [], O = [], $ = [], oe = [], d = l.stackSave(), te = l.stackAlloc(_ * b), Z = l.stackAlloc(_ * b), X = l.stackAlloc(k * b), De = l.stackAlloc(k * b);
    try {
      [U, M] = Ss(p), Ge("wasm prepareInputOutputTensor");
      for (let R = 0; R < _; R++) await Gs(s[R], Y, $, a, S[r[R]], r[R], A);
      for (let R = 0; R < k; R++) await Gs(i[R], O, $, a, v[f[R]], _ + f[R], A);
      $e("wasm prepareInputOutputTensor");
      for (let R = 0; R < _; R++) l.setValue(te + R * b, Y[R], "*"), l.setValue(Z + R * b, S[r[R]], "*");
      for (let R = 0; R < k; R++) l.setValue(X + R * b, O[R], "*"), l.setValue(De + R * b, v[f[R]], "*");
      if (T && !C) {
        let { handle: R, outputPreferredLocations: ae, outputPreferredLocationsEncoded: pe } = T;
        if (S.length !== _) throw new Error(`input count from feeds (${_}) is expected to be always equal to model's input count (${S.length}).`);
        Ge("wasm bindInputsOutputs");
        for (let J = 0; J < _; J++) {
          let ge = r[J];
          await l._OrtBindInput(R, S[ge], Y[J]) !== 0 && V(`Can't bind input[${J}] for session=${a}.`);
        }
        for (let J = 0; J < k; J++) {
          let ge = f[J];
          i[J]?.[3] ? (oe.push(O[J]), l._OrtBindOutput(R, v[ge], O[J], 0) !== 0 && V(`Can't bind pre-allocated output[${J}] for session=${a}.`)) : l._OrtBindOutput(R, v[ge], 0, pe[ge]) !== 0 && V(`Can't bind output[${J}] to ${ae[J]} for session=${a}.`);
        }
        $e("wasm bindInputsOutputs"), ft.set(a, [w, S, v, T, A, true]);
      }
      l.jsepOnRunStart?.(w), l.webnnOnRunStart?.(w);
      let K;
      T ? K = await l._OrtRunWithBinding(w, T.handle, k, X, U) : K = await l._OrtRun(w, Z, te, _, De, k, X, U), K !== 0 && V("failed to call OrtRun().");
      let I = [], E = [];
      Ge("wasm ProcessOutputTensor");
      for (let R = 0; R < k; R++) {
        let ae = Number(l.getValue(X + R * b, "*"));
        if (ae === O[R] || oe.includes(O[R])) {
          I.push(i[R]), ae !== O[R] && l._OrtReleaseTensor(ae) !== 0 && V("Can't release tensor.");
          continue;
        }
        let pe = l.stackSave(), J = l.stackAlloc(4 * b), ge = false, ne, se = 0;
        try {
          l._OrtGetTensorData(ae, J, J + b, J + 2 * b, J + 3 * b) !== 0 && V(`Can't access output tensor data on index ${R}.`);
          let we = b === 4 ? "i32" : "i64", qe = Number(l.getValue(J, we));
          se = l.getValue(J + b, "*");
          let wt = l.getValue(J + b * 2, "*"), Tt = Number(l.getValue(J + b * 3, we)), Se = [];
          for (let re = 0; re < Tt; re++) Se.push(Number(l.getValue(wt + re * b, we)));
          l._OrtFree(wt) !== 0 && V("Can't free memory for tensor dims.");
          let xe = Se.reduce((re, Q) => re * Q, 1);
          ne = ur(qe);
          let Be = T?.outputPreferredLocations[f[R]];
          if (ne === "string") {
            if (Be === "gpu-buffer" || Be === "ml-tensor") throw new Error("String tensor is not supported on GPU.");
            let re = [];
            for (let Q = 0; Q < xe; Q++) {
              let z = l.getValue(se + Q * b, "*"), H = l.getValue(se + (Q + 1) * b, "*"), Ye = Q === xe - 1 ? void 0 : H - z;
              re.push(l.UTF8ToString(z, Ye));
            }
            I.push([ne, Se, re, "cpu"]);
          } else if (Be === "gpu-buffer" && xe > 0) {
            let re = l.webgpuGetBuffer;
            if (!re) throw new Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');
            let Q = re(se), z = bt(qe, xe);
            if (z === void 0 || !fr(ne)) throw new Error(`Unsupported data type: ${ne}`);
            ge = true;
            {
              l.webgpuRegisterBuffer(Q, a, se);
              let H = l.webgpuCreateDownloader(Q, z, a);
              I.push([ne, Se, { gpuBuffer: Q, download: async () => {
                let Ye = await H();
                return new (it(ne))(Ye);
              }, dispose: () => {
                l._OrtReleaseTensor(ae) !== 0 && V("Can't release tensor.");
              } }, "gpu-buffer"]);
            }
          } else if (Be === "ml-tensor" && xe > 0) {
            let re = l.webnnEnsureTensor, Q = l.webnnIsGraphInputOutputTypeSupported;
            if (!re || !Q) throw new Error('preferredLocation "ml-tensor" is not supported without using WebNN.');
            if (bt(qe, xe) === void 0 || !cr(ne)) throw new Error(`Unsupported data type: ${ne}`);
            if (!Q(a, ne, false)) throw new Error(`preferredLocation "ml-tensor" for ${ne} output is not supported by current WebNN Context.`);
            let H = await re(a, se, qe, Se, false);
            ge = true, I.push([ne, Se, { mlTensor: H, download: l.webnnCreateMLTensorDownloader(se, ne), dispose: () => {
              l.webnnReleaseTensorId(se), l._OrtReleaseTensor(ae);
            } }, "ml-tensor"]);
          } else if (Be === "ml-tensor-cpu-output" && xe > 0) {
            let re = l.webnnCreateMLTensorDownloader(se, ne)(), Q = I.length;
            ge = true, E.push((async () => {
              let z = [Q, await re];
              return l.webnnReleaseTensorId(se), l._OrtReleaseTensor(ae), z;
            })()), I.push([ne, Se, [], "cpu"]);
          } else {
            let re = it(ne), Q = new re(xe);
            new Uint8Array(Q.buffer, Q.byteOffset, Q.byteLength).set(l.HEAPU8.subarray(se, se + Q.byteLength)), I.push([ne, Se, Q, "cpu"]);
          }
        } finally {
          l.stackRestore(pe), ne === "string" && se && l._free(se), ge || l._OrtReleaseTensor(ae);
        }
      }
      T && !A && (l._OrtClearBoundOutputs(T.handle) !== 0 && V("Can't clear bound outputs."), ft.set(a, [w, S, v, T, A, false]));
      for (let [R, ae] of await Promise.all(E)) I[R][2] = ae;
      return $e("wasm ProcessOutputTensor"), I;
    } finally {
      l.webnnOnRunEnd?.(w), l.stackRestore(d), s.forEach((K) => {
        K && K[3] === "gpu-buffer" && l.webgpuUnregisterBuffer(K[2].gpuBuffer);
      }), i.forEach((K) => {
        K && K[3] === "gpu-buffer" && l.webgpuUnregisterBuffer(K[2].gpuBuffer);
      }), Y.forEach((K) => l._OrtReleaseTensor(K)), O.forEach((K) => l._OrtReleaseTensor(K)), $.forEach((K) => l._free(K)), U !== 0 && l._OrtReleaseRunOptions(U), M.forEach((K) => l._free(K));
    }
  }, or = (a) => {
    let r = j(), s = ft.get(a);
    if (!s) throw new Error("invalid session id");
    let f = s[0], i = r._OrtEndProfiling(f);
    i === 0 && V("Can't get an profile file name."), r._OrtFree(i);
  }, ar = (a) => {
    let r = [];
    for (let s of a) {
      let f = s[2];
      !Array.isArray(f) && "buffer" in f && r.push(f.buffer);
    }
    return r;
  };
});
var ct;
var Ee;
var Dt;
var hr;
var br;
var mr;
var mn;
var hn;
var gt;
var yt;
var Gc;
var $s;
var zs;
var Vs;
var js;
var Hs;
var qs;
var Ys;
var bn = G(() => {
  "use strict";
  ze();
  nn();
  Ve();
  Zt();
  ct = () => !!ee.wasm.proxy && typeof document < "u", Dt = false, hr = false, br = false, hn = /* @__PURE__ */ new Map(), gt = (a, r) => {
    let s = hn.get(a);
    s ? s.push(r) : hn.set(a, [r]);
  }, yt = () => {
    if (Dt || !hr || br || !Ee) throw new Error("worker not ready");
  }, Gc = (a) => {
    switch (a.data.type) {
      case "init-wasm":
        Dt = false, a.data.err ? (br = true, mn[1](a.data.err)) : (hr = true, mn[0]()), mr && (URL.revokeObjectURL(mr), mr = void 0);
        break;
      case "init-ep":
      case "copy-from":
      case "create":
      case "release":
      case "run":
      case "end-profiling": {
        let r = hn.get(a.data.type);
        a.data.err ? r.shift()[1](a.data.err) : r.shift()[0](a.data.out);
        break;
      }
      default:
    }
  }, $s = async () => {
    if (!hr) {
      if (Dt) throw new Error("multiple calls to 'initWasm()' detected.");
      if (br) throw new Error("previous call to 'initWasm()' failed.");
      if (Dt = true, ct()) return new Promise((a, r) => {
        Ee?.terminate(), Ts().then(([s, f]) => {
          try {
            Ee = f, Ee.onerror = (p) => r(p), Ee.onmessage = Gc, mn = [a, r];
            let i = { type: "init-wasm", in: ee };
            !i.in.wasm.wasmPaths && (s || an) && (i.in.wasm.wasmPaths = { wasm: new URL("ort-wasm-simd-threaded.asyncify.wasm", import.meta.url).href }), Ee.postMessage(i), mr = s;
          } catch (i) {
            r(i);
          }
        }, r);
      });
      try {
        await Kt(ee.wasm), await Qt(ee), hr = true;
      } catch (a) {
        throw br = true, a;
      } finally {
        Dt = false;
      }
    }
  }, zs = async (a) => {
    if (ct()) return yt(), new Promise((r, s) => {
      gt("init-ep", [r, s]);
      let f = { type: "init-ep", in: { epName: a, env: ee } };
      Ee.postMessage(f);
    });
    await er(ee, a);
  }, Vs = async (a) => ct() ? (yt(), new Promise((r, s) => {
    gt("copy-from", [r, s]);
    let f = { type: "copy-from", in: { buffer: a } };
    Ee.postMessage(f, [a.buffer]);
  })) : Lt(a), js = async (a, r) => {
    if (ct()) {
      if (r?.preferredOutputLocation) throw new Error('session option "preferredOutputLocation" is not supported for proxy.');
      return yt(), new Promise((s, f) => {
        gt("create", [s, f]);
        let i = { type: "create", in: { model: a, options: { ...r } } }, p = [];
        a instanceof Uint8Array && p.push(a.buffer), Ee.postMessage(i, p);
      });
    } else return tr(a, r);
  }, Hs = async (a) => {
    if (ct()) return yt(), new Promise((r, s) => {
      gt("release", [r, s]);
      let f = { type: "release", in: a };
      Ee.postMessage(f);
    });
    rr(a);
  }, qs = async (a, r, s, f, i, p) => {
    if (ct()) {
      if (s.some((l) => l[3] !== "cpu")) throw new Error("input tensor on GPU is not supported for proxy.");
      if (i.some((l) => l)) throw new Error("pre-allocated output tensor is not supported for proxy.");
      return yt(), new Promise((l, b) => {
        gt("run", [l, b]);
        let g = s, w = { type: "run", in: { sessionId: a, inputIndices: r, inputs: g, outputIndices: f, options: p } };
        Ee.postMessage(w, ar(g));
      });
    } else return nr(a, r, s, f, i, p);
  }, Ys = async (a) => {
    if (ct()) return yt(), new Promise((r, s) => {
      gt("end-profiling", [r, s]);
      let f = { type: "end-profiling", in: a };
      Ee.postMessage(f);
    });
    or(a);
  };
});
var Js;
var $c;
var gr;
var Xs = G(() => {
  "use strict";
  ze();
  bn();
  ut();
  Xt();
  cn();
  Js = (a, r) => {
    switch (a.location) {
      case "cpu":
        return [a.type, a.dims, a.data, "cpu"];
      case "gpu-buffer":
        return [a.type, a.dims, { gpuBuffer: a.gpuBuffer }, "gpu-buffer"];
      case "ml-tensor":
        return [a.type, a.dims, { mlTensor: a.mlTensor }, "ml-tensor"];
      default:
        throw new Error(`invalid data location: ${a.location} for ${r()}`);
    }
  }, $c = (a) => {
    switch (a[3]) {
      case "cpu":
        return new Le(a[0], a[2], a[1]);
      case "gpu-buffer": {
        let r = a[0];
        if (!fr(r)) throw new Error(`not supported data type: ${r} for deserializing GPU tensor`);
        let { gpuBuffer: s, download: f, dispose: i } = a[2];
        return Le.fromGpuBuffer(s, { dataType: r, dims: a[1], download: f, dispose: i });
      }
      case "ml-tensor": {
        let r = a[0];
        if (!cr(r)) throw new Error(`not supported data type: ${r} for deserializing MLTensor tensor`);
        let { mlTensor: s, download: f, dispose: i } = a[2];
        return Le.fromMLTensor(s, { dataType: r, dims: a[1], download: f, dispose: i });
      }
      default:
        throw new Error(`invalid data location: ${a[3]}`);
    }
  }, gr = class {
    async fetchModelAndCopyToWasmMemory(r) {
      return Vs(await Ct(r));
    }
    async loadModel(r, s) {
      ot();
      let f;
      typeof r == "string" ? f = await this.fetchModelAndCopyToWasmMemory(r) : f = r, [this.sessionId, this.inputNames, this.outputNames, this.inputMetadata, this.outputMetadata] = await js(f, s), at();
    }
    async dispose() {
      return Hs(this.sessionId);
    }
    async run(r, s, f) {
      ot();
      let i = [], p = [];
      Object.entries(r).forEach((T) => {
        let A = T[0], C = T[1], _ = this.inputNames.indexOf(A);
        if (_ === -1) throw new Error(`invalid input '${A}'`);
        i.push(C), p.push(_);
      });
      let l = [], b = [];
      Object.entries(s).forEach((T) => {
        let A = T[0], C = T[1], _ = this.outputNames.indexOf(A);
        if (_ === -1) throw new Error(`invalid output '${A}'`);
        l.push(C), b.push(_);
      });
      let g = i.map((T, A) => Js(T, () => `input "${this.inputNames[p[A]]}"`)), w = l.map((T, A) => T ? Js(T, () => `output "${this.outputNames[b[A]]}"`) : null), S = await qs(this.sessionId, p, g, b, w, f), v = {};
      for (let T = 0; T < S.length; T++) v[this.outputNames[b[T]]] = l[T] ?? $c(S[T]);
      return at(), v;
    }
    startProfiling() {
    }
    endProfiling() {
      Ys(this.sessionId);
    }
  };
});
var Ks = {};
At(Ks, { OnnxruntimeWebAssemblyBackend: () => yr, initializeFlags: () => Zs, wasmBackend: () => zc });
var Zs;
var yr;
var zc;
var Qs = G(() => {
  "use strict";
  ze();
  bn();
  Xs();
  Zs = () => {
    (typeof ee.wasm.initTimeout != "number" || ee.wasm.initTimeout < 0) && (ee.wasm.initTimeout = 0);
    let a = ee.wasm.simd;
    if (typeof a != "boolean" && a !== void 0 && a !== "fixed" && a !== "relaxed" && (console.warn(`Property "env.wasm.simd" is set to unknown value "${a}". Reset it to \`false\` and ignore SIMD feature checking.`), ee.wasm.simd = false), typeof ee.wasm.proxy != "boolean" && (ee.wasm.proxy = false), typeof ee.wasm.trace != "boolean" && (ee.wasm.trace = false), typeof ee.wasm.numThreads != "number" || !Number.isInteger(ee.wasm.numThreads) || ee.wasm.numThreads <= 0) if (typeof self < "u" && !self.crossOriginIsolated) ee.wasm.numThreads = 1;
    else {
      let r = typeof navigator > "u" ? Xr("node:os").cpus().length : navigator.hardwareConcurrency;
      ee.wasm.numThreads = Math.min(4, Math.ceil((r || 1) / 2));
    }
  }, yr = class {
    async init(r) {
      Zs(), await $s(), await zs(r);
    }
    async createInferenceSessionHandler(r, s) {
      let f = new gr();
      return await f.loadModel(r, s), f;
    }
  }, zc = new yr();
});
ze();
ze();
ze();
var is = "1.30.0";
var $l = rn;
{
  let a = (Qs(), Ht(Ks)).wasmBackend;
  rt("webgpu", a, 5), rt("webnn", a, 5), rt("cpu", a, 10), rt("wasm", a, 10);
}
Object.defineProperty(ee.versions, "web", { value: is, enumerable: true });

// src/ocr.js
var DET_MAX_WIDTH = 960;
var DET_TILE = 1280;
var DET_OVERLAP = 160;
var DET_THRESH = 0.3;
var BOX_THRESH = 0.55;
var UNCLIP = 1.6;
var REC_HEIGHT = 48;
var REC_MAX_WIDTH = 1600;
var PaddleOcr = class _PaddleOcr {
  /** ort: modulo onnxruntime (web o node); det/rec: modelli già caricati come byte o percorso; keys: testo del dizionario. */
  static async create(ort, det, rec, keys, sessionOptions = {}) {
    const o = new _PaddleOcr();
    o.ort = ort;
    o.det = await ort.InferenceSession.create(det, sessionOptions);
    o.rec = await ort.InferenceSession.create(rec, sessionOptions);
    o.chars = ["", ...keys.split(/\r?\n/).filter((l) => l.length > 0), " "];
    return o;
  }
  /** Trova e legge tutte le righe di testo: [{ box: {x, y, w, h}, text, conf }]. */
  async read(img) {
    const boxes = await this.detect(img);
    const lines = [];
    for (const box of boxes) {
      const r = await this.recognize(img, box);
      if (r && r.text.trim()) lines.push({ box, text: r.text.trim(), conf: r.conf });
    }
    return lines;
  }
  // ---------- Rilevamento ----------
  async detect(img) {
    const scale = Math.min(1, DET_MAX_WIDTH / img.width);
    const tileSrc = Math.round(DET_TILE / scale);
    const overlapSrc = Math.round(DET_OVERLAP / scale);
    const all = [];
    for (let top = 0; top < img.height; top += tileSrc - overlapSrc) {
      const h = Math.min(tileSrc, img.height - top);
      const boxes = await this.detectTile(img, top, h, scale);
      for (const b of boxes) all.push(b);
      if (top + h >= img.height) break;
    }
    return dedupe(all);
  }
  async detectTile(img, top, srcH, scale) {
    const w = Math.max(32, Math.ceil(img.width * scale / 32) * 32);
    const h = Math.max(32, Math.ceil(srcH * scale / 32) * 32);
    const input = new Float32Array(3 * w * h);
    const mean = [0.485, 0.456, 0.406], std = [0.229, 0.224, 0.225];
    const sx = img.width / w, sy = srcH / h;
    for (let y = 0; y < h; y++) {
      const oy = Math.min(img.height - 1, top + Math.floor((y + 0.5) * sy));
      for (let x = 0; x < w; x++) {
        const ox = Math.min(img.width - 1, Math.floor((x + 0.5) * sx));
        const p = (oy * img.width + ox) * 4;
        for (let c = 0; c < 3; c++) input[c * w * h + y * w + x] = (img.data[p + c] / 255 - mean[c]) / std[c];
      }
    }
    const out = await this.det.run({ [this.det.inputNames[0]]: new this.ort.Tensor("float32", input, [1, 3, h, w]) });
    const prob = out[this.det.outputNames[0]].data;
    return components(prob, w, h).map((b) => {
      const d = b.w * b.h * UNCLIP / (2 * (b.w + b.h));
      const x0 = Math.max(0, (b.x - d) * sx), y0 = Math.max(0, (b.y - d) * sy);
      const x1 = Math.min(img.width, (b.x + b.w + d) * sx), y1 = Math.min(srcH, (b.y + b.h + d) * sy);
      return { x: Math.round(x0), y: Math.round(top + y0), w: Math.round(x1 - x0), h: Math.round(y1 - y0) };
    });
  }
  // ---------- Lettura ----------
  async recognize(img, box) {
    if (box.w < 4 || box.h < 4) return null;
    if (box.h > box.w * 1.6) {
      const m = Math.round(box.w * 0.15);
      const x = Math.max(0, box.x - m), r = Math.min(img.width, box.x + box.w + m);
      return this.run(img, { x, y: box.y, w: r - x, h: box.h }, "gira");
    }
    return this.run(img, box, "dritta");
  }
  /**
   * Prepara la riga per il modello (alta 48) e la legge.
   * dritta: così com'è; gira: ruotata di 90° (l'alto finisce a sinistra);
   * fila: la colonna tagliata in quadrati, uno per carattere, messi uno accanto all'altro.
   */
  async run(img, box, mode) {
    const h = REC_HEIGHT;
    let srcW, srcH, at2;
    if (mode === "dritta") {
      srcW = box.w;
      srcH = box.h;
      at2 = (u, v) => [box.x + u, box.y + v];
    } else if (mode === "gira") {
      srcW = box.h;
      srcH = box.w;
      at2 = (u, v) => [box.x + box.w - 1 - v, box.y + u];
    } else {
      const n2 = Math.max(1, Math.round(box.h / box.w));
      const cell = box.h / n2;
      srcW = n2 * box.w;
      srcH = box.w;
      at2 = (u, v) => {
        const k = Math.floor(u / box.w);
        return [box.x + (u - k * box.w), box.y + k * cell + v * cell / box.w];
      };
    }
    const w = Math.min(REC_MAX_WIDTH, Math.max(16, Math.round(srcW * h / srcH)));
    const input = new Float32Array(3 * w * h);
    const sx = srcW / w, sy = srcH / h;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const [px, py] = at2((x + 0.5) * sx, (y + 0.5) * sy);
        const ox = Math.min(img.width - 1, Math.max(0, Math.floor(px)));
        const oy = Math.min(img.height - 1, Math.max(0, Math.floor(py)));
        const p = (oy * img.width + ox) * 4;
        for (let c = 0; c < 3; c++) input[c * w * h + y * w + x] = (img.data[p + c] / 255 - 0.5) / 0.5;
      }
    }
    const out = await this.rec.run({ [this.rec.inputNames[0]]: new this.ort.Tensor("float32", input, [1, 3, h, w]) });
    const t = out[this.rec.outputNames[0]];
    const [, steps, classes] = t.dims;
    let text2 = "", last = 0, sum = 0, n = 0;
    for (let s = 0; s < steps; s++) {
      let best = 0, bp = -1;
      for (let c = 0; c < classes; c++) {
        const v = t.data[s * classes + c];
        if (v > bp) {
          bp = v;
          best = c;
        }
      }
      if (best !== 0 && best !== last) {
        text2 += this.chars[best] ?? "";
        sum += bp;
        n++;
      }
      last = best;
    }
    return { text: text2, conf: n ? sum / n : 0 };
  }
};
function components(prob, w, h) {
  const seen = new Uint8Array(w * h);
  const stack = new Int32Array(w * h);
  const boxes = [];
  for (let i = 0; i < w * h; i++) {
    if (seen[i] || prob[i] <= DET_THRESH) continue;
    let sp = 0, minX = w, minY = h, maxX = 0, maxY = 0, sum = 0, count = 0;
    stack[sp++] = i;
    seen[i] = 1;
    while (sp > 0) {
      const p = stack[--sp];
      const x = p % w, y = p / w | 0;
      sum += prob[p];
      count++;
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
      if (x > 0 && !seen[p - 1] && prob[p - 1] > DET_THRESH) {
        seen[p - 1] = 1;
        stack[sp++] = p - 1;
      }
      if (x < w - 1 && !seen[p + 1] && prob[p + 1] > DET_THRESH) {
        seen[p + 1] = 1;
        stack[sp++] = p + 1;
      }
      if (y > 0 && !seen[p - w] && prob[p - w] > DET_THRESH) {
        seen[p - w] = 1;
        stack[sp++] = p - w;
      }
      if (y < h - 1 && !seen[p + w] && prob[p + w] > DET_THRESH) {
        seen[p + w] = 1;
        stack[sp++] = p + w;
      }
    }
    const bw = maxX - minX + 1, bh = maxY - minY + 1;
    if (bw < 3 || bh < 3 || sum / count < BOX_THRESH) continue;
    boxes.push({ x: minX, y: minY, w: bw, h: bh });
  }
  return boxes;
}
function dedupe(boxes) {
  const kept = [];
  for (const b of boxes.sort((a, c) => c.w * c.h - a.w * a.h)) {
    if (!kept.some((k) => overlap(k, b) > 0.6)) kept.push(b);
  }
  return kept.sort((a, b) => a.y - b.y || a.x - b.x);
}
function overlap(a, b) {
  const x = Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x));
  const y = Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
  const small = Math.max(1, Math.min(a.w * a.h, b.w * b.h));
  return x * y / small;
}

// src/testo.js
var SOUNDS = {
  whoosh: "spostamento d'aria",
  woosh: "spostamento d'aria",
  swoosh: "fruscio veloce",
  fwoosh: "fiammata",
  swish: "fruscio",
  zoom: "sfreccia",
  vroom: "rombo di motore",
  boom: "esplosione",
  kaboom: "esplosione",
  bam: "colpo",
  bang: "sparo",
  pow: "pugno",
  wham: "colpo forte",
  whack: "botta",
  bonk: "botta in testa",
  smack: "schiaffo",
  slap: "schiaffo",
  punch: "pugno",
  kick: "calcio",
  crash: "schianto",
  smash: "fracasso",
  crack: "crepa",
  snap: "schiocco",
  thud: "tonfo",
  thump: "tonfo",
  slam: "sbattuta",
  stomp: "passo pesante",
  clang: "clangore metallico",
  clank: "rumore metallico",
  click: "clic",
  creak: "scricchiolio",
  crunch: "scricchiolio",
  rumble: "rombo",
  roar: "ruggito",
  growl: "ringhio",
  grr: "ringhio",
  hiss: "sibilo",
  buzz: "ronzio",
  zap: "scarica",
  splash: "schizzo d'acqua",
  drip: "gocciolio",
  sizzle: "sfrigolio",
  flash: "lampo",
  slash: "fendente",
  shing: "lama sguainata",
  stab: "pugnalata",
  slice: "taglio",
  gasp: "sussulto",
  sigh: "sospiro",
  huff: "sbuffo",
  hmph: "sbuffo",
  pant: "affanno",
  gulp: "deglutisce",
  sniff: "annusa",
  argh: "urlo",
  aargh: "urlo",
  ugh: "disgusto",
  tch: "schiocco di lingua",
  shh: "silenzio",
  haha: "risata",
  hahaha: "risata",
  heh: "risatina",
  hehe: "risatina",
  boing: "rimbalzo",
  poof: "sparisce",
  pop: "scoppio",
  ding: "campanello",
  ring: "squillo",
  knock: "bussare",
  beep: "bip",
  rustle: "fruscio",
  flap: "battito d'ali",
  thwip: "lancio",
  fwip: "lancio",
  tremble: "tremito",
  shake: "scossa",
  grab: "afferra",
  grip: "stretta"
};
var COMMON = new Set("room rush push wish fish dish bash cash wash pant bring thing king sing wing string boat boot book look took cook shock stuck luck back pack sack trick stick black slip stop shop drop crop top cap map rap grap this his miss kiss bus but mum hum ham bad ban bat pot pod now how cow row low slow show who why what when dash flesh fresh fang hang gang sang ding ring".split(" "));
var TWO_LETTER = new Set("of to in is it on be as at by we he or an my do if me up so no go us am oh".split(" "));
var CJK = /[぀-ヿ㐀-䶿一-鿿ｦ-ﾟ]/;
var MAX_RANK_FIX = 8e3;
var MAX_RANK_SEGMENT = 15e3;
var words = /* @__PURE__ */ new Map();
function loadWords(text2) {
  const m = /* @__PURE__ */ new Map();
  text2.split(/\r?\n/).forEach((w, i) => {
    w = w.trim();
    if (w && !m.has(w)) m.set(w, i);
  });
  words = m;
}
var isJapanese = (t) => CJK.test(t);
function clean(raw) {
  if (isJapanese(raw)) return raw.trim();
  let t = raw.replace(/\|/g, "I").replace(/[’‘]/g, "'").replace(/[^A-Za-z0-9 .,!?'"\-…:;()]/g, " ");
  t = t.replace(/(\.\.\.|…|[,!?;:])(?=[A-Za-z])/g, "$1 ").replace(/([A-Za-z]{2,})(\d+)(?=[A-Za-z]{2,}|\b)/g, "$1 $2").replace(/(\d)([A-Za-z]{2,})/g, "$1 $2");
  t = fixDigits(t);
  t = t.replace(/([A-Za-z])\1+[lI1]+(?=[!?.]*(\s|$))/g, (_, c) => c + c + "!");
  t = t.replace(/!+[lI1]+(?=\s|$)/g, "!!");
  t = t.replace(/([A-Za-z])\1{2,}/g, "$1");
  t = t.replace(/([AaIiUuYyHhWw])\1(?=[!?.,]*(\s|$))/g, "$1");
  t = t.replace(/([!?])[!?]+/g, "$1$1").replace(/\s+/g, " ").trim();
  t = fixWords(t);
  return sound(t) ?? t;
}
function fixDigits(t) {
  return t.replace(/[A-Za-z0-9]+/g, (w) => {
    const letters = [...w].filter((c) => /[A-Za-z]/.test(c)).length;
    if (letters && /\d/.test(w) && letters >= w.length / 2) {
      return w.replace(/[015 84]/g, (c) => ({ 0: "O", 1: "I", 5: "S", 8: "B", 4: "A" })[c] ?? c);
    }
    return w;
  });
}
function fixWords(text2) {
  if (!words.size) return text2;
  const re = /[A-Za-z]+/g;
  const tokens = [...text2.matchAll(re)];
  let out = "", last = 0;
  tokens.forEach((m, idx) => {
    out += text2.slice(last, m.index);
    const end = m.index + m[0].length;
    const isLast = idx === tokens.length - 1 && !/[A-Za-z0-9]/.test(text2.slice(end));
    out += fixWord(m[0], isLast);
    last = end;
  });
  return out + text2.slice(last);
}
function rank(w) {
  if (words.has(w)) return words.get(w);
  for (const suf of ["s", "es", "ers", "er", "ing", "ed", "d"]) {
    if (w.length - suf.length >= 3 && w.endsWith(suf)) {
      const r = words.get(w.slice(0, -suf.length));
      if (r !== void 0) return r + 2e3;
    }
  }
  return void 0;
}
function fixWord(token, atEnd) {
  const low = token.toLowerCase();
  if (low.length < 4 || rank(low) !== void 0) return token;
  const fixed = repair(low);
  if (fixed) return styled(fixed, token);
  if (atEnd) {
    for (let cut = 3; cut >= 1; cut--) {
      if (low.length - cut < 3) continue;
      const tail = low.slice(-cut);
      if ([...tail].some((c) => !"iel".includes(c))) continue;
      const base = low.slice(0, -cut);
      const f = rank(base) !== void 0 ? base : repair(base);
      if (f) return styled(f, token) + "!!";
    }
  }
  return token;
}
function repair(low) {
  if (low.length >= 6) {
    const parts = segment(low);
    if (parts) return parts.join(" ");
  }
  let best = null, bestRank = MAX_RANK_FIX;
  for (let i = 0; i < 26; i++) {
    const c = String.fromCharCode(97 + i);
    for (const cand of [c + low, low + c]) {
      const r = words.get(cand);
      if (r !== void 0 && r < bestRank) {
        best = cand;
        bestRank = r;
      }
    }
  }
  return best;
}
function segment(s) {
  const n = s.length;
  const cost = new Array(n + 1).fill(Infinity);
  const from = new Array(n + 1).fill(-1);
  cost[0] = 0;
  for (let end = 1; end <= n; end++) {
    for (let start = Math.max(0, end - 20); start < end; start++) {
      if (cost[start] === Infinity) continue;
      const w = s.slice(start, end);
      let r;
      if (w.length === 1) {
        if (w !== "a" && w !== "i") continue;
        r = 5;
      } else if (w.length === 2) {
        if (!TWO_LETTER.has(w)) continue;
        r = 20;
      } else {
        r = rank(w);
        if (r === void 0 || r >= MAX_RANK_SEGMENT) continue;
      }
      const c = cost[start] + 1 + Math.log(r + 2) / 4;
      if (c < cost[end]) {
        cost[end] = c;
        from[end] = start;
      }
    }
  }
  if (from[n] < 0) return null;
  const parts = [];
  for (let i = n; i > 0; i = from[i]) parts.unshift(s.slice(from[i], i));
  return parts.length >= 2 && n / parts.length >= 2.4 && parts[parts.length - 1] !== "i" ? parts : null;
}
function styled(fixed, original) {
  const letters = [...original].filter((c) => /[A-Za-z]/.test(c));
  if (letters.length > 1 && letters.filter((c) => c === c.toUpperCase()).length >= letters.length * 0.7) return fixed.toUpperCase();
  if (original[0] === original[0].toUpperCase()) return fixed[0].toUpperCase() + fixed.slice(1);
  return fixed;
}
function sound(t) {
  const ws2 = t.split(" ").map((w) => w.replace(/^[!?.,\-'"…]+|[!?.,\-'"…]+$/g, "")).filter(Boolean);
  if (!ws2.length || ws2.length > 2) return null;
  const found = [];
  for (const w of ws2) {
    const s = matchSound(w);
    if (!s) return null;
    found.push(s);
  }
  const meaning = [...new Set(found.map((f) => SOUNDS[f]))].join(", ");
  return found.map((f) => f.toUpperCase()).join(" ") + (t.includes("!") ? "!" : "") + ` (${meaning})`;
}
function matchSound(word) {
  const base = word.toLowerCase().replace(/[lir1]+$/, "");
  const cands = [.../* @__PURE__ */ new Set([word.toLowerCase(), base])].filter((c) => c.length >= 2);
  for (const c of cands) {
    if (COMMON.has(c)) return null;
    if (SOUNDS[c]) return c;
  }
  for (const c of cands) {
    if (c.length < 5) continue;
    const limit = c.length >= 7 ? 2 : 1;
    let best = null, bd = Infinity;
    for (const k of Object.keys(SOUNDS)) {
      if (k.length < 5) continue;
      const d = distance(c, k);
      if (d < bd) {
        bd = d;
        best = k;
      }
    }
    if (best && bd <= limit) return best;
  }
  return null;
}
var SIMILAR = /* @__PURE__ */ new Set(["mw", "wm", "nh", "hn", "oa", "ao", "ce", "ec", "il", "li", "uv", "vu", "rn"]);
function distance(a, b) {
  const d = Array.from({ length: a.length + 1 }, () => new Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) d[i][0] = i;
  for (let j2 = 0; j2 <= b.length; j2++) d[0][j2] = j2;
  for (let i = 1; i <= a.length; i++) for (let j2 = 1; j2 <= b.length; j2++) {
    const sub = a[i - 1] === b[j2 - 1] ? 0 : SIMILAR.has(a[i - 1] + b[j2 - 1]) ? 0.5 : 1;
    d[i][j2] = Math.min(d[i - 1][j2] + 1, d[i][j2 - 1] + 1, d[i - 1][j2 - 1] + sub);
  }
  return Math.ceil(d[a.length][b.length]);
}
function group(lines) {
  const pieces = lines.map((l) => {
    const vertical = l.box.h > l.box.w * 1.6 && isJapanese(l.text);
    return { ...l, vertical, lh: Math.max(1, vertical ? l.box.w : l.box.h) };
  });
  const parent = pieces.map((_, i) => i);
  const find = (i) => {
    while (parent[i] !== i) i = parent[i];
    return i;
  };
  for (let i = 0; i < pieces.length; i++) for (let j2 = i + 1; j2 < pieces.length; j2++) {
    if (close(pieces[i], pieces[j2])) parent[find(i)] = find(j2);
  }
  const groups = /* @__PURE__ */ new Map();
  pieces.forEach((p, i) => {
    const r = find(i);
    if (!groups.has(r)) groups.set(r, []);
    groups.get(r).push(p);
  });
  return [...groups.values()].map((members) => {
    const vertical = members.every((m) => m.vertical);
    members.sort(vertical ? (a, b) => b.box.x - a.box.x : (a, b) => a.box.y - b.box.y);
    const x0 = Math.min(...members.map((m) => m.box.x)), y0 = Math.min(...members.map((m) => m.box.y));
    const x1 = Math.max(...members.map((m) => m.box.x + m.box.w)), y1 = Math.max(...members.map((m) => m.box.y + m.box.h));
    return {
      box: { x: x0, y: y0, w: x1 - x0, h: y1 - y0 },
      text: joinLines(members.map((m) => m.text)),
      conf: members.reduce((s, m) => s + m.conf, 0) / members.length
    };
  }).sort((a, b) => a.box.y - b.box.y || a.box.x - b.box.x);
}
function close(a, b) {
  if (a.vertical !== b.vertical) return false;
  if (a.vertical) {
    const lw = Math.min(a.lh, b.lh);
    const hGap = Math.max(a.box.x, b.box.x) - Math.min(a.box.x + a.box.w, b.box.x + b.box.w);
    const vOverlap = Math.min(a.box.y + a.box.h, b.box.y + b.box.h) - Math.max(a.box.y, b.box.y);
    const short = Math.min(a.box.h, b.box.h);
    return Math.max(a.lh, b.lh) <= 2 * lw && hGap < 0.9 * lw && vOverlap > 0.3 * short;
  }
  const lh = Math.min(a.lh, b.lh);
  const vGap = Math.max(a.box.y, b.box.y) - Math.min(a.box.y + a.box.h, b.box.y + b.box.h);
  const hOverlap = Math.min(a.box.x + a.box.w, b.box.x + b.box.w) - Math.max(a.box.x, b.box.x);
  const narrow = Math.min(a.box.w, b.box.w);
  return Math.max(a.lh, b.lh) <= 2.5 * lh && vGap < 0.9 * lh && hOverlap > 0.3 * narrow;
}
function joinLines(lines) {
  let s = "";
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (s && isJapanese(s.slice(-1)) && isJapanese(line[0])) {
    } else if (s) {
      if (s.length > 1 && s.endsWith("-") && /[A-Za-z]/.test(s[s.length - 2])) s = s.slice(0, -1);
      else s += " ";
    }
    s += line;
  }
  return s;
}
var KANA = /[぀-ヿ]/;
var goodJapanese = (l) => l.text.length >= 2 && (KANA.test(l.text) || l.box.h > l.box.w * 1.6);
function balloons(lines) {
  const good = lines.filter((l) => l.conf >= 0.6 && (isJapanese(l.text) && goodJapanese(l) || (l.text.match(/[A-Za-z]/g) || []).length >= 2));
  return group(good).map((b) => ({ ...b, text: clean(b.text) })).filter((b) => isJapanese(b.text) || (b.text.match(/[A-Za-z]/g) || []).length >= 2);
}
function readingOrder(items, rtl) {
  const rows = [];
  for (const it2 of [...items].sort((a, b) => a.box.y - b.box.y)) {
    const row = rows.find((r) => {
      const top = Math.max(r.y0, it2.box.y), bottom = Math.min(r.y1, it2.box.y + it2.box.h);
      return bottom - top > 0.4 * Math.min(r.y1 - r.y0, it2.box.h);
    });
    if (row) {
      row.items.push(it2);
      row.y0 = Math.min(row.y0, it2.box.y);
      row.y1 = Math.max(row.y1, it2.box.y + it2.box.h);
    } else rows.push({ y0: it2.box.y, y1: it2.box.y + it2.box.h, items: [it2] });
  }
  return rows.sort((a, b) => a.y0 - b.y0).flatMap((r) => r.items.sort((a, b) => rtl ? b.box.x + b.box.w - (a.box.x + a.box.w) : a.box.x - b.box.x));
}
function sentenceCase(text2, names = []) {
  const letters = [...text2].filter((c) => /[A-Za-z]/.test(c));
  if (!letters.length || letters.filter((c) => c === c.toUpperCase()).length < letters.length * 0.7) return text2;
  let cap = true, out = "";
  for (const c of text2.toLowerCase()) {
    if (cap && /[a-z]/.test(c)) {
      out += c.toUpperCase();
      cap = false;
    } else {
      out += c;
      if (".!?".includes(c)) cap = true;
    }
  }
  out = out.replace(/\bi\b/g, "I").replace(/\bi'/g, "I'");
  if (names.length) {
    const set = new Set(names.map((n) => n.toLowerCase()));
    out = out.replace(/[a-z][a-z'-]*/gi, (w) => set.has(w.toLowerCase()) ? w[0].toUpperCase() + w.slice(1) : w);
  }
  return out;
}
var known = (w) => words.has(w) || ["s", "es", "ed", "d", "ing", "ly", "er", "est", "'s"].some((suf) => w.endsWith(suf) && words.has(w.slice(0, -suf.length)));
function nameCandidates(texts) {
  if (!words.size) return [];
  const out = /* @__PURE__ */ new Set();
  for (const t of texts) {
    if (isJapanese(t)) continue;
    for (const w of t.match(/[A-Za-z][A-Za-z'-]{2,}/g) || []) {
      const lw = w.toLowerCase().replace(/'s$/, "");
      if (lw.length >= 3 && !known(lw) && !/(.)\1\1/.test(lw)) out.add(lw[0].toUpperCase() + lw.slice(1));
    }
  }
  return [...out];
}

// src/impostazioni.js
var PREDEFINITE = {
  ollama: "http://localhost:11434",
  modello: "",
  // vuoto = automatico (preferisce TranslateGemma)
  opacita: 100,
  // percentuale
  testo: 100,
  // dimensione del testo in percentuale
  intera: true,
  correttore: ""
  // secondo modello che rilegge la bozza con la scheda della serie (vuoto = niente)     // una sola richiesta per tutta la pagina (le nuvolette numerate)
};

// src/offscreen.js
ee.wasm.wasmPaths = chrome.runtime.getURL("ort/");
ee.wasm.numThreads = 1;
var url = (p) => chrome.runtime.getURL(p);
var bytes = async (p) => new Uint8Array(await (await fetch(url(p))).arrayBuffer());
var text = async (p) => (await fetch(url(p))).text();
var ocrPromise = null;
var backend = "";
function getOcr() {
  ocrPromise ??= (async () => {
    const [det, rec, keys, words2] = await Promise.all([
      bytes("modelli/det.onnx"),
      bytes("modelli/rec.onnx"),
      text("modelli/chiavi.txt"),
      text("parole_en.txt")
    ]);
    loadWords(words2);
    try {
      const o = await PaddleOcr.create(ort_webgpu_bundle_min_exports, det, rec, keys, { executionProviders: ["webgpu"] });
      backend = "scheda video";
      return o;
    } catch (e) {
      console.warn("Mercurio: WebGPU non disponibile, uso il processore", e);
      backend = "processore";
      return PaddleOcr.create(ort_webgpu_bundle_min_exports, det, rec, keys, { executionProviders: ["wasm"] });
    }
  })();
  ocrPromise.catch(() => {
    ocrPromise = null;
  });
  return ocrPromise;
}
var current = { ...PREDEFINITE };
var settings = async () => current;
async function loadImage(src) {
  const res = await fetch(src, { credentials: "omit" });
  if (!res.ok) throw new Error(`il sito non mi d\xE0 l'immagine (${res.status})`);
  const bmp = await createImageBitmap(await res.blob());
  const canvas = new OffscreenCanvas(bmp.width, bmp.height);
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  ctx.drawImage(bmp, 0, 0);
  const data = ctx.getImageData(0, 0, bmp.width, bmp.height).data;
  bmp.close();
  return { data, width: canvas.width, height: canvas.height };
}
var cache = /* @__PURE__ */ new Map();
var autoModel = null;
async function ollama(cfg, path, body, maxMs = 0) {
  const base = cfg.ollama.trim().replace(/\/+$/, "");
  const stop = new AbortController();
  const timer = maxMs && setTimeout(() => stop.abort(), maxMs);
  let res;
  try {
    res = await fetch(base + path, { signal: stop.signal, ...body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {} });
    if (res.ok) return await res.json();
  } catch {
    if (stop.signal.aborted) throw new Error("ci mette troppo");
    throw new Error("Ollama non risponde: \xE8 aperto sul PC?");
  } finally {
    clearTimeout(timer);
  }
  if (res.status === 403) throw new Error("Ollama rifiuta l'estensione: imposta OLLAMA_ORIGINS=chrome-extension://* e riavvialo");
  throw new Error(`Ollama ha risposto ${res.status}: ${(await res.text()).slice(0, 150)}`);
}
async function models(cfg) {
  const j2 = await ollama(cfg, "/api/tags");
  return (j2.models || []).map((m) => m.name);
}
async function pickModel(cfg) {
  if (cfg.modello) return cfg.modello;
  if (autoModel) return autoModel;
  const names = await models(cfg);
  autoModel = names.find((n) => n.includes("translategemma")) || names.find((n) => n.includes("gemma")) || names[0];
  if (!autoModel) throw new Error("Su Ollama non c'\xE8 nessun modello: lancia 'ollama pull translategemma:4b'");
  return autoModel;
}
function prompt(model, src, japanese = isJapanese(src), names = []) {
  const [lang, code] = japanese ? ["Japanese", "ja"] : ["English", "en"];
  const t = code === "en" ? sentenceCase(src, names) : src;
  if (model.includes("translategemma")) {
    return `You are a professional ${lang} (${code}) to Italian (it) translator. Your goal is to accurately convey the meaning and nuances of the original ${lang} text while adhering to Italian grammar, vocabulary, and cultural sensitivities.
Produce only the Italian translation, without any additional explanations or commentary. Please translate the following ${lang} text into Italian:


${t}`;
  }
  const used = names.filter((n) => t.toLowerCase().includes(n.toLowerCase()));
  return `Translate this ${lang} comic book text into natural Italian, keeping tone, slang and jokes. The text comes from OCR and may contain small errors: fix them silently. ` + (used.length ? `These are names from the story, keep them as they are: ${used.join(", ")}. ` : "") + `Answer with only the Italian translation.

${t}`;
}
var explainedSound = (t) => /\)$/.test(t) && t.includes(" (") && !/[a-z]/.test(t.split(" (")[0]);
async function translate(cfg, src, names = []) {
  if (explainedSound(src)) return src;
  const model = await pickModel(cfg);
  const key = model + "\n" + src;
  if (cache.has(key)) return cache.get(key);
  const j2 = await ollama(cfg, "/api/chat", {
    model,
    stream: false,
    keep_alive: "30m",
    options: { temperature: 0.2, num_predict: 400 },
    // tetto: un modello che si inceppa non deve andare avanti all'infinito
    messages: [{ role: "user", content: prompt(model, src, isJapanese(src), names) }]
  });
  const out = (j2.message?.content || "").replace(/<think>[\s\S]*?<\/think>/g, "").trim().replace(/^["«]|["»]$/g, "").trim();
  cache.set(key, out);
  return out;
}
var CONTESTO = 6;
async function translatePage(cfg, texts, context = [], names = []) {
  const model = await pickModel(cfg);
  const its = texts.map((t) => explainedSound(t) ? t : cache.get(model + "\n" + t));
  const todo = texts.map((t, i) => [t, i]).filter(([, i]) => its[i] == null);
  if (todo.length === 1) its[todo[0][1]] = await translate(cfg, todo[0][0], names);
  else if (todo.length > 1) {
    const japanese = todo.filter(([t]) => isJapanese(t)).length * 2 > todo.length;
    const ctx = context.filter((t) => t && isJapanese(t) === japanese).slice(-CONTESTO);
    const lines = [...ctx, ...todo.map(([t]) => t)];
    const numbered2 = lines.map((t, n) => `${n + 1}. ${japanese ? t : sentenceCase(t, names)}`).join("\n");
    const j2 = await ollama(cfg, "/api/chat", {
      model,
      stream: false,
      keep_alive: "30m",
      options: { temperature: 0.2, num_predict: 100 * lines.length + 200 },
      messages: [{ role: "user", content: prompt(model, numbered2, japanese, names) }]
    });
    const raw = (j2.message?.content || "").replace(/<think>[\s\S]*?<\/think>/g, "");
    const got = /* @__PURE__ */ new Map();
    let last = 0;
    for (const line of raw.split("\n")) {
      const m = line.match(/^\s*\**(\d+)\**\s*[.)\]:-]\s*(.*)$/);
      if (m) {
        last = Number(m[1]);
        got.set(last, m[2].trim());
      } else if (last && line.trim()) got.set(last, got.get(last) + " " + line.trim());
    }
    const k = ctx.length;
    if (todo.some((_, n) => !got.get(k + n + 1))) return null;
    todo.forEach(([t, i], n) => {
      const it2 = got.get(k + n + 1).replace(/^["«]|["»]$/g, "").trim();
      its[i] = it2;
      cache.set(model + "\n" + t, it2);
    });
  }
  return its;
}
function numbered(raw) {
  const got = /* @__PURE__ */ new Map();
  let last = 0;
  for (const line of raw.replace(/<think>[\s\S]*?<\/think>/g, "").split("\n")) {
    const m = line.match(/^\s*\**(\d+)\**\s*[.)\]:-]\s*(.*)$/);
    if (m) {
      last = Number(m[1]);
      got.set(last, m[2].trim());
    } else if (last && line.trim()) got.set(last, got.get(last) + " " + line.trim());
  }
  return got;
}
async function revise(cfg, { titolo, scheda, nomi = [], coppie = [], righe }) {
  const model = cfg.correttore;
  const japanese = righe.filter((r) => isJapanese(r.o)).length * 2 > righe.length;
  const lang = japanese ? "Japanese" : "English";
  const fix = (t) => japanese ? t : sentenceCase(t, nomi);
  const parts = [
    `You are the Italian adapter of the comic${titolo ? ` "${titolo}"` : ""}. A small model made a first Italian translation of the balloons of one page; it is often too literal or wrong.`,
    `The ${lang} text was read by OCR, so it can contain misread words: guess the intended word from the context.`
  ];
  if (scheda?.trim()) parts.push(`Notes about this series (use these names and terms, they always win):
${scheda.trim()}`);
  if (nomi.length) parts.push(`Names that appear in this series: ${nomi.slice(0, 80).join(", ")}.`);
  if (coppie.length) parts.push(`Previous balloons, for context only:
` + coppie.map((c) => `- ${fix(c.o)} \u2192 ${c.it}`).join("\n"));
  parts.push(`For every numbered balloon write the final Italian text: natural spoken Italian as in a published comic, short, faithful to the meaning and to who is speaking. Keep the same numbers, exactly one line per number, and write nothing else.`);
  parts.push(righe.map((r, i) => `${i + 1}. ${lang}: ${fix(r.o)}
   Bozza: ${r.it}`).join("\n"));
  const body = {
    model,
    stream: false,
    keep_alive: "30m",
    // Tetto alle parole: senza, un modello che si mette a "ragionare" tiene la scheda video al 100% per minuti.
    options: { temperature: 0.3, num_predict: 100 * righe.length + 200 },
    messages: [{ role: "user", content: parts.join("\n\n") }]
  };
  if (/qwen3|deepseek-r1|magistral|gpt-oss/i.test(model)) body.think = false;
  const j2 = await ollama(cfg, "/api/chat", body, 12e4);
  const got = numbered(j2.message?.content || "");
  return righe.map((_, i) => {
    const t = got.get(i + 1)?.replace(/^(Italian|Italiano|Finale|Bozza)\s*:\s*/i, "").replace(/^["«]|["»]$/g, "").trim();
    return t || null;
  });
}
var pages = /* @__PURE__ */ new Map();
async function page(src, data) {
  if (pages.has(src)) return pages.get(src);
  const [ocr, img] = await Promise.all([getOcr(), loadImage(data || src)]);
  const t0 = performance.now();
  const rtl = img.height < img.width * 2;
  const found = readingOrder(balloons(await ocr.read(img)), rtl).map((b) => ({ box: b.box, text: b.text }));
  const result = { w: img.width, h: img.height, balloons: found, nomi: nameCandidates(found.map((b) => b.text)), ms: Math.round(performance.now() - t0), backend };
  pages.set(src, result);
  if (pages.size > 300) pages.delete(pages.keys().next().value);
  return result;
}
async function test() {
  const cfg = await settings();
  const t0 = performance.now();
  const model = await pickModel(cfg);
  cache.delete(model + "\nDAMN... TOP RANKERS HAVE CONNECTIONS WITH GOVERNMENTS TOO.");
  const it2 = await translate(cfg, "DAMN... TOP RANKERS HAVE CONNECTIONS WITH GOVERNMENTS TOO.");
  return { model, it: it2, secondi: ((performance.now() - t0) / 1e3).toFixed(1) };
}
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.to !== "offscreen") return;
  if (msg.cfg) current = { ...PREDEFINITE, ...msg.cfg };
  const run = {
    pagina: () => page(msg.src, msg.data),
    traduci: async () => ({ it: await translate(await settings(), msg.text, msg.nomi) }),
    traduciPagina: async () => ({ its: await translatePage(await settings(), msg.texts, msg.context, msg.nomi) }),
    correggi: async () => ({ its: await revise(await settings(), msg) }),
    prova: test,
    modelli: async () => ({ modelli: await models(await settings()) })
  }[msg.type];
  if (!run) return;
  if (!["pagina", "traduci", "traduciPagina", "correggi"].includes(msg.type)) autoModel = null;
  run().then(reply, (e) => reply({ error: String(e?.message || e) }));
  return true;
});
/*! Bundled license information:

onnxruntime-web/dist/ort.webgpu.bundle.min.mjs:
  (*!
   * ONNX Runtime Web v1.30.0
   * Copyright (c) Microsoft Corporation. All rights reserved.
   * Licensed under the MIT License.
   *)
*/
