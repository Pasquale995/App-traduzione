(() => {
  // src/impostazioni.js
  var PREDEFINITE = {
    motore: "mercurio",
    // 'mercurio' = Mercurio Motore sul PC (si accende da solo), 'ollama' = Ollama
    ollama: "http://localhost:11434",
    modello: "",
    // vuoto = automatico (preferisce TranslateGemma)
    opacita: 100,
    // percentuale
    testo: 100,
    // dimensione del testo in percentuale
    intera: true
    // una sola richiesta per tutta la pagina (le nuvolette numerate)
  };

  // src/popup.js
  var $ = (id) => document.getElementById(id);
  var esito = (t) => {
    $("esito").textContent = t;
  };
  var ask = (msg) => chrome.runtime.sendMessage({ to: "background", ...msg });
  async function loadModels(current) {
    const r = await ask({ type: "modelli" });
    const sel = $("modello");
    sel.length = 1;
    if (r?.error) {
      esito(r.error);
      return;
    }
    for (const m of r.modelli) sel.add(new Option(m, m));
    if (current && !r.modelli.includes(current)) sel.add(new Option(current + " (non trovato)", current));
    sel.value = current;
  }
  async function init() {
    const cfg = { ...PREDEFINITE, ...await chrome.storage.sync.get(PREDEFINITE) };
    $("ollama").value = cfg.ollama;
    $("motore").value = cfg.motore;
    const showMotore = () => {
      $("soloOllama").style.display = $("motore").value === "ollama" ? "" : "none";
      $("soloMercurio").style.display = $("motore").value === "mercurio" ? "" : "none";
    };
    showMotore();
    $("motore").onchange = async () => {
      await chrome.storage.sync.set({ motore: $("motore").value });
      showMotore();
      if ($("motore").value === "ollama") loadModels($("modello").value);
    };
    $("intera").checked = cfg.intera;
    $("intera").onchange = () => chrome.storage.sync.set({ intera: $("intera").checked });
    for (const k of ["opacita", "testo"]) {
      $(k).value = cfg[k];
      $(k + "V").textContent = cfg[k];
    }
    if (cfg.motore === "ollama") loadModels(cfg.modello);
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    let mode = (await ask({ type: "stato", tabId: tab?.id }))?.mode || null;
    const NOMI = { fumetto: "Leggi fumetto", novel: "Leggi novel" };
    const show = () => {
      for (const k of ["fumetto", "novel"]) {
        $(k).textContent = mode === k ? "Ferma" : NOMI[k];
        $(k).classList.toggle("acceso", mode === k);
      }
    };
    show();
    for (const k of ["fumetto", "novel"]) {
      $(k).onclick = async () => {
        if (!tab) return;
        mode = mode === k ? null : k;
        await ask(mode ? { type: "avvia", mode, tabId: tab.id } : { type: "ferma", tabId: tab.id });
        show();
        if (mode) window.close();
      };
    }
    $("ollama").onchange = async () => {
      await chrome.storage.sync.set({ ollama: $("ollama").value.trim() || PREDEFINITE.ollama });
      loadModels($("modello").value);
    };
    $("modello").onchange = () => chrome.storage.sync.set({ modello: $("modello").value });
    for (const k of ["opacita", "testo"]) {
      $(k).oninput = () => {
        $(k + "V").textContent = $(k).value;
        chrome.storage.sync.set({ [k]: Number($(k).value) });
      };
    }
    $("prova").onclick = async () => {
      esito("Provo\u2026 la prima volta il motore carica il modello, pu\xF2 volerci un po'.");
      const r = await ask({ type: "prova" });
      esito(r?.error ? r.error : `${r.model} in ${r.secondi}s:
\xAB${r.it}\xBB`);
    };
    $("ritraduci").onclick = async () => {
      const [tab2] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab2) chrome.tabs.sendMessage(tab2.id, { to: "pagina", type: "ritraduci" }).catch(() => esito("Ricarica la pagina e riprova."));
      window.close();
    };
  }
  init();
})();
