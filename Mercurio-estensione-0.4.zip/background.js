// src/impostazioni.js
var PREDEFINITE = {
  attivo: true,
  ollama: "http://localhost:11434",
  modello: "",
  // vuoto = automatico (preferisce TranslateGemma)
  opacita: 100,
  // percentuale
  testo: 100
  // dimensione del testo in percentuale
};

// src/background.js
var OFFSCREEN = "offscreen.html";
var creating = null;
async function ensureOffscreen() {
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (contexts.length) return;
  creating ??= chrome.offscreen.createDocument({
    url: OFFSCREEN,
    reasons: ["WORKERS"],
    justification: "Legge le scritte dei fumetti con PaddleOCR e le traduce con Ollama"
  }).finally(() => {
    creating = null;
  });
  await creating;
}
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.to !== "background") return;
  (async () => {
    const cfg = { ...PREDEFINITE, ...await chrome.storage.sync.get(PREDEFINITE) };
    await ensureOffscreen();
    for (let i = 0; ; i++) {
      try {
        return await chrome.runtime.sendMessage({ ...msg, cfg, to: "offscreen" });
      } catch (e) {
        if (i >= 20 || !String(e?.message).includes("Receiving end")) throw e;
        await new Promise((r) => setTimeout(r, 150));
      }
    }
  })().then(reply, (e) => reply({ error: String(e?.message || e) }));
  return true;
});
