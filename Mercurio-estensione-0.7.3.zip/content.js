(() => {
  // src/impostazioni.js
  var PREDEFINITE = {
    ollama: "http://localhost:11434",
    modello: "",
    // vuoto = automatico (preferisce TranslateGemma)
    opacita: 100,
    // percentuale
    testo: 100,
    // dimensione del testo in percentuale
    intera: true
    // una sola richiesta per tutta la pagina (le nuvolette numerate)
  };

  // src/stato.js
  var el = null;
  var timer = 0;
  function stato(text, kind = "lavoro") {
    clearTimeout(timer);
    if (!text) {
      el?.remove();
      el = null;
      return;
    }
    if (!el?.isConnected) {
      el = document.createElement("div");
      el.className = "mercurio-etichetta";
      document.documentElement.appendChild(el);
    }
    el.textContent = "Mercurio: " + text;
    el.classList.toggle("errore", kind === "errore");
    if (kind !== "lavoro") timer = setTimeout(() => {
      el?.remove();
      el = null;
    }, kind === "fatto" ? 3e3 : 15e3);
  }

  // src/novel.js
  var BLOCKS = "p,h1,h2,h3,h4,h5,h6,li,blockquote,dd,dt,td,th,figcaption,div";
  var LETTERS = /[A-Za-z぀-ヿ㐀-䶿一-鿿]/g;
  var BATCH_ITEMS = 12;
  var BATCH_CHARS = 2e3;
  function textOf(el2) {
    const c = el2.cloneNode(true);
    c.querySelectorAll("rt, rp, .mercurio-novel, script, style").forEach((e) => e.remove());
    return c.textContent.replace(/\s+/g, " ").trim();
  }
  function isParagraph(el2) {
    if (el2.closest('.mercurio-novel, .mercurio-etichetta, script, style, noscript, textarea, [contenteditable=""], [contenteditable="true"]')) return false;
    if (el2.tagName === "DIV" && el2.querySelector(BLOCKS)) return false;
    if (el2.tagName !== "DIV" && el2.querySelector("p,div,li,blockquote")) return false;
    const t = textOf(el2);
    return (t.match(LETTERS) || []).length >= 2;
  }
  var Novel = class {
    constructor(send2, cfg2) {
      this.send = send2;
      this.cfg = cfg2;
      this.seen = /* @__PURE__ */ new WeakSet();
      this.pending = /* @__PURE__ */ new Set();
      this.busy = false;
      this.running = false;
      this.count = 0;
      this.last = [];
      this.watcher = new IntersectionObserver((entries) => {
        for (const e of entries) {
          if (!e.isIntersecting || this.seen.has(e.target)) continue;
          this.pending.add(e.target);
        }
        this.pump();
      }, { rootMargin: "1500px 0px" });
      this.mutations = new MutationObserver(() => {
        clearTimeout(this.rescan);
        this.rescan = setTimeout(() => this.scan(), 500);
      });
    }
    start() {
      if (this.running) return;
      this.running = true;
      this.count = 0;
      this.scan();
      this.mutations.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => {
        if (this.running && !this.count && !this.pending.size && !this.busy) stato("non trovo testo da tradurre in questa pagina", "errore");
      }, 3e3);
    }
    stop() {
      this.running = false;
      this.watcher.disconnect();
      this.mutations.disconnect();
      this.pending.clear();
      document.querySelectorAll(".mercurio-novel").forEach((e) => e.remove());
      this.seen = /* @__PURE__ */ new WeakSet();
    }
    restart() {
      this.stop();
      this.start();
    }
    scan() {
      if (!this.running) return;
      for (const el2 of document.body.querySelectorAll(BLOCKS)) {
        if (el2._mercurioNovel || !isParagraph(el2)) continue;
        el2._mercurioNovel = true;
        this.watcher.observe(el2);
      }
    }
    async pump() {
      if (this.busy || !this.running) return;
      this.busy = true;
      try {
        while (this.running && this.pending.size) {
          const all = [...this.pending].filter((e) => e.isConnected).sort((a, b) => a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1);
          this.pending.clear();
          while (all.length && this.running) {
            const batch = [];
            let chars = 0;
            while (all.length && batch.length < BATCH_ITEMS && (chars < BATCH_CHARS || !batch.length)) {
              const el2 = all.shift();
              const text = textOf(el2);
              chars += text.length;
              batch.push({ el: el2, text, out: this.placeholder(el2) });
              this.seen.add(el2);
            }
            await this.translate(batch);
            for (const e of this.pending) if (!all.includes(e)) all.push(e);
            this.pending.clear();
          }
        }
        if (this.running) stato(`testo tradotto (${this.count} paragrafi)`, "fatto");
      } finally {
        this.busy = false;
      }
    }
    placeholder(el2) {
      const out = document.createElement("span");
      out.className = "mercurio-novel attesa";
      out.textContent = "\u2026";
      el2.appendChild(out);
      return out;
    }
    async translate(batch) {
      stato(`traduco ${batch.length} paragrafi\u2026 (${this.count} fatti)`, "lavoro");
      let its = null;
      if (batch.length > 1) {
        const r = await this.send({ to: "background", type: "traduciPagina", texts: batch.map((b) => b.text), context: this.last });
        if (r?.error) return this.fail(batch, r.error);
        its = r?.its;
      }
      for (let i = 0; i < batch.length; i++) {
        if (!this.running) return;
        let it = its?.[i];
        if (it == null) {
          const r = await this.send({ to: "background", type: "traduci", text: batch[i].text });
          if (r?.error) return this.fail(batch.slice(i), r.error);
          it = r.it;
        }
        batch[i].out.textContent = it;
        batch[i].out.classList.remove("attesa");
        this.count++;
      }
      this.last = batch.slice(-2).map((b) => b.text);
    }
    fail(batch, error) {
      stato(error, "errore");
      for (const b of batch) {
        b.out.remove();
        this.seen.delete(b.el);
        this.watcher.unobserve(b.el);
        this.watcher.observe(b.el);
      }
      this.running = false;
    }
  };

  // src/content.js
  var cfg = { ...PREDEFINITE };
  var on = false;
  var novel = null;
  var mode = null;
  var MIN_W = 300;
  var MIN_H = 200;
  var MIN_SHOWN = 250;
  var done = /* @__PURE__ */ new WeakMap();
  var shown = /* @__PURE__ */ new Set();
  var queue = [];
  var lastTexts = [];
  var busy = false;
  var isCandidate = (img) => img.naturalWidth >= MIN_W && img.naturalHeight >= MIN_H && img.getBoundingClientRect().width >= MIN_SHOWN;
  var srcOf = (img) => img.currentSrc || img.src;
  function enqueue(img) {
    if (!on || !isCandidate(img)) return;
    const src = srcOf(img);
    if (!src) return;
    const d = done.get(img);
    if (d && d.src === src) return;
    d?.layer?.querySelectorAll(".mercurio-riquadro").forEach((e) => e.remove());
    done.set(img, { src, layer: d?.layer, result: null });
    if (!queue.includes(img)) queue.push(img);
    pump();
  }
  async function send(msg) {
    try {
      return await chrome.runtime.sendMessage(msg);
    } catch (e) {
      const m = String(e?.message || e);
      return { error: /context invalidated/i.test(m) ? "Mercurio \xE8 stato aggiornato: ricarica la pagina (F5)" : m };
    }
  }
  async function pump() {
    if (busy) return;
    busy = true;
    try {
      while (queue.length) await work();
    } finally {
      busy = false;
    }
  }
  async function work() {
    {
      queue.sort((a, b) => Math.abs(a.getBoundingClientRect().top) - Math.abs(b.getBoundingClientRect().top));
      const img = queue.shift();
      const d = done.get(img);
      if (!d || !on) return;
      const layer = layerFor(img);
      badge(layer, "Mercurio: leggo\u2026", false);
      let res;
      try {
        const local = d.src.startsWith("blob:") || d.src.startsWith("data:");
        res = local ? await send({ to: "background", type: "pagina", src: d.src, data: await fromPage(d.src) }) : await send({ to: "background", type: "pagina", src: d.src });
        if (!local && res?.error?.startsWith("il sito non mi d\xE0")) {
          const data = await fromPage(d.src);
          if (data) res = await send({ to: "background", type: "pagina", src: d.src, data });
        }
      } catch (e) {
        res = { error: String(e?.message || e) };
      }
      if (done.get(img) !== d) return;
      if (res?.error) {
        badge(layer, "Mercurio: " + res.error, true);
        d.src = null;
        return;
      }
      d.result = res;
      let n = 0;
      if (cfg.intera && res.balloons.length > 1) {
        badge(layer, `Mercurio: traduco la pagina (${res.balloons.length})`, false);
        const t = await send({ to: "background", type: "traduciPagina", texts: res.balloons.map((b) => b.text), context: lastTexts });
        if (done.get(img) !== d) return;
        if (t?.error) {
          badge(layer, "Mercurio: " + t.error, true);
          d.src = null;
          return;
        }
        if (t?.its) {
          res.balloons.forEach((b, i) => {
            b.it = t.its[i];
          });
          n = res.balloons.length;
          draw(img);
        }
      }
      for (const b of n ? [] : res.balloons) {
        if (done.get(img) !== d || !on || !img.isConnected || img.getBoundingClientRect().width === 0) break;
        badge(layer, `Mercurio: traduco ${++n}/${res.balloons.length}`, false);
        const t = await send({ to: "background", type: "traduci", text: b.text });
        if (t?.error) {
          badge(layer, "Mercurio: " + t.error, true);
          break;
        }
        b.it = t.it;
        if (done.get(img) === d) draw(img);
      }
      if (res.balloons.length) lastTexts = res.balloons.slice(-3).map((b) => b.text);
      if (done.get(img) === d && n === res.balloons.length) badge(layer, null);
      else if (done.get(img) === d) d.src = null;
    }
  }
  async function fromPage(src) {
    try {
      const blob = await (await fetch(src)).blob();
      return await new Promise((ok, ko) => {
        const r = new FileReader();
        r.onload = () => ok(r.result);
        r.onerror = ko;
        r.readAsDataURL(blob);
      });
    } catch {
      return null;
    }
  }
  function layerFor(img) {
    const d = done.get(img);
    if (d.layer?.isConnected) return d.layer;
    const layer = document.createElement("div");
    layer.className = "mercurio-strato";
    document.body.appendChild(layer);
    d.layer = layer;
    shown.add(img);
    place(img);
    return layer;
  }
  function place(img) {
    const d = done.get(img);
    if (!d?.layer) return;
    const r = img.getBoundingClientRect();
    const s = d.layer.style;
    s.left = r.left + window.scrollX + "px";
    s.top = r.top + window.scrollY + "px";
    s.width = r.width + "px";
    s.height = r.height + "px";
    s.display = r.width > 0 && on ? "" : "none";
    const k = d.result ? r.width / d.result.w : 0;
    if (k && Math.abs((d.k || 0) - k) > 1e-3) draw(img);
  }
  function draw(img) {
    const d = done.get(img);
    if (!d?.result) return;
    const layer = layerFor(img);
    const r = img.getBoundingClientRect();
    const k = r.width / d.result.w;
    d.k = k;
    layer.querySelectorAll(".mercurio-riquadro").forEach((e) => e.remove());
    for (const b of d.result.balloons) {
      if (!b.it) continue;
      const el2 = document.createElement("div");
      el2.className = "mercurio-riquadro";
      el2.textContent = b.it;
      el2.title = b.text;
      const pad = 4;
      Object.assign(el2.style, {
        left: b.box.x * k - pad + "px",
        top: b.box.y * k - pad + "px",
        width: b.box.w * k + 2 * pad + "px",
        height: b.box.h * k + 2 * pad + "px",
        opacity: String(cfg.opacita / 100)
      });
      layer.appendChild(el2);
      fit(el2, b.box.h * k + 2 * pad);
    }
  }
  var MIN_FONT = 11;
  function fit(el2, h) {
    let size = Math.max(MIN_FONT, Math.round(16 * cfg.testo / 100));
    const floor = Math.max(MIN_FONT, Math.round(size * 0.7));
    const overflows = () => el2.scrollWidth > el2.clientWidth + 1 || el2.scrollHeight > h + 1;
    el2.style.fontSize = size + "px";
    el2.style.height = "auto";
    el2.style.minHeight = h + "px";
    while (overflows() && size > floor) {
      size--;
      el2.style.fontSize = size + "px";
    }
    const layerW = el2.parentElement.clientWidth;
    let w = el2.offsetWidth;
    while (el2.scrollWidth > el2.clientWidth + 1 && w < layerW) {
      const grow = Math.min(el2.scrollWidth - el2.clientWidth + 6, layerW - w);
      const left = Math.max(0, Math.min(layerW - w - grow, parseFloat(el2.style.left) - grow / 2));
      w += grow;
      el2.style.width = w + "px";
      el2.style.left = left + "px";
    }
    if (el2.scrollWidth > el2.clientWidth + 1) el2.style.overflowWrap = "anywhere";
  }
  function badge(layer, text, error) {
    if (text) stato(text.replace(/^Mercurio: /, ""), error ? "errore" : "lavoro");
    else stato(queue.length ? "passo alla tavola successiva\u2026" : "pagina tradotta", queue.length ? "lavoro" : "fatto");
    let b = layer.querySelector(".mercurio-stato");
    if (!text) {
      b?.remove();
      return;
    }
    if (!b) {
      b = document.createElement("div");
      b.className = "mercurio-stato";
      layer.appendChild(b);
    }
    b.textContent = text;
    b.style.background = error ? "rgba(200,30,30,.9)" : "rgba(40,40,40,.75)";
    clearTimeout(b._t);
    if (error) b._t = setTimeout(() => b.remove(), 15e3);
  }
  var watcher = new IntersectionObserver((entries) => {
    for (const e of entries) if (e.isIntersecting) enqueue(e.target);
  }, { rootMargin: "1200px 0px" });
  function watch(img) {
    if (img._mercurio) return;
    img._mercurio = true;
    watcher.observe(img);
    img.addEventListener("load", () => {
      watcher.unobserve(img);
      watcher.observe(img);
    });
  }
  function scan(root = document) {
    root.querySelectorAll?.("img").forEach(watch);
  }
  new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.type === "attributes" && m.target.tagName === "IMG") {
        const d = done.get(m.target);
        if (d && d.src !== srcOf(m.target)) {
          d.layer?.remove();
          done.delete(m.target);
        }
        watcher.unobserve(m.target);
        watcher.observe(m.target);
      }
      for (const n of m.addedNodes) {
        if (n.tagName === "IMG") watch(n);
        else if (n.nodeType === 1) scan(n);
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["src", "srcset"] });
  function relayoutAll() {
    for (const img of shown) if (!img.isConnected) {
      place(img);
      if (!done.get(img)?.layer?.isConnected) shown.delete(img);
    }
    document.querySelectorAll("img").forEach((img) => {
      const d = done.get(img);
      if (d?.layer) {
        if (!img.isConnected) {
          d.layer.remove();
          done.delete(img);
        } else place(img);
      }
      if (d && d.src && d.src !== srcOf(img) && img.complete) enqueue(img);
      else if (!img._mercurio) watch(img);
    });
  }
  var raf = 0;
  var relayoutSoon = () => {
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(relayoutAll);
  };
  window.addEventListener("resize", relayoutSoon);
  setInterval(relayoutAll, 1500);
  function redrawAll() {
    document.querySelectorAll(".mercurio-strato").forEach((l) => {
      l.style.display = on ? "" : "none";
    });
    document.querySelectorAll("img").forEach((img) => {
      if (done.get(img)?.result) draw(img);
    });
  }
  function retranslateAll() {
    document.querySelectorAll(".mercurio-strato").forEach((l) => l.remove());
    document.querySelectorAll("img").forEach((img) => {
      done.delete(img);
      watcher.unobserve(img);
      watcher.observe(img);
    });
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    for (const [k, v] of Object.entries(changes)) cfg[k] = v.newValue ?? PREDEFINITE[k];
    if (changes.modello || changes.ollama) retranslateAll();
    else redrawAll();
  });
  function setOn(value) {
    if (on === value) return;
    on = value;
    if (on) {
      scan();
      retranslateAll();
      setTimeout(() => {
        if (on && !document.querySelector(".mercurio-strato")) stato('nessuna tavola trovata: se \xE8 testo, usa "Leggi novel"', "errore");
      }, 4e3);
    } else {
      queue.length = 0;
      redrawAll();
    }
  }
  function setMode(m) {
    mode = m;
    setOn(mode === "fumetto");
    if (mode === "novel") {
      novel ??= new Novel(send, () => cfg);
      novel.start();
    } else novel?.stop();
    if (!mode) stato(null);
    else stato(mode === "fumetto" ? "acceso: cerco le tavole\u2026" : "acceso: cerco il testo\u2026", "lavoro");
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.to !== "pagina") return;
    if (msg.type === "ritraduci") {
      if (on) retranslateAll();
      if (mode === "novel") novel?.restart();
    }
    if (msg.type === "acceso") setMode(msg.mode);
  });
  chrome.storage.sync.get(PREDEFINITE).then(async (v) => {
    cfg = { ...PREDEFINITE, ...v };
    scan();
    const r = await send({ to: "background", type: "stato" });
    if (r?.mode) setMode(r.mode);
  });
})();
